const { S3Client } = require("@aws-sdk/client-s3");
const config = require('config');

const s3Client = new S3Client({
  region: config.get('App.AWS.Region'),
  credentials: {
    accessKeyId: config.get('App.AWS.AccessKey'),
    secretAccessKey: config.get('App.AWS.SecretKey'),
  },
});

const BUCKET_NAME = config.get('App.AWS.BucketName');

// Export parameters using standard CommonJS module syntax
module.exports = {
  s3Client,
  BUCKET_NAME
};