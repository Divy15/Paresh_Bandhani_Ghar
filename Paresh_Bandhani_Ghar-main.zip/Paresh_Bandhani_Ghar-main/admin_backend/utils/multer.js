const multer = require("multer");
const path = require("path");

const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  // Swapped the text string 'Filter' with standard case-insensitive regex flag switches /i
  const allowedExtensions = /jpeg|jpg|png|webp|gif|mp4|mov|avi/i;
  const allowedMimeTypes = /image|video/i;

  const extName = allowedExtensions.test(path.extname(file.originalname).toLowerCase());
  const mimeType = allowedMimeTypes.test(file.mimetype);

  if (extName && mimeType) {
    return cb(null, true);
  }
  
  cb(new Error("File validation failed! Only standard images and video files are supported."), false);
};

const uploadEngine = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 1024 * 1024 * 100 
  }
});

const mediaUpload = {
  single: (fieldName) => uploadEngine.single(fieldName),
  array: (fieldName, maxCount = 10) => uploadEngine.array(fieldName, maxCount),
  mixed: (fieldsArray) => uploadEngine.fields(fieldsArray)
};

module.exports = mediaUpload;