const { pgClient } = require('../utils/db');
const { PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { s3Client, BUCKET_NAME } = require("../utils/s3Config");
const crypto = require("crypto");
const config = require('config');

async function store_product_category_subcategory(req, res, next) {
    const { categoryid, subcategoryid } = req.body;

    // 2. Generate unique timestamp-based integer ID (e.g., 1717943234567 + 342 = "1717943234567342")
    const uniqueTimestampInt = `${Date.now()}${Math.floor(100 + Math.random() * 900)}`;

    try {
        // 3. Call your PostgreSQL function using positional parameters
        await pgClient(
            'SELECT store_product_catlog_category($1, $2, $3);',
            [uniqueTimestampInt, parseInt(categoryid, 10), parseInt(subcategoryid, 10)]
        );

        // 4. Return the generated catalog ID back to the client
        return res.status(201).json({
            success: true,
            message: "Product catalog category stored successfully.",
            catalogId: uniqueTimestampInt
        });

    } catch (error) {
        console.error("Database execution failed:", error);
        
        // Pass the error to your global Express error handler
        return next(error);
    }
}

async function generate_batch_presigned_urls(req, res, next) {
    try {
        const { catalogId, products } = req.body;

        // Validation: Ensure catalogId and products array are provided
        if (!catalogId || !Array.isArray(products) || products.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Missing catalogId or products array in request body."
            });
        }

        const region = config.get('App.AWS.Region');

        // Loop through each product to process its media assets
        const processedProducts = await Promise.all(products.map(async (product) => {
            // Generate a secure unique ID for this product slot right now!
            const productId = crypto.randomUUID(); 

            // Validate if the product contains files
            if (!product.files || !Array.isArray(product.files)) {
                return { productId, uploads: [] };
            }

            // Generate pre-signed URLs for this specific product's files in parallel
            const uploads = await Promise.all(product.files.map(async (file) => {
                const { clientFilename, contentType, contentLength } = file;
                const fileExtension = clientFilename.split('.').pop();
                
                // Group inside S3 by catalogId AND the newly generated productId
                const s3Key = `catalogs/${catalogId}/${productId}/${crypto.randomUUID()}.${fileExtension}`;
                
                const command = new PutObjectCommand({
                    Bucket: BUCKET_NAME,
                    Key: s3Key,
                    ContentType: contentType,
                    ContentLength: parseInt(contentLength, 10)
                });

                const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
                const permanentUrl = `https://${BUCKET_NAME}.s3.${region}.amazonaws.com/${s3Key}`;

                return {
                    clientFilename,
                    uploadUrl,
                    permanentUrl,
                    mediaType: contentType.startsWith('video/') ? 'video' : 'image'
                };
            }));

            // Return the product paired up with its new ID and clean upload tickets
            return {
                productId,
                uploads
            };
        }));

        return res.status(200).json({
            success: true,
            message: "Product IDs and pre-signed URLs generated successfully.",
            products: processedProducts
        });

    } catch (error) {
        console.error("Error generating product batch urls:", error);
        return next(error);
    }
}

async function confirm_and_save_product_media(req, res, next) {
    try {
        const { catalogId, media } = req.body; // Expecting: [{ productId, path, isCover }]


        // Set a long-term read expiration window (e.g., 2 days = 172800 seconds)
        const READ_EXPIRES_IN_SECONDS = 172800; 
        const urlExpiresAt = new Date(Date.now() + READ_EXPIRES_IN_SECONDS * 1000);

        // Process each confirmed upload to generate a READ-ready presigned URL
        const formattedRecords = await Promise.all(media.map(async (item) => {
            
            // 1. Generate a read-accessible command token signature
            const command = new GetObjectCommand({
                Bucket: BUCKET_NAME,
                Key: item.path
            });

            // 2. A brand new GET presigned url generated on demand
            const downloadPresignedUrl = await getSignedUrl(s3Client, command, { 
                expiresIn: READ_EXPIRES_IN_SECONDS 
            });

            return {
                productId: parseInt(item.productId, 10), // Type cast to integer safely
                path: item.path,
                presignedUrl: downloadPresignedUrl, // Fresh read URL saved to the column
                urlExpiresAt: urlExpiresAt.toISOString(),
                isCover: !!item.isCover
            };
        }));

        // 3. Flatten and pass down to your PostgreSQL raw worker function
        const jsonPayload = JSON.stringify(formattedRecords);
        await pgClient(`SELECT save_batch_product_media($1, $2)`, [jsonPayload, catalogId]);

        return res.status(201).json({
            success: true,
            message: "Media confirmed and registered with valid read-access presigned URLs."
        });

    } catch (error) {
        console.error("Confirmation execution crash:", error);
        return next(error);
    }
}

module.exports = {
    store_product_category_subcategory,
    generate_batch_presigned_urls,
    confirm_and_save_product_media,
};