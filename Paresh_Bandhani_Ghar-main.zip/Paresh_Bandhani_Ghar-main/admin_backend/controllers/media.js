const { PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { s3Client, BUCKET_NAME } = require("../utils/s3Config");
const { pgClient } = require('../utils/db');

const uploadMediaFile = async (req, res) => {
  try {
    const { type } = req.body; 
    const file = req.file;     

    if (!file) {
      return res.status(400).json({ error: "No file content uploaded under form key 'file'." });
    }

    const cleanFileName = `${Date.now()}_${file.originalname.replace(/\s+/g, "_")}`;
    const s3Key = `paresh_bandhani_ghar_image/${type}/${cleanFileName}`;

    // A. Ship to S3
    const uploadCommand = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: s3Key,
      Body: file.buffer,
      ContentType: file.mimetype,
    });
    await s3Client.send(uploadCommand);

    // B. Save path using native postgres client function call
    const savedMedia = await pgClient('SELECT * FROM store_media_file_path($1)', [s3Key]);

    return res.status(201).json({
      message: "Media asset registered successfully",
      mediaId: savedMedia.rows[0].id,
    });
  } catch (error) {
    console.error("Media upload error:", error);
    return res.status(500).json({ error: "Failed to upload and store media asset." });
  }
};

const getMediaPresignedUrl = async (req, res) => {
  try {
    const mediaId = Number(req.params.id);

    // A. Query using your fixed SQL text string syntax
    const mediaRecord = await pgClient.query('SELECT * FROM get_media_data($1)', [mediaId]);

    if (!mediaRecord.rows || mediaRecord.rows.length === 0) {
      return res.status(404).json({ error: "Requested media record not found." });
    }

    // B. Build secure access command for S3
    const getCommand = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: mediaRecord.rows[0].path, 
    });

    const presignedUrl = await getSignedUrl(s3Client, getCommand, { expiresIn: 3600 });

    return res.status(200).json({
      path: mediaRecord.rows[0].path,
      url: presignedUrl,
    });
  } catch (error) {
    console.error("Presign generation error:", error);
    return res.status(500).json({ error: "Failed to generate temporary media authentication links." });
  }
};

module.exports = {
  uploadMediaFile,
  getMediaPresignedUrl
};