const express = require('express');
const cors = require('cors');
const config = require('config');
const { pgPool } = require('./utils/db.js');
const redisClient = require('./utils/redis.js');
const route = require('./routes/index.js');
const { isCelebrateError } = require('celebrate');

const app = express();
const PORT = config.get('App.Config.Port');

app.use(cors());
// Allow larger payloads if needed
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

(
    async () => {
        try {
            await pgPool.connect();
            console.log('🚀 Database connected');
        } catch (error) {
            console.log(error);
        }
    }
)();

(
    async () => {
        try {
            await redisClient;
        } catch (error) {
            console.log(error);
        }
    }
)();

app.use('/api', route);

app.use((err, req, res, next) => {
    console.error("Caught Error:", err); // Use console.error so you see it clearly

    if (isCelebrateError(err)) {
        // Safely extract whatever segment failed validation (body, params, query, etc.)
        let errorDetails = 'Validation failed';
        for (const [segment, joiError] of err.details.entries()) {
            errorDetails = joiError.message;
            break;
        }
        return res.status(400).json({ success: false, message: errorDetails });
    }
    next(err); // Pass along to the 500 handler
});

app.use((err, req, res, next) => {
        return res.status(500).json({ success: false, message: 'Server internal error please call the administrator' });
});

app.listen(PORT, () => {
    console.log(`🎉 Server is running on port ${PORT}`);
});