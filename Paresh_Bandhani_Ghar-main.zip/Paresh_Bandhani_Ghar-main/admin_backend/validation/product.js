const { Joi } = require('celebrate');

module.exports = {

    store_product_category_subcategory: {
        body: Joi.object({
            categoryid: Joi.number().required(),
            subcategoryid: Joi.number().required()
        })
    },

    generate_batch_presigned_urls: {
        body: Joi.object({
            // Ensure the catalog string is passed and valid
            catalogId: Joi.string().required().messages({
                'any.required': 'Catalog ID is required.'
            }),
            
            // Validate the parent collection of products
            products: Joi.array().items(
                Joi.object({
                    // Each specific product must contain its own nested files array layout
                    files: Joi.array().items(
                        Joi.object({
                            clientFilename: Joi.string().required().messages({
                                'string.empty': 'Original file name cannot be empty.'
                            }),
                            // Restrict content types strictly to image/ or video/ formats
                            contentType: Joi.string().required().regex(/^(image|video)\/.+$/).messages({
                                'string.pattern.base': 'Only image or video asset file formats are accepted.'
                            }),
                            // Enforce reasonable single file size limits (e.g., 100MB maximum)
                            contentLength: Joi.number().integer().positive().max(100 * 1024 * 1024).required().messages({
                                'number.max': 'Individual file size cannot exceed 100 Megabytes.'
                            })
                        })
                    ).min(1).required().messages({
                        'array.min': 'Each product must contain at least one image or video asset file record.',
                        'any.required': 'The files list for each product is required.'
                    })
                })
            ).min(1).required().messages({
                'array.min': 'You must provide at least one product slot to generate upload configurations.',
                'any.required': 'The products block layout array is required.'
            })
        })
    },

    confirm_and_save_product_media: {
        body: Joi.object({
            catalogId: Joi.string().required().messages({
                'any.required': 'Catalog ID is required.'
            }),
            media: Joi.array().items(
                Joi.object({
                    productId: Joi.string().required(), // Ensures clear Postgres compatible values
                    path: Joi.string().required(), // The structural s3 Key string
                    isCover: Joi.boolean().required()
                })
            ).min(1).required()
        })
    },

    update_products_batch: {
        body: Joi.object({
            products: Joi.array().items(
                Joi.object({
                    productId: Joi.string().required(),
                    productName: Joi.string().required(),
                    quantity: Joi.number().integer().min(0).required(),
                    price: Joi.number().integer().min(0).required() // Expecting integer cents/paise
                })
            ).min(1).required() // Ensures at least one product is sent
        })
    },

    update_product_matrix_bulk: {
        body: Joi.array().items(
            Joi.object({
                productId: Joi.string().required().messages({
                    'string.empty': 'Product ID cannot be an empty string',
                    'any.required': 'Product ID is a required field'
                }),
                productMatrix: Joi.array().items(
                    Joi.object({
                        product: Joi.string().required(),
                        material: Joi.string().required(),
                        colour: Joi.string().required(),
                        length: Joi.string().required(), // Matches the string "3" in your JSON
                        width: Joi.string().required()   // Matches the string "1.15" in your JSON
                    })
                ).required().min(1).messages({
                    'array.min': 'productMatrix must contain at least one item specification'
                })
            })
        ).required().min(1)
    },
}