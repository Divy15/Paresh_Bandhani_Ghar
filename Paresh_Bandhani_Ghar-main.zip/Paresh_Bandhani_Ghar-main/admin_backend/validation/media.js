const { Joi } = require('celebrate');

module.exports = {
    uploadMediaFile: {
        body: Joi.object({
            type: Joi.string().valid('category', 'subcategory').required()
        })
    },
    getMediaPresignedUrl: {
        params: Joi.object({
            id: Joi.number().integer().positive().required()
        })
    }
};