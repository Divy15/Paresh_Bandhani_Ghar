-- This is an empty migration.

 DROP FUNCTION IF EXISTS public.edit_washing_instruction(integer, text, text);


CREATE OR REPLACE FUNCTION public.edit_washing_instruction(
    p_id integer,
    p_instruction text,
    p_description text
)
RETURNS TABLE(
    id integer, 
    instruction text, 
    instruction_description text, 
    created_at timestamp without time zone
) 
LANGUAGE 'plpgsql'
COST 100
VOLATILE PARALLEL UNSAFE
ROWS 1000
AS $BODY$
BEGIN
    RETURN QUERY
    UPDATE washing_instruction AS wi
    SET instruction = COALESCE(p_instruction, wi.instruction),
        instruction_description = COALESCE(p_description, wi.instruction_description)
    WHERE wi.id = p_id
    RETURNING wi.id, wi.instruction, wi.instruction_description, wi.created_at;
END;
$BODY$;
