-- This is an empty migration.

-- ==========================================
-- 1. FIXING THE "catalog" TABLE SEQUENCE
-- ==========================================

-- Step A: Create a temporary table and copy existing data
CREATE TEMP TABLE catalog_tmp AS SELECT * FROM "catalog";

-- Step B: Drop the old table (and its foreign key dependents if necessary)
-- Note: 'CASCADE' ensures it drops smoothly, but we will recreate the table and constraints safely.
DROP TABLE "catalog" CASCADE;

-- Step C: Recreate the table with your exact desired column sequence
CREATE TABLE "catalog" (
    "id" SERIAL NOT NULL,
    "catalog_id" TEXT NOT NULL, -- Added next after id
    "category_id" INTEGER NOT NULL,
    "subcategory_id" INTEGER,
    "is_catalog" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "catalog_pkey" PRIMARY KEY ("id")
);

-- Step D: Restore the data from the temporary table
-- Since old data doesn't have "catalog_id", we generate a unique UUID on the fly using gen_random_uuid()
INSERT INTO "catalog" ("id", "catalog_id", "category_id", "subcategory_id", "is_catalog", "created_at")
SELECT 
    "id", 
    gen_random_uuid()::text, -- Generates unique ID for old records
    "category_id", 
    "subcategory_id", 
    "is_catalog", 
    "created_at" 
FROM catalog_tmp;

-- Step E: Re-apply the UNIQUE constraint on catalog_id
CREATE UNIQUE INDEX "catalog_catalog_id_key" ON "catalog"("catalog_id");

-- Step F: Drop the temporary table
DROP TABLE catalog_tmp;


-- ==========================================
-- 2. FIXING THE "product_media" TABLE SEQUENCE
-- ==========================================

-- Step A: Create a temporary table and copy existing data
CREATE TEMP TABLE product_media_tmp AS SELECT * FROM "product_media";

-- Step B: Drop the old table
DROP TABLE "product_media" CASCADE;

-- Step C: Recreate the table with your exact desired column sequence
CREATE TABLE "product_media" (
    "id" SERIAL NOT NULL,
    "product_id" INTEGER NOT NULL,
    "path" TEXT NOT NULL,
    "presigned_url" TEXT,
    "url_expires_at" TIMESTAMP(3),
    "is_cover" BOOLEAN NOT NULL DEFAULT false, -- Added right before created_at
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "product_media_pkey" PRIMARY KEY ("id")
);

-- Step D: Restore the data from the temporary table
-- We map old columns and set the new 'is_cover' column to its default 'false' for existing records
INSERT INTO "product_media" ("id", "product_id", "path", "presigned_url", "url_expires_at", "is_cover", "created_at")
SELECT 
    "id", 
    "product_id", 
    "path", 
    "presigned_url", 
    "url_expires_at", 
    false, -- Default value for old data
    "created_at" 
FROM product_media_tmp;

-- Step E: Re-apply indexes
CREATE INDEX "product_media_product_id_idx" ON "product_media"("product_id");

-- Step F: Drop the temporary table
DROP TABLE product_media_tmp;


-- ==========================================
-- 3. RE-APPLY FOREIGN KEY RELATIONSHIPS
-- ==========================================
-- Since we dropped tables with CASCADE, we must explicitly re-link the relations

-- ==========================================
-- 3. RE-APPLY FOREIGN KEY RELATIONSHIPS
-- ==========================================
-- Updated to match your snake_case/lowercase mapped database tables

ALTER TABLE "catalog" 
  ADD CONSTRAINT "catalog_category_id_fkey" 
  FOREIGN KEY ("category_id") REFERENCES "category"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "catalog" 
  ADD CONSTRAINT "catalog_subcategory_id_fkey" 
  FOREIGN KEY ("subcategory_id") REFERENCES "subcategory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "product_media" 
  ADD CONSTRAINT "product_media_product_id_fkey" 
  FOREIGN KEY ("product_id") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE CASCADE;