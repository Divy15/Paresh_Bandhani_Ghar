-- This is an empty migration.

DROP FUNCTION IF EXISTS public.get_washing_instructions(integer);


CREATE OR REPLACE FUNCTION public.get_washing_instructions(
	p_id integer DEFAULT NULL::integer)
    RETURNS TABLE(id integer, instruction text, instruction_description text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    SELECT wi.id, wi.instruction, wi.instruction_description, wi.created_at
    FROM washing_instruction wi
    WHERE (p_id IS NULL OR wi.id = p_id)
    ORDER BY wi.created_at DESC;
END;
$BODY$;