-- This is an empty migration.
-- 1. Create a temporary column to hold the 'created_at' timestamp safely
ALTER TABLE "product" ADD COLUMN "created_at_temp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- 2. Copy the existing data from 'created_at' into the temporary backup column
UPDATE "product" SET "created_at_temp" = "created_at";

-- 3. Drop the original 'created_at' column
-- (This removes it from its old physical position right before the step columns)
ALTER TABLE "product" DROP COLUMN "created_at";

-- 4. Re-create the 'created_at' column 
-- Because we add it now, PostgreSQL physically places it AFTER 'is_step6_done' on disk!
ALTER TABLE "product" ADD COLUMN "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- 5. Restore the original timestamp values back into the newly positioned 'created_at' column
UPDATE "product" SET "created_at" = "created_at_temp";

-- 6. Clean up by dropping the temporary column
ALTER TABLE "product" DROP COLUMN "created_at_temp";