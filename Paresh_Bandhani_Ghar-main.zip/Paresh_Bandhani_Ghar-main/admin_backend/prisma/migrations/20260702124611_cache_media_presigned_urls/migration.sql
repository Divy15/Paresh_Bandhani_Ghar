-- 1. Alter the media table to add caching columns
ALTER TABLE "media" ADD COLUMN "presigned_url" TEXT;
ALTER TABLE "media" ADD COLUMN "url_expires_at" TIMESTAMP;

DROP FUNCTION IF EXISTS public.get_category_details(character varying);

DROP FUNCTION IF EXISTS public.get_subcategories_by_category(integer);


-- 2. Update Function 1 (get_subcategories_by_category)
CREATE OR REPLACE FUNCTION public.get_subcategories_by_category(
    p_category_id integer DEFAULT NULL::integer)
    RETURNS TABLE(
        id integer, 
        category_id integer, 
        category_name text, 
        subcategory_name text, 
        image_id integer, 
        media_path text, 
        presigned_url text,      -- <-- Added
        url_expires_at timestamp -- <-- Added
    ) 
    LANGUAGE 'plpgsql'
AS $BODY$
BEGIN
    RETURN QUERY
    SELECT 
        s.id,
        s.category_id,
        c.category_name,
        s.subcategory_name,
        s.image_id,
        m.path AS media_path,
        m.presigned_url,      -- <-- Added
        m.url_expires_at      -- <-- Added
    FROM subcategory s
    INNER JOIN category c ON s.category_id = c.id
    LEFT JOIN media m ON s.image_id = m.id
    WHERE (p_category_id IS NULL OR s.category_id = p_category_id)
    ORDER BY s.created_at DESC;
END;
$BODY$;

-- 3. Update Function 2 (get_category_details)
CREATE OR REPLACE FUNCTION public.get_category_details(
    p_search_name character varying DEFAULT NULL::character varying)
    RETURNS TABLE(
        id integer, 
        category_name text, 
        image_id integer, 
        image_path text, 
        presigned_url text,      -- <-- Added
        url_expires_at timestamp -- <-- Added
    ) 
    LANGUAGE 'plpgsql'
AS $BODY$
BEGIN
    RETURN QUERY
    SELECT 
        c.id,
        c.category_name,
        c.image_id,
        m.path AS image_path,
        m.presigned_url,      -- <-- Added
        m.url_expires_at      -- <-- Added
    FROM category c
    LEFT JOIN media m ON c.image_id = m.id
    WHERE (
        p_search_name IS NULL 
        OR TRIM(p_search_name) = '' 
        OR c.category_name ILIKE '%' || p_search_name || '%'
    )
    ORDER BY c.created_at DESC;
END;
$BODY$;