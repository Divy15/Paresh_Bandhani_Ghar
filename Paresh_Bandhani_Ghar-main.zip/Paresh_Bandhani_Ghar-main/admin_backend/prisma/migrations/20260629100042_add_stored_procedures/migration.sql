-- This is an empty migration.
CREATE OR REPLACE FUNCTION store_media_file_path(in_path character varying)
RETURNS TABLE(id integer)
LANGUAGE 'plpgsql'
SECURITY DEFINER PARALLEL UNSAFE
AS $$
BEGIN
    -- Added RETURN QUERY to match the RETURNS TABLE definition
    RETURN QUERY 
    INSERT INTO media(path)
    VALUES (in_path)
    RETURNING media.id;
END;
$$;

CREATE OR REPLACE FUNCTION get_media_data(in_id integer)
RETURNS TABLE (path character varying)
LANGUAGE 'plpgsql'
SECURITY DEFINER PARALLEL UNSAFE
AS $$
BEGIN
    RETURN QUERY
    -- Specified media.path to prevent naming conflicts with the return table column
    SELECT media.path FROM media
    WHERE media.id = in_id;
END;
$$;