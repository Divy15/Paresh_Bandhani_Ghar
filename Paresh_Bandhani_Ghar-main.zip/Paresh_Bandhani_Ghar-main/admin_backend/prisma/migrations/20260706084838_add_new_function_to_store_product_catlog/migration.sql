-- This is an empty migration.

CREATE OR REPLACE FUNCTION store_product_catlog_category(
    in_catlogid TEXT,
    in_categoryid INTEGER,
    in_subcategoryid INTEGER
)
RETURNS VOID 
LANGUAGE plpgsql
SECURITY DEFINER PARALLEL UNSAFE
AS $$
BEGIN

INSERT INTO catalog(catalog_id, category_id, subcategory_id, is_catalog)
VALUES (in_catlogid, in_categoryid, in_subcategoryid, false);

END;
$$;
