-- DropForeignKey
ALTER TABLE "product_media" DROP CONSTRAINT "product_media_product_id_fkey";

-- AlterTable
ALTER TABLE "product_media" ALTER COLUMN "product_id" SET DATA TYPE TEXT;

-- AddForeignKey
ALTER TABLE "product_media" ADD CONSTRAINT "product_media_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("product_id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE OR REPLACE FUNCTION save_batch_product_media(media_records JSONB)
RETURNS VOID AS $$
DECLARE
    record_item JSONB;
BEGIN
    FOR record_item IN SELECT * FROM jsonb_array_elements(media_records)
    LOOP
        INSERT INTO product_media (
            product_id, 
            path, 
            presigned_url, 
            url_expires_at, 
            is_cover, 
            created_at
        ) VALUES (
            (record_item->>'productId')::TEXT, -- Updated to cast to text/string matching the column
            record_item->>'path',
            record_item->>'presignedUrl',
            (record_item->>'urlExpiresAt')::TIMESTAMP WITH TIME ZONE,
            (record_item->>'isCover')::BOOLEAN,
            NOW()
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;