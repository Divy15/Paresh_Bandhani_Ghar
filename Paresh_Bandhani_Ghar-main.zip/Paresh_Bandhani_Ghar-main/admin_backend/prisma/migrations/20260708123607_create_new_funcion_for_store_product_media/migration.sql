-- This is an empty migration.

DROP FUNCTION IF EXISTS public.save_batch_product_media(jsonb);

CREATE OR REPLACE FUNCTION save_batch_product_media(media_records JSONB, target_catalog_id TEXT)
RETURNS VOID AS $$
DECLARE
    record_item JSONB;
    unique_product_count INT;
    current_product_id TEXT;
BEGIN
    -- 1. Calculate how many unique products are present in this media batch array
    SELECT COUNT(DISTINCT (elem->>'productId'))
    INTO unique_product_count
    FROM jsonb_array_elements(media_records) AS elem;

    -- 2. Update the target catalog's "is_catalog" flag based on the product count
    UPDATE catalog
    SET is_catalog = (unique_product_count > 1)
    WHERE id = target_catalog_id;

    -- 3. Loop through the JSON array
    FOR record_item IN SELECT * FROM jsonb_array_elements(media_records)
    LOOP
        current_product_id := record_item->>'productId';

        -- NEW CODE: If the product id does not exist in the product table yet, create it!
        IF NOT EXISTS (SELECT 1 FROM product WHERE product_id = current_product_id) THEN
            INSERT INTO product (
                product_id,
                catalog_id,
                created_at
            ) VALUES (
                current_product_id,
                target_catalog_id,
                NOW()
            );
        END IF;

        -- 4. Safe to insert the media row now since the parent product row exists
        INSERT INTO product_media (
            product_id, 
            path, 
            presigned_url, 
            url_expires_at, 
            is_cover, 
            created_at
        ) VALUES (
            current_product_id,
            record_item->>'path',
            record_item->>'presignedUrl',
            (record_item->>'urlExpiresAt')::TIMESTAMP WITHOUT TIME ZONE,
            (record_item->>'isCover')::BOOLEAN,
            NOW()
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;