-- This is an empty migration.

CREATE OR REPLACE FUNCTION save_batch_product_media(media_records JSONB)
RETURNS VOID AS $$
DECLARE
    record_item JSONB;
BEGIN
    -- Loop through the JSON array passed from the controller
    FOR record_item IN SELECT * FROM jsonb_array_elements(media_records)
    LOOP
        INSERT INTO product_media (
            product_id, 
            path, 
            presigned_url, 
            url_expires_at, 
            is_cover, 
            created_at
        ) VALUES (
            (record_item->>'productId')::INT, -- Cast to your schema's type (change to ::TEXT/::UUID if you alter Prisma)
            record_item->>'path',
            record_item->>'presignedUrl',
            (record_item->>'urlExpiresAt')::TIMESTAMP WITH TIME ZONE,
            (record_item->>'isCover')::BOOLEAN,
            NOW()
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;