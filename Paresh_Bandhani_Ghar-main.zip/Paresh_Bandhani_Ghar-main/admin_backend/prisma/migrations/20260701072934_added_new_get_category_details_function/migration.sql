-- This is an empty migration.

DROP FUNCTION IF EXISTS public.get_category_details(character varying);

CREATE OR REPLACE FUNCTION public.get_category_details(
	p_search_name character varying DEFAULT NULL::character varying)
    RETURNS TABLE(id integer, category_name text, image_id integer, image_path text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    SELECT 
        c.id,
        c.category_name,
        c.image_id,
        m.path AS image_path,
        c.created_at
    FROM category c
    LEFT JOIN media m ON c.image_id = m.id
    WHERE (
        p_search_name IS NULL 
        OR TRIM(p_search_name) = '' 
        OR c.category_name ILIKE '%' || p_search_name || '%'
    )
    ORDER BY c.created_at DESC;
END;
$BODY$;
