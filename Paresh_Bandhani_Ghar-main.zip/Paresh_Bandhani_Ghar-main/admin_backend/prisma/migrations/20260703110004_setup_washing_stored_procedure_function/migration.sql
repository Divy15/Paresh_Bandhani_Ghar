-- This is an empty migration.
-- =========================================================
-- 1. GET FUNCTION: Fetch all or a single record by ID
-- =========================================================
CREATE OR REPLACE FUNCTION get_washing_instructions(p_id INT DEFAULT NULL)
RETURNS TABLE (
    id INT,
    instruction TEXT,
    instruction_description TEXT,
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT wi.id, wi.instruction, wi.instruction_description, wi.created_at
    FROM washing_instruction wi
    WHERE (p_id IS NULL OR wi.id = p_id)
    ORDER BY wi.created_at DESC;
END;
$$ LANGUAGE plpgsql;


-- =========================================================
-- 2. ADD FUNCTION: Insert a new row and return it
-- =========================================================
CREATE OR REPLACE FUNCTION add_washing_instruction(
    p_instruction TEXT,
    p_description TEXT
)
RETURNS TABLE (
    id INT,
    instruction TEXT,
    instruction_description TEXT,
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    INSERT INTO washing_instruction (instruction, instruction_description, created_at)
    VALUES (p_instruction, p_description, NOW())
    RETURNING washing_instruction.id, washing_instruction.instruction, washing_instruction.instruction_description, washing_instruction.created_at;
END;
$$ LANGUAGE plpgsql;


-- =========================================================
-- 3. EDIT FUNCTION: Update an existing row dynamically
-- =========================================================
CREATE OR REPLACE FUNCTION edit_washing_instruction(
    p_id INT,
    p_instruction TEXT,
    p_description TEXT
)
RETURNS TABLE (
    id INT,
    instruction TEXT,
    instruction_description TEXT,
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    UPDATE washing_instruction
    SET instruction = COALESCE(p_instruction, instruction),
        instruction_description = COALESCE(p_description, instruction_description)
    WHERE washing_instruction.id = p_id
    RETURNING washing_instruction.id, washing_instruction.instruction, washing_instruction.instruction_description, washing_instruction.created_at;
END;
$$ LANGUAGE plpgsql;


-- =========================================================
-- 4. DELETE FUNCTION: Remove a row by its ID
-- =========================================================
CREATE OR REPLACE FUNCTION delete_washing_instruction(p_id INT)
RETURNS TABLE (
    id INT,
    instruction TEXT,
    instruction_description TEXT,
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    DELETE FROM washing_instruction
    WHERE washing_instruction.id = p_id
    RETURNING washing_instruction.id, washing_instruction.instruction, washing_instruction.instruction_description, washing_instruction.created_at;
END;
$$ LANGUAGE plpgsql;