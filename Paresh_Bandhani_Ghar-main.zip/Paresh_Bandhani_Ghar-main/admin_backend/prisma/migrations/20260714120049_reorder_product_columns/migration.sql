/*
  Warnings:

  - You are about to drop the column `barcode_id` on the `product` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "product_barcode_id_key";

-- AlterTable
ALTER TABLE "product" DROP COLUMN "barcode_id",
ADD COLUMN     "is_step1_done" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "is_step2_done" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "is_step3_done" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "is_step4_done" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "is_step5_done" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "is_step6_done" BOOLEAN NOT NULL DEFAULT false;
