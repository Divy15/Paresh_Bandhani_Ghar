-- This is an empty migration.

CREATE OR REPLACE FUNCTION update_product_other_details_bulk(p_payload JSONB)
RETURNS VOID AS $$
DECLARE
    v_item JSONB;
BEGIN
    -- Loop through each item in the passed JSON array
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_payload)
    LOOP
        UPDATE "product"
        SET "other_details" = jsonb_build_object(
            'description', v_item->>'description'
        )
        WHERE "product_id" = v_item->>'productId';
    END LOOP;
END;
$$ LANGUAGE plpgsql;