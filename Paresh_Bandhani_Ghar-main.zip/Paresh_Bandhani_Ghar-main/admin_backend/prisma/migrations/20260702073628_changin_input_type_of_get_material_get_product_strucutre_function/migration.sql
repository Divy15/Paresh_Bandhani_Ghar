-- This is an empty migration.

DROP FUNCTION IF EXISTS public.get_all_materials();

DROP FUNCTION IF EXISTS public.get_product_structures(character varying);


CREATE OR REPLACE FUNCTION public.get_all_materials(
	)
    RETURNS TABLE(id integer, material_name text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    SELECT 
        m.id,
        m.material_name,
        m.created_at
    FROM material m
    ORDER BY m.created_at DESC;
END;
$BODY$;

CREATE OR REPLACE FUNCTION public.get_product_structures(
	p_search_name character varying DEFAULT NULL::character varying)
    RETURNS TABLE(id integer, main_name text, includes jsonb, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    SELECT 
        ps.id,
        ps.main_name,
        ps.includes,
        ps.created_at
    FROM product_structure ps
    WHERE (
        p_search_name IS NULL 
        OR TRIM(p_search_name) = '' 
        OR ps.main_name ILIKE '%' || p_search_name || '%'
    )
    ORDER BY ps.created_at DESC;
END;
$BODY$;