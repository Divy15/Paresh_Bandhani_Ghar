-- AlterTable
ALTER TABLE "media" ALTER COLUMN "url_expires_at" SET DATA TYPE TIMESTAMP(3);
