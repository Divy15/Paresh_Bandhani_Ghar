-- This is an empty migration.

CREATE OR REPLACE FUNCTION update_products_from_json(p_products_json JSONB)
RETURNS VOID AS $$
BEGIN
    UPDATE "product" AS p
    SET 
        "product_name" = u.product_name,
        "quantity"     = u.quantity,
        "price"        = u.price
    FROM (
        SELECT 
            (item->>'productId')::TEXT AS product_id,
            (item->>'productName')::TEXT AS product_name,
            (item->>'quantity')::INTEGER AS quantity,
            (item->>'price')::INTEGER AS price
        FROM jsonb_array_elements(p_products_json) AS item
    ) AS u
    WHERE p."product_id" = u.product_id;
END;
$$ LANGUAGE plpgsql;