/*
  Warnings:

  - A unique constraint covering the columns `[catalog_id]` on the table `catalog` will be added. If there are existing duplicate values, this will fail.
  - The required column `catalog_id` was added to the `catalog` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.

*/
-- AlterTable
ALTER TABLE "catalog" ADD COLUMN     "catalog_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "product_media" ADD COLUMN     "is_cover" BOOLEAN NOT NULL DEFAULT false;

-- CreateIndex
CREATE UNIQUE INDEX "catalog_catalog_id_key" ON "catalog"("catalog_id");
