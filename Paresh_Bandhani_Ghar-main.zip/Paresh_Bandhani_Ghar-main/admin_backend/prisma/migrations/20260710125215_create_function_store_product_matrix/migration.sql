-- This is an empty migration.

CREATE OR REPLACE FUNCTION update_product_matrix_bulk(payload JSONB)
RETURNS VOID AS $$
DECLARE
    product_record RECORD;
BEGIN
    -- Loop through each object inside the main JSON array
    FOR product_record IN 
        SELECT 
            elem->>'productId' AS p_id,
            elem->'productMatrix' AS matrix
        FROM jsonb_array_elements(payload) AS elem
    LOOP
        -- Perform the update matching the mapped table and column names
        UPDATE "product"
        SET "product_matrix_details" = product_record.matrix
        WHERE "product_id" = product_record.p_id;
    END LOOP;
END;
$$ LANGUAGE plpgsql
SECURITY DEFINER;