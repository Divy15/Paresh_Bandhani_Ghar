-- DropForeignKey
ALTER TABLE "catalog" DROP CONSTRAINT "catalog_subcategory_id_fkey";
