-- This is an empty migration.

DROP FUNCTION IF EXISTS public.add_washing_instruction(text, text);

DROP FUNCTION IF EXISTS public.edit_washing_instruction(integer, text, text);

DROP FUNCTION IF EXISTS public.delete_washing_instruction(integer);


CREATE OR REPLACE FUNCTION public.add_washing_instruction(
	p_instruction text,
	p_description text)
    RETURNS TABLE(id integer, instruction text, instruction_description text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    INSERT INTO washing_instruction (instruction, instruction_description, created_at)
    VALUES (p_instruction, p_description, NOW())
    RETURNING washing_instruction.id, washing_instruction.instruction, washing_instruction.instruction_description, washing_instruction.created_at;
END;
$BODY$;

CREATE OR REPLACE FUNCTION public.edit_washing_instruction(
	p_id integer,
	p_instruction text,
	p_description text)
    RETURNS TABLE(id integer, instruction text, instruction_description text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    UPDATE washing_instruction
    SET instruction = COALESCE(p_instruction, instruction),
        instruction_description = COALESCE(p_description, instruction_description)
    WHERE washing_instruction.id = p_id
    RETURNING washing_instruction.id, washing_instruction.instruction, washing_instruction.instruction_description, washing_instruction.created_at;
END;
$BODY$;

CREATE OR REPLACE FUNCTION public.delete_washing_instruction(
	p_id integer)
    RETURNS TABLE(id integer, instruction text, instruction_description text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    DELETE FROM washing_instruction
    WHERE washing_instruction.id = p_id
    RETURNING washing_instruction.id, washing_instruction.instruction, washing_instruction.instruction_description, washing_instruction.created_at;
END;
$BODY$;