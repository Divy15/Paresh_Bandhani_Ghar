-- This is an empty migration.
DROP FUNCTION IF EXISTS public.get_subcategories_by_category(integer);

CREATE OR REPLACE FUNCTION public.get_subcategories_by_category(
	p_category_id integer DEFAULT NULL::integer)
    RETURNS TABLE(id integer, category_id integer, category_name text, subcategory_name text, image_id integer, media_path text, created_at timestamp without time zone) 
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
BEGIN
    RETURN QUERY
    SELECT 
        s.id,
        s.category_id,
        c.category_name,
        s.subcategory_name,
        s.image_id,
        m.path AS media_path,
        s.created_at
    FROM subcategory s
    INNER JOIN category c ON s.category_id = c.id
    LEFT JOIN media m ON s.image_id = m.id
    WHERE (p_category_id IS NULL OR s.category_id = p_category_id)
    ORDER BY s.created_at DESC;
END;
$BODY$;