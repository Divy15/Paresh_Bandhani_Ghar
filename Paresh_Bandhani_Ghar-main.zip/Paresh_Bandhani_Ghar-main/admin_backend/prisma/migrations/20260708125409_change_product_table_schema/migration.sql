-- DropForeignKey
ALTER TABLE "product" DROP CONSTRAINT "product_catalog_id_fkey";

-- AlterTable
ALTER TABLE "product" ALTER COLUMN "catalog_id" SET DATA TYPE TEXT;

-- AddForeignKey
ALTER TABLE "product" ADD CONSTRAINT "product_catalog_id_fkey" FOREIGN KEY ("catalog_id") REFERENCES "catalog"("catalog_id") ON DELETE CASCADE ON UPDATE CASCADE;
