-- This is an empty migration.
DROP FUNCTION IF EXISTS public.save_batch_product_media(jsonb);

CREATE OR REPLACE FUNCTION public.save_batch_product_media(
	media_records jsonb)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    record_item JSONB;
BEGIN
    FOR record_item IN SELECT * FROM jsonb_array_elements(media_records)
    LOOP
        INSERT INTO product_media (
            product_id, 
            path, 
            presigned_url, 
            url_expires_at, 
            is_cover, 
            created_at
        ) VALUES (
            (record_item->>'productId')::TEXT, -- Updated to cast to text/string matching the column
            record_item->>'path',
            record_item->>'presignedUrl',
            (record_item->>'urlExpiresAt')::TIMESTAMP WITH TIME ZONE,
            (record_item->>'isCover')::BOOLEAN,
            NOW()
        );
    END LOOP;
END;
$BODY$;
