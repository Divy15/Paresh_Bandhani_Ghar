-- This is an empty migration.

-- step 1 and step2 completion logs are puted hear
DROP FUNCTION IF EXISTS public.save_batch_product_media(jsonb, text);

-- step3 completion logs are puted hear
DROP FUNCTION IF EXISTS public.update_products_from_json(jsonb);

-- step4 completion logs are puted hear
DROP FUNCTION IF EXISTS public.update_product_matrix_bulk(jsonb);

-- step5 completion logs are puted hear
DROP FUNCTION IF EXISTS public.update_product_other_details_bulk(jsonb);

-- step 1 and 2 function

CREATE OR REPLACE FUNCTION public.save_batch_product_media(
	media_records jsonb,
	target_catalog_id text)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    record_item JSONB;
    unique_product_count INT;
    current_product_id TEXT;
BEGIN
    -- 1. Calculate how many unique products are present in this media batch array
    -- (Ensuring we use exact 'productId' case matching the API payload)
    SELECT COUNT(DISTINCT (elem->>'productId'))
    INTO unique_product_count
    FROM jsonb_array_elements(media_records) AS elem;

    -- 2. Update the target catalog's "is_catalog" flag based on the product count
    UPDATE catalog
    SET is_catalog = CASE WHEN (unique_product_count > 1) THEN TRUE ELSE FALSE END
    WHERE catalog_id = target_catalog_id;

    -- 3. Loop through the JSON array
    FOR record_item IN SELECT * FROM jsonb_array_elements(media_records)
    LOOP
        -- Explicitly extract 'productId' (case-sensitive mapping to your API layout)
        current_product_id := record_item->>'productId';

        -- Safety fallback check: skip or error if the input JSON somehow passes an empty ID string
        IF current_product_id IS NOT NULL AND current_product_id <> '' THEN

            -- 4. If the product id does not exist in the product table yet, create it!
            IF NOT EXISTS (SELECT 1 FROM product WHERE product_id = current_product_id) THEN
                INSERT INTO product (
                    product_id,
                    catalog_id,
                    product_name,           
                    quantity,               
                    price,                  
                    product_matrix_details, 
					is_step1_done,
					is_step2_done,
                    created_at
                ) VALUES (
                    current_product_id,
                    target_catalog_id,
                    'Draft Item ' || SUBSTRING(current_product_id FROM 1 FOR 8), 
                    1,                                                            
                    0,                                                            
                    '{}'::jsonb,                                                  
					true,
					true,
                    NOW()
                );
            END IF;

            -- 5. Safe to insert the media row now since the parent product row exists
            INSERT INTO product_media (
                product_id, 
                path, 
                presigned_url, 
                url_expires_at, 
                is_cover, 
                created_at
            ) VALUES (
                current_product_id,
                record_item->>'path',
                record_item->>'presignedUrl',
                (record_item->>'urlExpiresAt')::TIMESTAMP WITHOUT TIME ZONE,
                (record_item->>'isCover')::BOOLEAN,
                NOW()
            );
            
        END IF;
    END LOOP;
END;
$BODY$;

-- step 3 function

CREATE OR REPLACE FUNCTION public.update_products_from_json(
	p_products_json jsonb)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
BEGIN
    UPDATE "product" AS p
    SET 
        "product_name" = u.product_name,
        "quantity"     = u.quantity,
        "price"        = u.price,
		"is_step3_done" = true
    FROM (
        SELECT 
            (item->>'productId')::TEXT AS product_id,
            (item->>'productName')::TEXT AS product_name,
            (item->>'quantity')::INTEGER AS quantity,
            (item->>'price')::INTEGER AS price
        FROM jsonb_array_elements(p_products_json) AS item
    ) AS u
    WHERE p."product_id" = u.product_id;
END;
$BODY$;

-- step 4 function

CREATE OR REPLACE FUNCTION public.update_product_matrix_bulk(
	payload jsonb)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE SECURITY DEFINER PARALLEL UNSAFE
AS $BODY$
DECLARE
    product_record RECORD;
BEGIN
    -- Loop through each object inside the main JSON array
    FOR product_record IN 
        SELECT 
            elem->>'productId' AS p_id,
            elem->'productMatrix' AS matrix
        FROM jsonb_array_elements(payload) AS elem
    LOOP
        -- Perform the update matching the mapped table and column names
        UPDATE "product"
        SET "product_matrix_details" = product_record.matrix,
		"is_step4_done" = true
        WHERE "product_id" = product_record.p_id;
    END LOOP;
END;
$BODY$;

-- step 5 function

CREATE OR REPLACE FUNCTION public.update_product_other_details_bulk(
	p_payload jsonb)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_item JSONB;
BEGIN
    -- Loop through each item in the passed JSON array
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_payload)
    LOOP
        UPDATE "product"
        SET "other_details" = jsonb_build_object(
            'description', v_item->>'description'
        ),
		"is_step5_done" = true
        WHERE "product_id" = v_item->>'productId';
    END LOOP;
END;
$BODY$;
