-- This is an empty migration.

CREATE OR REPLACE FUNCTION admin_product_get_product_list(
    in_catalog_id text DEFAULT NULL,
    in_product_id text DEFAULT NULL,
    in_product_name text DEFAULT NULL,
    in_pagenumber integer DEFAULT 1
)
RETURNS TABLE(
    catalog_id text,
    category_id integer, -- Adjust data type if your category_id is text/uuid
    category_name text,
    product_id text,
    product_name text,
    quantity integer,
    price integer,
    product_status text, -- The online/offline tag
    product_media json   -- The aggregated media objects
)
LANGUAGE plpgsql
SECURITY DEFINER PARALLEL SAFE
AS $$
DECLARE
    page_limit integer := 20;
    page_offset integer := page_limit * (in_pagenumber - 1);
BEGIN

    RETURN QUERY
    SELECT
        c.catalog_id::text,
        c.category_id,
        ct.category_name,
        p.product_id::text,
        p.product_name,
        p.quantity,
        p.price,
        -- Conditional Status Tag Logic
        CASE 
            WHEN p.is_step1_done AND p.is_step2_done AND p.is_step3_done AND p.is_step4_done AND p.is_step5_done THEN 'Online'
            WHEN p.is_step1_done AND p.is_step2_done AND p.is_step3_done THEN 'Offline'
            ELSE 'Incomplete' -- Fallback if it doesn't meet either criteria
        END AS product_status,
        -- Proper JSON aggregation structure
        JSON_AGG(
            JSON_BUILD_OBJECT(
                'path', pm.path,
                'presigned_url', pm.presigned_url,
                'url_expires_at', pm.url_expires_at,
                'is_cover', pm.is_cover
            )
        ) AS product_media
    FROM catalog c
    JOIN category ct ON ct.id = c.category_id
    JOIN product p ON p.catalog_id = c.catalog_id
    JOIN product_media pm ON pm.product_id = p.product_id
    WHERE 
        -- Optional Filters (If param is null, filter is bypassed)
        (in_catalog_id IS NULL OR c.catalog_id = in_catalog_id)
        AND (in_product_id IS NULL OR p.product_id = in_product_id)
        AND (in_product_name IS NULL OR p.product_name ILIKE '%' || in_product_name || '%')
    GROUP BY 
        c.catalog_id, c.category_id, ct.category_name, 
        p.product_id, p.product_name, p.quantity, p.price,
        p.is_step1_done, p.is_step2_done, p.is_step3_done, p.is_step4_done, p.is_step5_done
    ORDER BY p.product_id
    LIMIT page_limit
    OFFSET page_offset;

END;
$$;

CREATE OR REPLACE FUNCTION update_batch_presigned_urls(
    in_payload jsonb
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER AS $$
BEGIN
    -- Update product_media directly using double-quoted camelCase columns
    UPDATE product_media pm
    SET 
        presigned_url = item."presignedUrl",
        url_expires_at = (item."urlExpiresAt")::timestamp
    FROM jsonb_to_recordset(in_payload) AS item(
        path text, 
        "presignedUrl" text, 
        "urlExpiresAt" text
    )
    WHERE pm.path = item.path;
END;
$$;