const express = require('express');
const route = express.Router();
const { celebrate, Segments } = require('celebrate');
const mediaUpload = require('../utils/multer'); // Fixed assignment mapping
const mediaCtrl = require('../controllers/media');
const paramValidation = require('../validation/media');

route.route('/upload/file')
.post(
    mediaUpload.single('file'), // Run Multer first so req.body exists
    celebrate({ [Segments.BODY]: paramValidation.uploadMediaFile.body }), 
    mediaCtrl.uploadMediaFile
);

route.route('/get/presigned/url/:id')
.get( // Changed to .get since you are fetching resource access links
    celebrate({ [Segments.PARAMS]: paramValidation.getMediaPresignedUrl.params }), // Changed QUERY to PARAMS
    mediaCtrl.getMediaPresignedUrl
);

module.exports = route;