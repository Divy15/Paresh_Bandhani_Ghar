const express = require('express');
const route = express.Router();
const authRoute = require('./auth');
const configRoute = require('./configuration');
const mediaRoute = require('./media');

route.use('/auth', authRoute);

route.use('/config', configRoute);

route.use('/media', mediaRoute);

module.exports = route;