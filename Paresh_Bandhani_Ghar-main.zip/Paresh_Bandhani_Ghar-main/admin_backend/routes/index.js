const express = require('express');
const route = express.Router();
const authRoute = require('./auth');
const configRoute = require('./configuration');
const mediaRoute = require('./media');
const productRoute = require('./product');

route.use('/auth', authRoute);

route.use('/config', configRoute);

route.use('/media', mediaRoute);

route.use('/product', productRoute);

module.exports = route;