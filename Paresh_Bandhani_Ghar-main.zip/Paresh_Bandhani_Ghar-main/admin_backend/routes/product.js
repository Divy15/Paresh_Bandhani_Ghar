const express = require('express');
const route = express.Router();
const { celebrate, Segments } = require('celebrate');
const productCtrl = require('../controllers/product');
const productValidation = require('../validation/product');

route.route('/store-product-category-subcategory')
    .post(
        celebrate(productValidation.store_product_category_subcategory),
        productCtrl.store_product_category_subcategory
    );

route.route('/generate-batch-presigned-urls')
    .post(
        celebrate(productValidation.generate_batch_presigned_urls),
        productCtrl.generate_batch_presigned_urls
    );

route.route('/confirm-and-save-product-media')
    .post(
        celebrate(productValidation.confirm_and_save_product_media),
        productCtrl.confirm_and_save_product_media
    );

route.route('/update-products-batch-controller')
    .post(
        celebrate(productValidation.update_products_batch),
        productCtrl.update_products_batch_controller
    );

route.route('/store-product-matrix')
    .post(
        celebrate(productValidation.update_product_matrix_bulk),
        productCtrl.store_product_matrix
    );

route.route('/update-product-description-bulk')
    .post(
        celebrate(productValidation.update_product_description_bulk),
        productCtrl.updateProductDescriptionsBulk
    );

route.route('/get-products-and-refresh-media')
    .get(
        celebrate(productValidation.get_products_and_refresh_media),
        productCtrl.get_products_and_refresh_media
    );

module.exports = route;