const express = require('express');
const route = express.Router();
const { celebrate, Segments } = require('celebrate');

module.exports = route;