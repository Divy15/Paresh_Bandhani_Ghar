import { type InternalAxiosRequestConfig, type AxiosResponse, AxiosError } from 'axios';

// Handles operations BEFORE a request hits the network
export const requestInterceptor = (config: InternalAxiosRequestConfig): InternalAxiosRequestConfig => {
  // Pull your session token from wherever you store it safely (localStorage, cookies, Zustand, etc.)
  const token = localStorage.getItem('pbg_auth_token');
  
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  
  return config;
};

export const requestErrorInterceptor = (error: AxiosError): Promise<never> => {
  return Promise.reject(error);
};

// Handles data structures or global catch states AFTER receiving responses
export const responseInterceptor = (response: AxiosResponse): AxiosResponse => {
  // If your server wraps standard returns in a payload shell (e.g. { data: {...} }), you can parse it globally here
  return response;
};

export const responseErrorInterceptor = (error: AxiosError): Promise<never> => {
  // Centralized Error Catching System
  if (error.response) {
    const { status } = error.response;

    switch (status) {
      case 401:
        // Handle Session Expired states (Clear storage, redirect to login screen)
        localStorage.clear();
        window.location.href = '/login';
        break;
      case 403:
        console.error('Permission Denied.');
        break;
      case 500:
        console.error('Internal System Crash. Please try again later.');
        break;
      default:
        console.error(`API Exception Details: ${error.message}`);
    }
  }

  return Promise.reject(error);
};