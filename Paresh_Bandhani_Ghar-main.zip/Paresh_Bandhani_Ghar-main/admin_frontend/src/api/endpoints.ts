export const ApiObject = {
  Auth: {
    mobileNoValid: "/auth/login",
    verifyOtp: "/auth/verify/otp",
  },
  Configuration: {
    storeCategory: "/config/store/category",
    updateCategory: "/config/update/category",
    getCategories: "/config/get/categories",
    deleteCategory: "/config/delete/category",
    storeSubCategory: "/config/store/subcategory",
    updateSubCategory: "/config/update/subcategory",
    getSubCategories: "/config/get/subcategories",
    deleteSubCategory: "/config/delete/subcategory",
    storeMaterial: "/config/store/material",
    deleteMaterial: "/config/delete/material",
    getMaterials: "/config/get/materials",
    storeStructure: "/config/store/structure",
    updateStructure: "/config/update/structure",
    getStructures: "/config/get/structures",
    deleteStructure: "/config/delete/structure",
  },
  Media: {
    uploadFile: "/media/upload/file",
    getPresignedUrl: "/media/get/presigned/url"
  }
};