export const ApiObject = {
  Auth: {
    mobileNoValid: "/auth/login",
    verifyOtp: "/auth/verify/otp",
  },
  Catalog: {
    getProducts: "/products",
    createProduct: "/products/new",
    deleteProduct: (id: string) => `/products/${id}`, // Dynamic route helper example
  },
};