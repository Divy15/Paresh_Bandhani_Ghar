import axios from 'axios';
import { 
  requestInterceptor, 
  requestErrorInterceptor, 
  responseInterceptor, 
  responseErrorInterceptor 
} from './interceptors';

// Build custom reusable instance configurations
export const apiClient = axios.create({
  baseURL: "http://localhost:3000/api",
  timeout: 15000, // Safe default: 15 seconds
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// Bind interceptor handlers
apiClient.interceptors.request.use(requestInterceptor, requestErrorInterceptor);
apiClient.interceptors.response.use(responseInterceptor, responseErrorInterceptor);