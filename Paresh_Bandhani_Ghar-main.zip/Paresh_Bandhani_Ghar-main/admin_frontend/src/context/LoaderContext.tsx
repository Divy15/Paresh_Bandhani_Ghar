import React, { createContext, useContext, useState, type ReactNode } from 'react';

interface LoaderContextType {
  showLoader: () => void;
  hideLoader: () => void;
  isLoading: boolean;
}

const LoaderContext = createContext<LoaderContextType | undefined>(undefined);

// --- THE TRADITIONAL HANDLOOM/TEXTILE INSPIRED LOADER UI ---
export const AestheticLoader: React.FC<{ size?: 'sm' | 'lg' }> = ({ size = 'lg' }) => {
  const isLarge = size === 'lg';
  return (
    <div className="flex flex-col items-center justify-center gap-4">
      <div className="relative flex items-center justify-center">
        {/* Outer Ring: Simulating a spinning wooden embroidery hoop or textile wheel */}
        <div className={`animate-spin rounded-full border-2 border-dashed border-amber-600/30 border-t-amber-700 ${isLarge ? 'h-16 w-16' : 'h-10 w-10'}`}></div>
        
        {/* Inner Core: A pulsing tie-dye node ring characteristic of Bandhani patterns */}
        <div className={`absolute animate-ping rounded-full bg-rose-700/20 ${isLarge ? 'h-8 w-8' : 'h-5 w-5'}`}></div>
        <div className={`absolute rounded-full bg-rose-600 shadow-sm shadow-rose-900/50 ${isLarge ? 'h-4 w-4' : 'h-2.5 w-2.5'}`}></div>
      </div>
      {isLarge && (
        <p className="text-xs font-medium tracking-widest text-amber-900/60 uppercase animate-pulse font-serif">
          Weaving Layout...
        </p>
      )}
    </div>
  );
};

export const LoaderProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(false);

  const showLoader = () => setIsLoading(true);
  const hideLoader = () => setIsLoading(false);

  return (
    <LoaderContext.Provider value={{ showLoader, hideLoader, isLoading }}>
      {children}
      
      {/* FULL PAGE OVERLAY */}
      {isLoading && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-stone-100/70 backdrop-blur-[2px]">
          <div className="rounded-2xl bg-white p-8 shadow-xl shadow-stone-200 border border-stone-100">
            <AestheticLoader size="lg" />
          </div>
        </div>
      )}
    </LoaderContext.Provider>
  );
};

export const useLoader = () => {
  const context = useContext(LoaderContext);
  if (!context) throw new Error('useLoader must be used within a LoaderProvider');
  return context;
};

// --- COMPONENT LEVEL LOADER MASK ---
// Wrap any micro layout panel with this to freeze and mask it locally!
interface BlockLoaderProps {
  isLoading: boolean;
  children: ReactNode;
  className?: string;
}

export const BlockLoader: React.FC<BlockLoaderProps> = ({ isLoading, children, className = "" }) => {
  return (
    <div className={`relative ${className}`}>
      {children}
      {isLoading && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-white/60 rounded-xl backdrop-blur-[1px] transition-all">
          <AestheticLoader size="sm" />
        </div>
      )}
    </div>
  );
};