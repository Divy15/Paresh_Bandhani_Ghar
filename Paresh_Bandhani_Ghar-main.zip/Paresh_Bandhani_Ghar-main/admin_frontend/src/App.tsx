import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { LoginPage } from './pages/login.page';
import { DashboardPage } from './pages/dashboard.page';
import { ProductRegistrationPage } from './pages/product.page';
import { ConfigurationPage } from './pages/configuration.page'; 
import { Navbar } from './components/navbar/Navbar';
import { Toaster } from 'react-hot-toast'; // 1. IMPORT TOASTER HERE

function App() {
  const { isAuthenticated } = useAuth();

  return (
    <BrowserRouter>
      {/* 2. PLACE TOASTER AT THE ROOT LEVEL */}
      {/* You can style it to fit your Bandhani aesthetics using toastOptions */}
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#ffffff',
            color: '#1c1917', // stone-900
            border: '1px solid #e7e5e4', // stone-200
            fontSize: '14px',
          },
          success: {
            iconTheme: {
              primary: '#9b1c1c', // Your brand maroon color
              secondary: '#ffffff',
            },
          },
        }}
      />

      <div className="min-h-screen bg-bg-main text-text-main flex flex-col">
        <Navbar />
        
        <main className="flex-1">
          <Routes>
            {/* Public Route */}
            <Route 
              path="/login" 
              element={!isAuthenticated ? <LoginPage /> : <Navigate to="/dashboard" replace />} 
            />

            {/* Protected Routes */}
            <Route 
              path="/dashboard" 
              element={isAuthenticated ? <DashboardPage /> : <Navigate to="/login" replace />} 
            />
            <Route 
              path="/products" 
              element={isAuthenticated ? <ProductRegistrationPage /> : <Navigate to="/login" replace />} 
            />
            <Route 
              path="/configuration" 
              element={isAuthenticated ? <ConfigurationPage /> : <Navigate to="/login" replace />} 
            />
            <Route 
              path="/billing" 
              element={isAuthenticated ? <div className="p-6">Billing Page (Coming Soon)</div> : <Navigate to="/login" replace />} 
            />
            <Route 
              path="/returns" 
              element={isAuthenticated ? <div className="p-6">Return Product (Coming Soon)</div> : <Navigate to="/login" replace />} 
            />

            {/* Fallback Catch-All Route */}
            <Route 
              path="*" 
              element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} 
            />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;