import React from 'react';

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  showPointsPreview?: boolean;
}

export const TextArea: React.FC<TextAreaProps> = ({
  label,
  showPointsPreview = false,
  className = '',
  value = '',
  ...props
}) => {
  // Parse the textarea value into clean, separate points for a live list preview
  const points = String(value)
    .split('\n')
    .map(point => point.trim())
    .filter(point => point.length > 0);

  return (
    <div className="flex flex-col gap-1.5 w-full">
      <div className="flex justify-between items-center">
        <label className="text-sm font-medium text-text-main">{label}</label>
        {showPointsPreview && points.length > 0 && (
          <span className="text-xs font-mono text-brand-maroon-500 bg-brand-maroon-500/5 px-2 py-0.5 rounded-md">
            {points.length} {points.length === 1 ? 'point' : 'points'} detected
          </span>
        )}
      </div>

      <textarea
        className={`px-3 py-2 rounded-lg border border-border-main bg-bg-main text-text-main focus:outline-none focus:border-brand-maroon-500 transition-colors disabled:opacity-60 min-h-[100px] resize-y text-sm ${className}`}
        value={value}
        {...props}
      />

      {/* Point-wise Live Preview Render Block */}
      {showPointsPreview && points.length > 0 && (
        <div className="mt-2 p-3 bg-bg-main/40 border border-border-main/40 rounded-lg animate-fade-in">
          <p className="text-[11px] font-mono font-bold uppercase tracking-wider text-text-muted mb-2">Live Point-Wise Preview:</p>
          <ul className="list-disc list-inside space-y-1 text-xs text-text-muted pl-1">
            {points.map((point, index) => (
              <li key={index} className="leading-relaxed">
                <span className="text-text-main">{point}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};