import React from 'react';
import { type Product } from '../../components/product/productList/ProductList.types';

interface ProductCardProps {
  product: Product;
  onViewClick: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onViewClick }) => {
  return (
    <div className="group relative flex flex-col rounded-2xl overflow-hidden border border-[var(--border-main)] bg-[var(--bg-card)] transition-all duration-300 hover:shadow-lg hover:border-[var(--color-brand-maroon-500)]/30">
      
      {/* 1. Myntra-style Portrait Image Frame */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-zinc-100 dark:bg-zinc-800">
        <img 
          src={product.imageUrl || `https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=600&q=80`} 
          alt={product.name} 
          className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />
        
        {/* Floating Traditional Status Tag */}
        <div className="absolute top-3 left-3">
          <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider shadow-sm ${
            product.productStatus === 'Online' 
              ? 'bg-emerald-500 text-white' 
              : product.productStatus === 'Offline' 
              ? 'bg-amber-500 text-white' 
              : 'bg-zinc-500 text-white'
          }`}>
            {product.productStatus}
          </span>
        </div>
      </div>

      {/* 2. Content Details Section */}
      <div className="flex flex-col flex-1 p-4">
        {/* Category Label */}
        <span className="text-[11px] font-bold tracking-widest text-[var(--color-brand-gold-500)] uppercase">
          {product.categoryName || "Traditional Wear"}
        </span>

        {/* Product Identity Title */}
        <h3 className="mt-1 text-sm font-semibold text-[var(--text-main)] line-clamp-1 group-hover:text-[var(--color-brand-maroon-500)] transition-colors">
          {product.name}
        </h3>

        {/* Catalog / Unique Identity Tag */}
        <span className="mt-1 text-[11px] font-mono text-[var(--text-muted)]">
          ID: {product.id}
        </span>

        {/* Pricing & Stock Grid */}
        <div className="mt-3 flex items-baseline justify-between border-t border-[var(--border-main)] pt-3">
          <div>
            <span className="text-base font-bold text-[var(--text-main)]">
              {product.price}
            </span>
          </div>
          <span className="text-xs text-[var(--text-muted)]">
            {product.stock > 0 ? `${product.stock} left` : 'Out of Stock'}
          </span>
        </div>

        {/* 3. Integrated Action Button */}
        <button
          onClick={() => onViewClick(product)}
          className="mt-4 w-full rounded-xl bg-[var(--color-brand-maroon-500)] hover:bg-[var(--color-brand-maroon-600)] text-white text-xs font-bold py-2.5 tracking-wide transition-all duration-200 active:scale-95 shadow-sm hover:shadow-md"
        >
          View Name
        </button>
      </div>
    </div>
  );
};