import React from 'react';

interface Product {
  id: string;
  name: string;
  stock: number;
  price: string;
  imageUrl?: string; // Added to support product images
}

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  // Fallback image using a structural placeholder if no imageUrl is present
  const fallbackImage = `https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=300&q=80`;

  return (
    <div className="flex bg-bg-card border border-border-main rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow h-32">
      {/* Rectangular Image Block */}
      <div className="w-32 h-full bg-bg-main relative shrink-0 border-r border-border-main">
        <img 
          src={product.imageUrl || fallbackImage} 
          alt={product.name}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Structured Copy Area */}
      <div className="flex flex-col justify-between p-3 flex-1 min-w-0">
        <div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-mono font-bold text-brand-maroon-500 bg-brand-maroon-500/10 px-1.5 py-0.5 rounded truncate">
              {product.id}
            </span>
            <span className="text-xs text-text-muted font-semibold bg-bg-main px-2 py-0.5 rounded border border-border-main shrink-0">
              {product.stock} units
            </span>
          </div>
          <h4 className="font-medium text-text-main text-sm mt-1.5 truncate line-clamp-2 leading-tight">
            {product.name}
          </h4>
        </div>
        
        <div className="flex justify-end items-end pt-1">
          <span className="text-base font-bold text-text-main font-mono">
            {product.price}
          </span>
        </div>
      </div>
    </div>
  );
};