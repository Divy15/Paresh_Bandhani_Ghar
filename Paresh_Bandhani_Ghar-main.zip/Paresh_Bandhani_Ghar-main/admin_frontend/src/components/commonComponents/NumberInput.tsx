import React from 'react';

interface NumberInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

export const NumberInput: React.FC<NumberInputProps> = ({
  label,
  value,
  onChange,
  error,
  className = '',
  ...props
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;

    /* 
       Regex Breakdown:
       - inputValue === '' : Allows backspacing the entire field
       - inputValue === '.' : Allows typing a lone decimal point first (e.g., .5)
       - /^\d*\.?\d*$/ : Allows optional digits, followed by an optional single decimal point, followed by optional digits
    */
    if (inputValue === '' || inputValue === '.' || /^\d*\.?\d*$/.test(inputValue)) {
      onChange(inputValue);
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const pastedData = e.clipboardData.getData('text');
    // Block paste if it's not a valid integer or decimal format
    if (!/^\d*\.?\d*$/.test(pastedData)) {
      e.preventDefault();
    }
  };

  return (
    <div className="flex flex-col gap-1.5 w-full">
      {label && (
        <label className="text-sm font-medium text-text-main">
          {label}
        </label>
      )}
      <input
        type="text"
        inputMode="decimal" // Changing this to "decimal" brings up the mobile keyboard with the "." key
        pattern="[0-9]*\.?[0-9]*"
        value={value}
        onChange={handleChange}
        onPaste={handlePaste}
        className={`px-3 py-2 rounded-lg border border-border-main bg-bg-main text-text-main focus:outline-none focus:border-brand-maroon-500 transition-colors ${
          error ? 'border-red-500 focus:border-red-500' : ''
        } ${className}`}
        {...props}
      />
      {error && (
        <span className="text-xs font-medium text-red-500 mt-0.5">
          {error}
        </span>
      )}
    </div>
  );
};