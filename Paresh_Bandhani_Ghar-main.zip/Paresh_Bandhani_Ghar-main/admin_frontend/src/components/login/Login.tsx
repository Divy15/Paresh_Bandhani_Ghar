import React, { useState } from "react";
import { OtpInput } from "../commonComponents/OtpInput";
import { motion } from "motion/react";
import { NumberInput } from "../commonComponents/NumberInput";

interface LoginFormProps {
  step: "phone" | "otp";
  phoneNumber: string;
  onPhoneSubmit: (phone: string) => void;
  onOtpSubmit: (otp: string) => void;
  onBackToPhone: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({
  step,
  phoneNumber,
  onPhoneSubmit,
  onOtpSubmit,
  onBackToPhone,
}) => {
  const [phoneInput, setPhoneInput] = useState("");

  const submitPhone = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneInput.length === 10) {
      onPhoneSubmit(phoneInput);
    }
  };

  if (step === "phone") {
    return (
      <motion.form
        key="phone-step"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 20 }}
        onSubmit={submitPhone}
        className="space-y-6"
      >
        <div>
          {/* The relative container should wrap ONLY the input and its overlay badge, NOT the label */}
          <div className="flex flex-col gap-1.5 w-full">
            <label className="text-sm font-medium text-text-muted">
              Registered Mobile Number
            </label>

            <div className="relative rounded-lg shadow-sm">
              {/* Country code overlay prefix - now perfectly centered vertically over the input field */}
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-text-muted text-sm font-semibold z-10 pointer-events-none">
                +91
              </span>

              <NumberInput
                required
                maxLength={10}
                placeholder="Enter 10-digit mobile"
                value={phoneInput}
                onChange={(value) => setPhoneInput(value.replace(/\D/g, ""))}
                inputMode="numeric"
                pattern="[0-9]{10}"
                /* 
          1. Removed the 'label' prop from here so it doesn't render internally.
          2. Kept pl-12 so your typing text starts nicely after the +91.
        */
                className="pl-12 pr-4 py-3 w-full bg-bg-main border border-border-main text-text-main rounded-lg outline-none focus:ring-1 focus:ring-brand-maroon-500 focus:border-brand-maroon-500 transition-all"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={phoneInput.length !== 10}
          className="w-full py-3 bg-brand-maroon-500 hover:bg-brand-maroon-600 disabled:bg-brand-maroon-500/50 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-md transition-colors"
        >
          Send Verification Code
        </button>
      </motion.form>
    );
  }

  return (
    <motion.div
      key="otp-step"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-6"
    >
      <div className="text-center">
        <p className="text-sm text-text-muted">
          Enter code delivered to{" "}
          <strong className="text-text-main">+91 {phoneNumber}</strong>
        </p>
      </div>

      <OtpInput length={6} onComplete={onOtpSubmit} />

      <div className="text-center mt-4">
        <button
          onClick={onBackToPhone}
          className="text-xs font-semibold text-brand-gold-500 hover:underline cursor-pointer"
        >
          Change Phone Number
        </button>
      </div>
    </motion.div>
  );
};
