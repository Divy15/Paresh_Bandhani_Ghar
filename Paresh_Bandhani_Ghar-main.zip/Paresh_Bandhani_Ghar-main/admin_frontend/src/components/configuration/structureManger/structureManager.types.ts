export interface StructureConfig {
  id: string;
  productName: string; 
  components: string[]; 
}

export interface StructureViewProps {
  structures: StructureConfig[];
  filteredStructures: StructureConfig[];
  productName: string;
  setProductName: (value: string) => void;
  componentInput: string;
  setComponentInput: (value: string) => void;
  currentComponentList: string[];
  setCurrentComponentList: (components: string[]) => void;
  editingId: string | null;
  filterStructureId: string | null;
  setFilterStructureId: (id: string | null) => void;
  dropdownOptions: { value: string; label: string }[];
  addComponentTag: () => void;
  saveStructure: () => void;
  startEdit: (struct: StructureConfig) => void;
  cancelEdit: () => void;
  handleDelete: (id: string) => void;
}