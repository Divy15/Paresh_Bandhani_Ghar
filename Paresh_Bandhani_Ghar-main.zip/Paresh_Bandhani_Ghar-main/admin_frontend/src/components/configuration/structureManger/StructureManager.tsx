import React, { useState } from 'react';
import { type StructureConfig } from './structureManager.types';
import { StructureDesktopView } from './structureDesktopView';
import { StructureMobileView } from './structureMobileView';

export const StructureManager: React.FC = () => {
  const [structures, setStructures] = useState<StructureConfig[]>([
    { id: '1', productName: 'Dress', components: ['Top', 'Bottom', 'Dupatta'] },
    { id: '2', productName: 'Saree Set', components: ['Saree', 'Blouse Piece'] },
  ]);

  const [productName, setProductName] = useState('');
  const [componentInput, setComponentInput] = useState('');
  const [currentComponentList, setCurrentComponentList] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterStructureId, setFilterStructureId] = useState<string | null>(null);

  const addComponentTag = () => {
    if (componentInput.trim() && !currentComponentList.includes(componentInput.trim())) {
      setCurrentComponentList([...currentComponentList, componentInput.trim()]);
      setComponentInput('');
    }
  };

  const saveStructure = () => {
    if (!productName.trim() || currentComponentList.length === 0) return;

    if (editingId) {
      setStructures(
        structures.map((struct) =>
          struct.id === editingId
            ? { ...struct, productName: productName.trim(), components: currentComponentList }
            : struct
        )
      );
      setEditingId(null);
    } else {
      setStructures([
        ...structures,
        {
          id: Date.now().toString(),
          productName: productName.trim(),
          components: currentComponentList,
        },
      ]);
    }
    setProductName('');
    setCurrentComponentList([]);
  };

  const startEdit = (struct: StructureConfig) => {
    setEditingId(struct.id);
    setProductName(struct.productName);
    setCurrentComponentList(struct.components);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setProductName('');
    setCurrentComponentList([]);
  };

  const dropdownOptions = structures.map((struct) => ({
    value: struct.id,
    label: struct.productName,
  }));

  const filteredStructures = filterStructureId
    ? structures.filter((struct) => struct.id === filterStructureId)
    : structures;

  const sharedProps = {
    structures,
    filteredStructures,
    productName,
    setProductName,
    componentInput,
    setComponentInput,
    currentComponentList,
    setCurrentComponentList,
    editingId,
    filterStructureId,
    setFilterStructureId,
    dropdownOptions,
    addComponentTag,
    saveStructure,
    startEdit,
    cancelEdit,
    handleDelete: (id: string) => {
      setStructures(structures.filter((s) => s.id !== id));
      if (editingId === id) cancelEdit();
      if (filterStructureId === id) setFilterStructureId(null);
    },
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <h2 className="text-xl font-bold mb-1">Product Component Structure Configuration</h2>
      <p className="text-sm text-text-muted mb-6">Define bundled package items (e.g., Dress = Top + Bottom + Dupatta).</p>

      {/* RENDER FOR TABLETS & MOBILES (< 1024px) */}
      <div className="block lg:hidden">
        <StructureMobileView {...sharedProps} />
      </div>

      {/* RENDER FOR DESKTOPS (>= 1024px) */}
      <div className="hidden lg:block">
        <StructureDesktopView {...sharedProps} />
      </div>
    </div>
  );
};