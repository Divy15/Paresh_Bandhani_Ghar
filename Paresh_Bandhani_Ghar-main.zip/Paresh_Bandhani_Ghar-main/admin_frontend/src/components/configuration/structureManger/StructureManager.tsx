import React, { useState, useEffect } from 'react';
import { type StructureConfig } from './structureManager.types';
import { StructureDesktopView } from './structureDesktopView';
import { StructureMobileView } from './structureMobileView';
import { useLoader } from '../../../context/LoaderContext'; 
import { toast } from 'react-hot-toast'; 
import {
  storeStructure,
  getStructures,
  deleteStructure,
  updateStructure,
} from '../../../service/Configuration.service';

export const StructureManager: React.FC = () => {
  const { showLoader, hideLoader } = useLoader();
  const [structures, setStructures] = useState<StructureConfig[]>([]);

  const [productName, setProductName] = useState('');
  const [componentInput, setComponentInput] = useState('');
  const [currentComponentList, setCurrentComponentList] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterStructureId, setFilterStructureId] = useState<string | null>(null);

  // 1. GET ALL STRUCTURES (Quiet on success, toaster on error)
  
  const fetchAllStructures = async (searchStr: string = '') => {
    showLoader();
    try {
      const response = await getStructures(searchStr);
      const rawData = response?.data || response || [];
      
      const mappedData: StructureConfig[] = rawData.map((item: any) => {
        // Unpack jsonb object array back to a simple string list for UI display
        let componentsArray: string[] = [];
        if (Array.isArray(item.includes)) {
          componentsArray = item.includes.map((inc: any) => 
            typeof inc === 'object' && inc !== null ? inc.product : String(inc)
          );
        }

        return {
          id: String(item.id),
          productName: item.main_name || '',
          components: componentsArray,
        };
      });

      setStructures(mappedData);
    } catch (error: any) {
      toast.error(error || 'Failed to sync component configuration list');
    } finally {
      hideLoader();
    }
  };

  // Sync with backend on component mount
  useEffect(() => {
    fetchAllStructures();
  }, []);

  const addComponentTag = () => {
    if (componentInput.trim() && !currentComponentList.includes(componentInput.trim())) {
      setCurrentComponentList([...currentComponentList, componentInput.trim()]);
      setComponentInput('');
    }
  };

  // 2. STORE & UPDATE (Toaster on success & error)
  const saveStructure = async () => {
    if (!productName.trim()) {
      toast.error('Product title cannot be empty');
      return;
    }
    if (currentComponentList.length === 0) {
      toast.error('Please assign at least one component element tag');
      return;
    }

    // Transform string array ["Saree", "Blouse"] into object array [{ product: "Saree" }, { product: "Blouse" }]
    const formattedIncludes = currentComponentList.map(item => ({
      product: item
    }));

    showLoader();
    try {
      if (editingId) {
        // Update operational branch
        await updateStructure({
          id: Number(editingId),
          mainName: productName.trim(),
          includes: formattedIncludes as any, // Now satisfies Joi validation!
        });
        toast.success('🎉 Layout specifications modified successfully!');
      } else {
        // Insert operational branch
        await storeStructure({
          mainName: productName.trim(),
          includes: formattedIncludes as any, // Now satisfies Joi validation!
        });
        toast.success('✨ New bundle structural matrix registered!');
      }

      // Reset configurations and synchronize
      setEditingId(null);
      setProductName('');
      setCurrentComponentList([]);
      fetchAllStructures();
    } catch (error: any) {
      toast.error(error || 'Failed to submit structural layout configurations');
    } finally {
      hideLoader();
    }
  };

  const startEdit = (struct: StructureConfig) => {
    setEditingId(struct.id);
    setProductName(struct.productName);
    setCurrentComponentList(struct.components);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setProductName('');
    setCurrentComponentList([]);
  };

  // 3. DELETE ROUTE (Toaster on success & error)
  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to completely erase this mapping layout structure?')) return;

    showLoader();
    try {
      await deleteStructure({ id });
      toast.success('Deleted item mapping entry');
      
      if (editingId === id) cancelEdit();
      if (filterStructureId === id) setFilterStructureId(null);
      
      fetchAllStructures(); // Refresh table view data matrix 
    } catch (error: any) {
      toast.error(error || 'Unable to drop structure blueprint mapping');
    } finally {
      hideLoader();
    }
  };

  const dropdownOptions = structures.map((struct) => ({
    value: struct.id,
    label: struct.productName,
  }));

  const filteredStructures = filterStructureId
    ? structures.filter((struct) => struct.id === filterStructureId)
    : structures;

  const sharedProps = {
    structures,
    filteredStructures,
    productName,
    setProductName,
    componentInput,
    setComponentInput,
    currentComponentList,
    setCurrentComponentList,
    editingId,
    filterStructureId,
    setFilterStructureId,
    dropdownOptions,
    addComponentTag,
    saveStructure,
    startEdit,
    cancelEdit,
    handleDelete,
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <h2 className="text-xl font-bold mb-1">Product Component Structure Configuration</h2>
      <p className="text-sm text-text-muted mb-6">Define bundled package items (e.g., Dress = Top + Bottom + Dupatta).</p>

      {/* RENDER FOR TABLETS & MOBILES (< 1024px) */}
      <div className="block lg:hidden">
        <StructureMobileView {...sharedProps} />
      </div>

      {/* RENDER FOR DESKTOPS (>= 1024px) */}
      <div className="hidden lg:block">
        <StructureDesktopView {...sharedProps} />
      </div>
    </div>
  );
};