import React, { useState, useEffect } from 'react';
import { Input } from '../../commonComponents/Input';
import { FilterSearchDropdown } from '../../commonComponents/FilterSearchDropdown';
import { Trash2, Edit2, Check, X, Filter, Plus, FileText, List } from 'lucide-react';
import { type StructureViewProps } from './structureManager.types';

export const StructureMobileView: React.FC<StructureViewProps> = ({
  filteredStructures,
  productName,
  setProductName,
  componentInput,
  setComponentInput,
  currentComponentList,
  setCurrentComponentList,
  editingId,
  filterStructureId,
  setFilterStructureId,
  dropdownOptions,
  addComponentTag,
  saveStructure,
  startEdit,
  cancelEdit,
  handleDelete,
}) => {
  const [activeTab, setActiveTab] = useState<'form' | 'list'>('form');

  // Direct workspace bounce switch to form workspace panel when an item edit begins
  useEffect(() => {
    if (editingId) {
      setActiveTab('form');
    }
  }, [editingId]);

  return (
    <div className="flex flex-col gap-4">
      {/* Upper View Segmented Toggle Controller */}
      <div className="flex p-1 bg-bg-main/60 rounded-xl border border-border-main">
        <button
          type="button"
          onClick={() => setActiveTab('form')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'form'
              ? 'bg-white text-brand-maroon-500 shadow-sm border border-border-main/40'
              : 'text-text-muted hover:text-text-main'
          }`}
        >
          <FileText className="w-4 h-4" />
          {editingId ? 'Modify Template' : 'Add Structure'}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('list')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'list'
              ? 'bg-white text-brand-maroon-500 shadow-sm border border-border-main/40'
              : 'text-text-muted hover:text-text-main'
          }`}
        >
          <List className="w-4 h-4" />
          <span>View Lists ({filteredStructures.length})</span>
        </button>
      </div>

      {/* Workspace Display Layer */}
      {activeTab === 'form' ? (
        <div className="bg-bg-main/20 p-3 rounded-xl border border-border-main flex flex-col gap-4">
          <Input 
            label={editingId ? "Update Product Model Name" : "Main Product Model Name"} 
            placeholder="e.g., Lehenga Choli" 
            value={productName} 
            onChange={(e) => setProductName(e.target.value)} 
          />
          
          <div className="flex gap-2 items-end">
            <div className="flex-1">
              <Input 
                label="Add Component Item Name" 
                placeholder="e.g., Dupatta" 
                value={componentInput} 
                onChange={(e) => setComponentInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addComponentTag()}
              />
            </div>
            <button 
              onClick={addComponentTag} 
              type="button" 
              className="p-2.5 bg-bg-main text-text-main border border-border-main rounded-lg h-10.5 text-xs font-medium"
            >
              Include
            </button>
          </div>

          {currentComponentList.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {currentComponentList.map(comp => (
                <span key={comp} className="text-[11px] bg-brand-maroon-500/10 text-brand-maroon-500 px-2 py-0.5 rounded-full font-medium flex items-center gap-1 border border-brand-maroon-500/20">
                  {comp}
                  <button 
                    type="button" 
                    onClick={() => setCurrentComponentList(currentComponentList.filter(c => c !== comp))} 
                    className="hover:text-red-500 font-bold"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <button 
              onClick={() => {
                saveStructure();
                setActiveTab('list');
              }} 
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-brand-maroon-500 text-white rounded-lg text-xs font-semibold shadow-sm"
            >
              {editingId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {editingId ? 'Update Template' : 'Save Configuration'}
            </button>
            {editingId && (
              <button 
                onClick={cancelEdit} 
                className="px-4 py-3 border border-border-main rounded-lg text-xs font-medium text-text-muted bg-bg-card"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {/* Active Dropdown Filter Panel */}
          <div className="bg-bg-main/50 p-3 rounded-xl border border-border-main">
            <div className="flex items-center gap-2 mb-2 text-[11px] font-bold uppercase tracking-wider text-text-muted">
              <Filter className="w-3 h-3 text-brand-maroon-500" />
              <span>Search Structures</span>
            </div>
            <FilterSearchDropdown
              placeholder="All Product Structures"
              options={dropdownOptions}
              selectedValue={filterStructureId}
              onSelect={setFilterStructureId}
            />
          </div>

          {/* Core Layout Data Cards Container Stack */}
          <div className="flex flex-col gap-3">
            {filteredStructures.length > 0 ? (
              filteredStructures.map((struct) => (
                <div key={struct.id} className="p-3 border border-border-main bg-bg-main/20 rounded-xl flex items-center justify-between">
                  <div className="min-w-0 flex-1 pr-2">
                    <h4 className="font-bold text-xs text-text-main truncate">{struct.productName}</h4>
                    <p className="text-[11px] text-text-muted mt-0.5 line-clamp-2">
                      Consists of: <span className="font-medium text-brand-maroon-500">{struct.components.join(' + ')}</span>
                    </p>
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <button 
                      onClick={() => startEdit(struct)} 
                      className="p-2 bg-bg-card border border-border-main rounded-lg text-text-muted hover:text-brand-maroon-500"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={() => handleDelete(struct.id)} 
                      className="p-2 bg-bg-card border border-border-main rounded-lg text-text-muted hover:text-red-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-xs text-text-muted border border-dashed border-border-main bg-bg-card rounded-xl">
                No configurations found.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};