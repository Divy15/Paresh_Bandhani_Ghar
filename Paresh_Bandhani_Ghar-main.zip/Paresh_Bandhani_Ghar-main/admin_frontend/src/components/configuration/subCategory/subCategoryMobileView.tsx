import React, { useState, useEffect } from 'react';
import { Input } from '../../commonComponents/Input';
import { FileUpload } from '../../commonComponents/FileUpload';
import { Select } from '../../commonComponents/Select';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';
import { FilterSearchDropdown } from '../../commonComponents/FilterSearchDropdown';
import { Trash2, Edit2, Plus, Check, X, Filter, List, FileText } from 'lucide-react';
import { type SubCategoryViewProps } from './subCategoryManager.types';

export const SubCategoryMobileView: React.FC<SubCategoryViewProps> = ({
  categories,
  subCategories,
  selectedCategory,
  setSelectedCategory,
  name,
  setName,
  editingId,
  filterCategory,
  setFilterCategory,
  selectedFile,
  imagePreview,
  srcImage,
  handleFileUpload,
  handleCropComplete,
  handleCancelCrop,
  clearImageSelection,
  handleSave,
  startEdit,
  handleCancelEdit,
  handleDelete,
}) => {
  // Local state to toggle between Form screen or List screen
  const [activeTab, setActiveTab] = useState<'form' | 'list'>('form');

  // Auto-switch to form view whenever the user enters edit mode
  useEffect(() => {
    if (editingId) {
      setActiveTab('form');
    }
  }, [editingId]);

  const filteredSubCategories = !filterCategory
    ? subCategories
    : subCategories.filter(sub => sub.categoryId === filterCategory);

  return (
    <>
      {/* Upper View Toggle Controller */}
      <div className="flex p-1 bg-bg-main/60 rounded-xl border border-border-main">
        <button
          onClick={() => setActiveTab('form')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'form'
              ? 'bg-white text-brand-maroon-500 shadow-sm border border-border-main/40'
              : 'text-text-muted hover:text-text-main'
          }`}
        >
          <FileText className="w-4 h-4" />
          {editingId ? 'Modify Layout' : 'Add Sub-Category'}
        </button>
        <button
          onClick={() => setActiveTab('list')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'list'
              ? 'bg-white text-brand-maroon-500 shadow-sm border border-border-main/40'
              : 'text-text-muted hover:text-text-main'
          }`}
        >
          <List className="w-4 h-4" />
          <span>View Mappings ({filteredSubCategories.length})</span>
        </button>
      </div>

      {/* Conditional Workspace Rendering */}
      {activeTab === 'form' ? (
        /* --- FORM VIEW PANEL --- */
        <div className="flex flex-col gap-4 bg-bg-main/20 p-3 rounded-xl border border-border-main/60 animate-fadeIn">
          <Select 
            label="Parent Category" 
            options={categories} 
            value={selectedCategory} 
            onChange={(e) => setSelectedCategory(e.target.value)} 
          />
          <Input 
            label="Sub-Category Name" 
            placeholder="e.g., Banarasi" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
          />
          
          <FileUpload label="Icon Art Cover" onChange={handleFileUpload} multiple={false} />
          
          {imagePreview && (
            <div className="flex items-center justify-between p-2 border border-dashed border-border-main rounded-lg bg-bg-card">
              <div className="flex items-center gap-2">
                <img src={imagePreview} alt="preview" className="w-10 h-10 rounded-full object-cover border border-brand-maroon-500" />
                <p className="text-[11px] text-text-muted truncate max-w-[160px]">{selectedFile}</p>
              </div>
              <button onClick={clearImageSelection} className="p-1 text-text-muted hover:text-red-500">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="flex gap-2 w-full pt-2">
            <button 
              onClick={() => {
                handleSave();
                // Optional: bounce them back to the list layout after completing a clean insert/update
                setActiveTab('list');
              }} 
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-brand-maroon-500 text-white rounded-lg text-xs font-semibold shadow-sm hover:bg-brand-maroon-600 active:scale-[0.99] transition-all"
            >
              {editingId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {editingId ? 'Update Variant' : 'Map Item'}
            </button>
            {editingId && (
              <button 
                onClick={handleCancelEdit} 
                className="px-4 py-3 border border-border-main rounded-lg text-xs font-medium text-text-muted bg-bg-card"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      ) : (
        /* --- LIST VIEW PANEL --- */
        <div className="flex flex-col gap-4 animate-fadeIn">
          {/* Workspace Filter Dropdown */}
          <div className="bg-bg-main/50 p-3 rounded-xl border border-border-main">
            <div className="flex items-center gap-2 mb-2 text-[11px] font-bold uppercase tracking-wider text-text-muted">
              <Filter className="w-3 h-3 text-brand-maroon-500" />
              <span>Scope Mappings View</span>
            </div>
            <FilterSearchDropdown 
              placeholder="Showing All Categories" 
              options={categories} 
              selectedValue={filterCategory} 
              onSelect={setFilterCategory} 
            />
          </div>

          {/* Cards Stack */}
          <div className="flex flex-col gap-3">
            {filteredSubCategories.length > 0 ? (
              filteredSubCategories.map((sub) => (
                <div key={sub.id} className="flex items-center justify-between p-3 border border-border-main rounded-xl bg-bg-main/20 hover:border-brand-maroon-500/30 transition-all">
                  <div className="flex items-center gap-3 min-w-0">
                    {sub.imagePreview ? (
                      <img src={sub.imagePreview} alt="" className="w-11 h-11 rounded-full object-cover border border-border-main shadow-sm" />
                    ) : (
                      <div className="w-11 h-11 rounded-full bg-bg-main flex items-center justify-center text-xs font-bold text-text-muted border border-border-main">N/A</div>
                    )}
                    <div className="flex flex-col min-w-0">
                      <p className="text-xs font-bold text-brand-maroon-500 truncate">
                        {categories.find(c => c.value === sub.categoryId)?.label || 'Unknown'}
                      </p>
                      <p className="text-sm font-semibold text-text-main truncate">{sub.name}</p>
                    </div>
                  </div>
                  
                  {/* Item Actions */}
                  <div className="flex gap-1 pl-2">
                    <button 
                      onClick={() => startEdit(sub)} 
                      className="p-2 bg-bg-card border border-border-main rounded-lg text-text-muted hover:text-brand-maroon-500 active:bg-bg-main transition-colors"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={() => handleDelete(sub.id)} 
                      className="p-2 bg-bg-card border border-border-main rounded-lg text-text-muted hover:text-red-500 active:bg-bg-main transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-xs text-text-muted border border-dashed border-border-main rounded-xl bg-bg-card">
                No child records match current criteria parameters.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Image Cropper Overlay Portal remain visible dynamically under any state configuration inside layout */}
      {srcImage && (
        <ImageCropperModal 
          imageSrc={srcImage} 
          onCropComplete={handleCropComplete} 
          onClose={handleCancelCrop} 
        />
      )}
    </>
  );
};