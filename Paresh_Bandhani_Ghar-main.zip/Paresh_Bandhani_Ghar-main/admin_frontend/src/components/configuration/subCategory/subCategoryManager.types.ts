export interface SubCategory {
  id: string;
  categoryId: string;
  name: string;
  imageName: string;
  imagePreview?: string;
  imageId?: number;
}

export interface CategoryOption {
  value: string;
  label: string;
}

export interface SubCategoryViewProps {
  categories: CategoryOption[];
  subCategories: SubCategory[];
  selectedCategory: string;
  setSelectedCategory: (val: string) => void;
  name: string;
  setName: (val: string) => void;
  editingId: string | null;
  filterCategory: string | null;
  setFilterCategory: (val: string | null) => void;
  selectedFile: string;
  imagePreview: string;
  srcImage: string | null;
  handleFileUpload: (files: FileList) => void;
  handleCropComplete: (finalFile: File, previewUrl: string) => void;
  handleCancelCrop: () => void;
  clearImageSelection: () => void;
  handleSave: () => void;
  startEdit: (sub: SubCategory) => void;
  handleCancelEdit: () => void;
  handleDelete: (id: string) => void;
}