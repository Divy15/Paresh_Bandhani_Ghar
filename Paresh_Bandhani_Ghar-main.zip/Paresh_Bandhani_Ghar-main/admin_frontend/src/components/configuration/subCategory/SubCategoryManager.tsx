import React, { useState, useEffect } from 'react';
import { type SubCategory } from './subCategoryManager.types';
import { SubCategoryDesktopView } from './subCategoryDesktopView';
import { SubCategoryMobileView } from './subCategoryMobileView';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';
import { useLoader } from '../../../context/LoaderContext'; 
import { toast } from 'react-hot-toast'; 
import {
  storeSubCategory,
  updateSubCategory,
  getSubCategories,
  deleteSubCategory,
  getCategories, 
} from '../../../service/Configuration.service';
import { uploadImage } from '../../../service/Media.service';

export const SubCategoryManager: React.FC = () => {
  const { showLoader, hideLoader } = useLoader();
  
  const [categories, setCategories] = useState<{ value: string; label: string }[]>([]);
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  
  const [selectedCategory, setSelectedCategory] = useState('');
  const [name, setName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  const [editingImageId, setEditingImageId] = useState<number | null>(null);

  // Crop & File State management
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState('');
  const [croppedFile, setCroppedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  // 1. FIXED: Added empty string argument to satisfy the required search parameter
  useEffect(() => {
    const fetchMasterCategories = async () => {
      showLoader();
      try {
        const rawCategories = await getCategories(''); 
        const mappedCategories = (rawCategories || []).map((cat: any) => ({
          value: String(cat.id),
          label: cat.categoryName || cat.name || 'Unnamed Category',
        }));
        
        setCategories(mappedCategories);

        if (mappedCategories.length > 0) {
          setSelectedCategory(mappedCategories[0].value);
        }
      } catch (err: any) {
        toast.error(err || 'Failed to load master categories');
      } finally {
        hideLoader();
      }
    };

    fetchMasterCategories();
  }, []);

  const fetchSubCategories = async () => {
    if (!selectedCategory) return;
    
    showLoader();
    try {
      const data = await getSubCategories(Number(selectedCategory));
      setSubCategories(data || []);
    } catch (err: any) {
      toast.error(err);
    } finally {
      hideLoader();
    }
  };

  useEffect(() => {
    fetchSubCategories();
  }, [selectedCategory]);

  const handleFileUpload = (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      setSelectedFile(file.name);
      
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrcImage(reader.result as string);
      });
      reader.readAsDataURL(file);
    }
  };

  const clearImageSelection = () => {
    setSelectedFile('');
    setCroppedFile(null);
    setImagePreview('');
    setEditingImageId(null);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error('Sub-category name cannot be empty');
      return;
    }
    if (!selectedCategory) {
      toast.error('Please select a master category alignment');
      return;
    }
    if (!editingId && !croppedFile) {
      toast.error('Please upload and crop an image first');
      return;
    }

    showLoader();
    try {
      let finalImageId = editingImageId || 0;

      // 2. FIXED: Structured object to match the signature '{ type: string; file: File; }'
      if (croppedFile) {
        const uploadResponse = await uploadImage({
          type: 'subcategory',
          file: croppedFile
        });
        
        finalImageId = uploadResponse?.id || uploadResponse?.imageId || uploadResponse;
        
        if (!finalImageId) {
          throw 'Failed to parse generated asset ID from storage container';
        }
      }

      if (editingId) {
        await updateSubCategory({
          id: editingId,
          subcategoryName: name.trim(),
          categoryId: selectedCategory,
          imageId: finalImageId,
        });
        toast.success('🎉 Sub-Category updated successfully!');
      } else {
        await storeSubCategory({
          subcategoryName: name.trim(),
          categoryId: selectedCategory,
          imageId: finalImageId,
        });
        toast.success('✨ New Sub-Category added cleanly!');
      }

      setName('');
      setEditingId(null);
      clearImageSelection();
      fetchSubCategories(); 
    } catch (backendError: any) {
      toast.error(backendError);
    } finally {
      hideLoader();
    }
  };

  const startEdit = (sub: SubCategory) => {
    setEditingId(sub.id);
    setSelectedCategory(String(sub.categoryId));
    setName(sub.name);
    setSelectedFile(sub.imageName);
    setImagePreview(sub.imagePreview || '');
    setEditingImageId(sub.imageId);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to drop this mapping assignment?')) return;
    
    showLoader();
    try {
      await deleteSubCategory({ id });
      toast.success('Deleted item mapping entry');
      
      if (editingId === id) {
        setEditingId(null);
        setName('');
        clearImageSelection();
      }
      fetchSubCategories();
    } catch (backendError: any) {
      toast.error(backendError);
    } finally {
      hideLoader();
    }
  };

  const sharedProps = {
    categories,
    subCategories,
    selectedCategory,
    setSelectedCategory,
    name,
    setName,
    editingId,
    filterCategory,
    setFilterCategory,
    selectedFile,
    imagePreview,
    handleSave,
    startEdit,
    srcImage,
    handleCropComplete: (finalFile: File, previewUrl: string) => { setCroppedFile(finalFile); setImagePreview(previewUrl); },
    handleCancelCrop: () => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); },
    handleCancelEdit: () => { setEditingId(null); setName(''); clearImageSelection(); },
    handleDelete,
    handleFileUpload,
    clearImageSelection
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <h2 className="text-xl font-bold mb-1">Sub-Category Mappings</h2>
      <p className="text-sm text-text-muted mb-6">Map subsets directly inside master categories.</p>

      {/* RENDER FOR TABLETS & MOBILES (< 1024px) */}
      <div className="block lg:hidden">
        <SubCategoryMobileView {...sharedProps} />
      </div>

      {/* RENDER FOR DESKTOPS (>= 1024px) */}
      <div className="hidden lg:block">
        <SubCategoryDesktopView {...sharedProps} />
      </div>

      {/* Shared Cropper Modal container handles both screen modes */}
      {srcImage && (
        <ImageCropperModal
          imageSrc={srcImage}
          onCropComplete={(file, url) => { setCroppedFile(file); setImagePreview(url); setSrcImage(null); }}
          onClose={() => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); }}
        />
      )}
    </div>
  );
};