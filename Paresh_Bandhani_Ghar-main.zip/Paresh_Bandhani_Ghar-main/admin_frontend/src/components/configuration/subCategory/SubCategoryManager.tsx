import React, { useState } from 'react';
import { type SubCategory } from './subCategoryManager.types';
import { SubCategoryDesktopView } from './subCategoryDesktopView';
import { SubCategoryMobileView } from './subCategoryMobileView';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';

export const SubCategoryManager: React.FC = () => {
  const categories = [
    { value: '1', label: 'Saree' },
    { value: '2', label: 'Dress Materials' },
  ];

  const [subCategories, setSubCategories] = useState<SubCategory[]>([
    { id: '101', categoryId: '1', name: 'Gaji Silk', imageName: 'gaji_silk.jpg' },
    { id: '102', categoryId: '2', name: 'Cotton Dress Piece', imageName: 'cotton.jpg' },
  ]);

  const [selectedCategory, setSelectedCategory] = useState('1');
  const [name, setName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string | null>(null);

  // Crop & File State management
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState('');
  const [croppedFile, setCroppedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  const handleFileUpload = (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      setSelectedFile(file.name);
      
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrcImage(reader.result as string);
      });
      reader.readAsDataURL(file);
    }
  };

  const clearImageSelection = () => {
    setSelectedFile('');
    setCroppedFile(null);
    setImagePreview('');
  };

  const handleSave = () => {
    if (!name.trim()) return;

    if (editingId) {
      setSubCategories(
        subCategories.map((sub) =>
          sub.id === editingId
            ? { 
                ...sub, 
                categoryId: selectedCategory, 
                name, 
                imageName: selectedFile || sub.imageName, 
                imagePreview: imagePreview || sub.imagePreview 
              }
            : sub
        )
      );
      setEditingId(null);
    } else {
      setSubCategories([...subCategories, {
        id: Date.now().toString(),
        categoryId: selectedCategory,
        name,
        imageName: selectedFile || 'placeholder.jpg',
        imagePreview: imagePreview,
      }]);
    }

    setName('');
    clearImageSelection();
  };

  const startEdit = (sub: SubCategory) => {
    setEditingId(sub.id);
    setSelectedCategory(sub.categoryId);
    setName(sub.name);
    setSelectedFile(sub.imageName);
    setImagePreview(sub.imagePreview || '');
  };

  const sharedProps = {
    categories,
    subCategories,
    selectedCategory,
    setSelectedCategory,
    name,
    setName,
    editingId,
    filterCategory,
    setFilterCategory,
    selectedFile,
    imagePreview,
    handleSave,
    startEdit,
    srcImage,
    handleCropComplete: (finalFile: File, previewUrl: string) => { setCroppedFile(finalFile); setImagePreview(previewUrl); },
    handleCancelCrop: () => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); },
    handleCancelEdit: () => { setEditingId(null); setName(''); clearImageSelection(); },
    handleDelete: (id: string) => {
      setSubCategories(subCategories.filter((sub) => sub.id !== id));
      if (editingId === id) { setEditingId(null); setName(''); clearImageSelection(); }
    },
    handleFileUpload,
    clearImageSelection
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <h2 className="text-xl font-bold mb-1">Sub-Category Mappings</h2>
      <p className="text-sm text-text-muted mb-6">Map subsets directly inside master categories.</p>

      {/* RENDER FOR TABLETS & MOBILES (< 1024px) */}
      <div className="block lg:hidden">
        <SubCategoryMobileView {...sharedProps} />
      </div>

      {/* RENDER FOR DESKTOPS (>= 1024px) */}
      <div className="hidden lg:block">
        <SubCategoryDesktopView {...sharedProps} />
      </div>

      {/* Shared Cropper Modal container handles both screen modes */}
      {srcImage && (
        <ImageCropperModal
          imageSrc={srcImage}
          onCropComplete={(file, url) => { setCroppedFile(file); setImagePreview(url); setSrcImage(null); }}
          onClose={() => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); }}
        />
      )}
    </div>
  );
};