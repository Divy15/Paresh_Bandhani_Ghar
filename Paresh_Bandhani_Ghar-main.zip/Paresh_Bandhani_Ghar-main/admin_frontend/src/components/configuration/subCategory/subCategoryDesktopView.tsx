import React from 'react';
import { Input } from '../../commonComponents/Input';
import { FileUpload } from '../../commonComponents/FileUpload';
import { Select } from '../../commonComponents/Select';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';
import { FilterSearchDropdown } from '../../commonComponents/FilterSearchDropdown';
import { Trash2, Edit2, Plus, Check, X, Filter } from 'lucide-react';
import { type SubCategoryViewProps } from './subCategoryManager.types';


export const SubCategoryDesktopView: React.FC<SubCategoryViewProps> = ({
  categories,
  subCategories,
  selectedCategory,
  setSelectedCategory,
  name,
  setName,
  editingId,
  filterCategory,
  setFilterCategory,
  selectedFile,
  imagePreview,
  srcImage,
  handleFileUpload,
  handleCropComplete,
  handleCancelCrop,
  clearImageSelection,
  handleSave,
  startEdit,
  handleCancelEdit,
  handleDelete,
}) => {
  const filteredSubCategories = !filterCategory
    ? subCategories
    : subCategories.filter(sub => sub.categoryId === filterCategory);

  return (
    <>
      <div className="grid grid-cols-2 gap-6 mb-8 bg-bg-main/40 p-4 rounded-xl border border-border-main">
        <div className="flex flex-col gap-4">
          <Select label="Parent Category" options={categories} value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} />
          <Input label="Sub-Category Name" placeholder="e.g., Banarasi Silk" value={name} onChange={(e) => setName(e.target.value)} />
          
          <div className="flex gap-2 mt-auto">
            <button onClick={handleSave} className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-maroon-500 hover:bg-brand-maroon-600 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
              {editingId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {editingId ? 'Update Variant Set' : 'Map Sub-Category'}
            </button>
            {editingId && (
              <button onClick={handleCancelEdit} className="px-4 py-2.5 border border-border-main rounded-lg text-sm font-medium text-text-muted hover:bg-bg-main transition">
                Cancel
              </button>
            )}
          </div>
        </div>
        
        <div>
          <FileUpload label="Icon Art / Display Cover File" onChange={handleFileUpload} multiple={false} />
          {imagePreview && (
            <div className="flex items-center justify-between mt-3 p-2 border border-dashed border-border-main rounded-lg bg-bg-card">
              <div className="flex items-center gap-3">
                <img src={imagePreview} alt="preview" className="w-12 h-12 rounded-full object-cover border-2 border-brand-maroon-500" />
                <div className="flex flex-col">
                  <p className="text-xs font-semibold text-text-main">Active Selection</p>
                  <p className="text-[11px] text-text-muted truncate max-w-45">{selectedFile}</p>
                </div>
              </div>
              <button onClick={clearImageSelection} className="p-1 hover:bg-bg-main text-text-muted hover:text-red-500 rounded-full">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="mb-6 bg-bg-main/60 p-4 rounded-xl border border-border-main">
        <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-text-muted">
          <Filter className="w-3.5 h-3.5 text-brand-maroon-500" /> 
          <span>Filter Table View By Category</span>
        </div>
        <FilterSearchDropdown placeholder="All Categories" options={categories} selectedValue={filterCategory} onSelect={setSelectedCategory} />
      </div>

      <div className="overflow-hidden border border-border-main rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-bg-main text-text-muted text-xs font-semibold uppercase border-b border-border-main">
              <th className="p-4 w-24">Visual Icon</th>
              <th className="p-4">Subcategory Title</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border-main text-sm">
            {filteredSubCategories.length > 0 ? (
              filteredSubCategories.map((sub) => (
                <tr key={sub.id} className="hover:bg-bg-main/30">
                  <td className="p-4">
                    {sub.imagePreview ? <img src={sub.imagePreview} alt="" className="w-10 h-10 rounded-full object-cover border" /> : <div className="w-10 h-10 rounded-full bg-bg-main flex items-center justify-center text-xs text-text-muted">N/A</div>}
                  </td>
                  <td className="p-4 text-text-main font-medium">{sub.name}</td>
                  <td className="p-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => startEdit(sub)} className="p-1.5 text-text-muted hover:text-brand-maroon-500"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(sub.id)} className="p-1.5 text-text-muted hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan={4} className="p-8 text-center text-text-muted bg-bg-card">No subcategories found.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {srcImage && <ImageCropperModal imageSrc={srcImage} onCropComplete={handleCropComplete} onClose={handleCancelCrop} />}
    </>
  );
};