import React, { useState, useEffect } from 'react';
import { type CategoryViewProps } from './categoryManager.types';
import { Input } from '../../commonComponents/Input';
import { FileUpload } from '../../commonComponents/FileUpload';
import { FilterSearchDropdown } from '../../commonComponents/FilterSearchDropdown'; 
import { Trash2, Edit2, Plus, Check, X, FileText, List } from 'lucide-react';

export const CategoryMobileView: React.FC<CategoryViewProps> = (props) => {
  const [mobileView, setMobileView] = useState<'form' | 'list'>('form');

  // Auto-switch tabs to 'form' when an edit begins, or 'list' when saved
  useEffect(() => {
    if (props.editingId) setMobileView('form');
  }, [props.editingId]);

  const handleMobileSave = () => {
    props.handleSave();
    setMobileView('list');
  };

  return (
    <>
      <div className="flex bg-bg-main p-1 rounded-xl mb-6 border border-border-main">
        <button
          type="button"
          onClick={() => setMobileView('form')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-all ${
            mobileView === 'form' ? 'bg-bg-card text-brand-maroon-500 font-semibold border border-border-main shadow-sm' : 'text-text-muted'
          }`}
        >
          <FileText className="w-4 h-4" />
          {props.editingId ? 'Edit Form' : 'Open Form'}
        </button>
        <button
          type="button"
          onClick={() => setMobileView('list')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-all ${
            mobileView === 'list' ? 'bg-bg-card text-brand-maroon-500 font-semibold border border-border-main shadow-sm' : 'text-text-muted'
          }`}
        >
          <List className="w-4 h-4" />
          View List ({props.categories.length})
        </button>
      </div>

      {mobileView === 'form' ? (
        <div className="flex flex-col gap-6 bg-bg-main/40 p-4 rounded-xl border border-border-main">
          <Input label="Category Title Name" placeholder="e.g., Silk Dupattas" value={props.name} onChange={(e) => props.setName(e.target.value)} />
          <div>
            <FileUpload label="Category Banner/Icon Thumbnail" onChange={props.handleFileUpload} multiple={false} />
            {props.imagePreview && (
              <div className="flex items-center justify-between mt-3 p-2 border border-dashed border-border-main rounded-lg bg-bg-card">
                <img src={props.imagePreview} alt="preview" className="w-12 h-12 rounded-full object-cover border-2 border-brand-maroon-500" />
                <button onClick={props.clearImageSelection} className="p-1 text-text-muted hover:text-red-500"><X className="w-4 h-4" /></button>
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button onClick={handleMobileSave} className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-maroon-500 text-white rounded-lg text-sm font-semibold">
              {props.editingId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {props.editingId ? 'Update Variant' : 'Add New Category'}
            </button>
            {props.editingId && <button onClick={props.handleCancelEdit} className="px-4 py-2.5 border border-border-main rounded-lg text-sm text-text-muted">Cancel</button>}
          </div>
        </div>
      ) : (
        <div>
          <div className="mb-6">
            <FilterSearchDropdown label="Filter Categories View" placeholder="Search..." options={props.dropdownOptions} selectedValue={props.selectedFilterId} onSelect={props.setSelectedFilterId} />
          </div>
          <div className="overflow-x-auto border border-border-main rounded-xl">
            <table className="w-full text-left min-w-[500px]">
              <thead>
                <tr className="bg-bg-main text-text-muted text-xs font-semibold uppercase border-b border-border-main"><th className="p-4">Icon</th><th className="p-4">Title</th><th className="p-4 text-right">Actions</th></tr>
              </thead>
              <tbody className="divide-y divide-border-main text-sm">
                {props.filteredCategories.map((cat) => (
                  <tr key={cat.id} className="hover:bg-bg-main/30">
                    <td className="p-4"><img src={cat.presignedUrl || ''} alt="" className="w-10 h-10 rounded-full object-cover" /></td>
                    <td className="p-4 font-medium">{cat.category_name}</td>
                    <td className="p-4 text-right">
                      <button onClick={() => props.startEdit(cat)} className="p-1.5 text-text-muted hover:text-brand-maroon-500"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => props.handleDelete(cat.id)} className="p-1.5 text-text-muted hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
};