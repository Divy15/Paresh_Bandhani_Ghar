import React, { useState } from 'react';
import { type Category } from './categoryManager.types';
import { CategoryDesktopView } from './categoryDesktopView';
import { CategoryMobileView } from './categoryMobileView';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';
import {
  storeCategory,
} from "../../../service/Configuration.service"
import { uploadImage } from "../../../service/Media.service"

export const CategoryManager: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([
    { id: '1', name: 'Saree', imageName: 'saree_thumb.jpg' },
    { id: '2', name: 'Dress Materials', imageName: 'dress_thumb.jpg' },
  ]);
  const [name, setName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedFilterId, setSelectedFilterId] = useState<string | null>(null);
  
  // Image cropping states
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [croppedFile, setCroppedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  const handleFileUpload = (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      setSelectedFile(file.name);
      const reader = new FileReader();
      reader.addEventListener('load', () => setSrcImage(reader.result as string));
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
  if (!name.trim()) {
    alert("Please enter a category name");
    return;
  }

  try {
    let imageId: number | null = null;

    // 1. STEP ONE: If a cropped file exists, upload it to the media service first
    if (croppedFile) {
      const uploadResponse = await uploadImage({
        type: 'category', // Folder/Type name structure for your S3 path
        file: croppedFile,
      });

      // Based on your backend controller, it returns { mediaId: ... }
      imageId = uploadResponse.mediaId; 
      
      if (!imageId) {
        throw new Error("Failed to retrieve image ID from media upload.");
      }
    } else {
      alert("Please upload and crop a thumbnail photo first.");
      return;
    }

    // 2. STEP TWO: Store your category data along with the fresh imageId
    const categoryPayload = {
      categoryName: name,
      imageId: imageId, // Attaching the resolved ID here
    };

    const result = await storeCategory(categoryPayload);
    console.log("Category created successfully:", result);

    // 3. STEP THREE: Update local state to show the new category instantly (Optional)
    // If your backend returns the new category object, use that instead of fallback mapping
    setCategories([
      ...categories,
      {
        id: result?.id || Date.now().toString(),
        name: name,
        imageName: selectedFile || 'placeholder.jpg',
        imagePreview: imagePreview,
      },
    ]);

    // 4. STEP FOUR: Reset your input fields and image previews
    setName('');
    clearImageSelection();
    alert("Category and thumbnail saved successfully!");

  } catch (error) {
    console.error("Pipeline execution failed:", error);
    alert(typeof error === 'string' ? error : "An unexpected error occurred during save.");
  }
};

  const startEdit = (cat: Category) => {
    setEditingId(cat.id);
    setName(cat.name);
    setSelectedFile(cat.imageName);
    setImagePreview(cat.imagePreview || '');
  };

  const clearImageSelection = () => {
    setSelectedFile('');
    setCroppedFile(null);
    setImagePreview('');
  };

  const dropdownOptions = categories.map((cat) => ({ value: cat.id, label: cat.name }));
  const filteredCategories = selectedFilterId ? categories.filter((cat) => cat.id === selectedFilterId) : categories;

  // Packet of data passed straight down to the child view layers
  const sharedProps = {
    categories, filteredCategories, name, setName, editingId,
    selectedFilterId, setSelectedFilterId, selectedFile, imagePreview,
    dropdownOptions, handleSave, handleCancelEdit: () => { setEditingId(null); setName(''); clearImageSelection(); },
    startEdit, handleDelete: (id: string) => {
      setCategories(categories.filter((cat) => cat.id !== id));
      if (editingId === id) { setEditingId(null); setName(''); clearImageSelection(); }
      if (selectedFilterId === id) setSelectedFilterId(null);
    },
    handleFileUpload, clearImageSelection
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <h2 className="text-xl font-bold mb-1">Category Administration</h2>
      <p className="text-sm text-text-muted mb-6">Create base collection rules for items.</p>

      {/* RENDER FOR TABLETS & MOBILES (< 1024px) */}
      <div className="block lg:hidden">
        <CategoryMobileView {...sharedProps} />
      </div>

      {/* RENDER FOR DESKTOPS (>= 1024px) */}
      <div className="hidden lg:block">
        <CategoryDesktopView {...sharedProps} />
      </div>

      {srcImage && (
        <ImageCropperModal
          imageSrc={srcImage}
          onCropComplete={(file, url) => { setCroppedFile(file); setImagePreview(url); setSrcImage(null); }}
          onClose={() => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); }}
        />
      )}
    </div>
  );
};