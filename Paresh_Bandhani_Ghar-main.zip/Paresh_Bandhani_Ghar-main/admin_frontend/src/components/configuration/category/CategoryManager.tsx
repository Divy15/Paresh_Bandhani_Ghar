import React, { useState, useEffect } from 'react';
import { type Category } from './categoryManager.types';
import { CategoryDesktopView } from './categoryDesktopView';
import { CategoryMobileView } from './categoryMobileView';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';
import { BlockLoader, useLoader } from '../../../context/LoaderContext'; 
import { toast } from 'react-hot-toast'; 
import {
  storeCategory,
  getCategories,
  deleteCategory,
  updateCategory,
} from "../../../service/Configuration.service";
import { uploadImage } from "../../../service/Media.service";

export const CategoryManager: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState<boolean>(true); 
  
  const { showLoader, hideLoader } = useLoader();
  
  const [name, setName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFilterId, setSelectedFilterId] = useState<string | null>(null);
  
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [croppedFile, setCroppedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  // --- GET / READ SERVICE (No Toasts Here) ---
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true); 
        const response = await getCategories(searchQuery);
        
        if (response && Array.isArray(response.data)) {
          setCategories(response.data);
        } else {
          setCategories([]);
        }
      } catch (error) {
        console.error("Failed to load categories:", error);
        setCategories([]);
      } finally {
        setLoading(false);
      }
    };

    const delayDebounceFn = setTimeout(() => {
      fetchCategories();
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  // --- DELETE SERVICE ---
  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this category?")) return;

    try {
      showLoader(); 
      await deleteCategory({ id });
      
      setCategories(prev => prev.filter((cat) => cat.id !== id));
      if (editingId === id) { setEditingId(null); setName(''); clearImageSelection(); }
      if (selectedFilterId === id) setSelectedFilterId(null);
      
      toast.success("Category deleted successfully."); // 2. DELETE SUCCESS TOAST
    } catch (error) {
      console.error("Failed to delete category:", error);
      const errMsg = typeof error === 'string' ? error : "Could not delete category.";
      toast.error(errMsg); // 3. DELETE ERROR TOAST
    } finally {
      hideLoader(); 
    }
  };

  const handleFileUpload = (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      setSelectedFile(file.name);
      const reader = new FileReader();
      reader.addEventListener('load', () => setSrcImage(reader.result as string));
      reader.readAsDataURL(file);
    }
  };

  // --- SAVE & UPDATE SERVICE ---
  const handleSave = async () => {
    if (!name.trim()) {
      toast.error("Please enter a category name");
      return;
    }

    try {
      showLoader(); 
      let imageId: number | null = null;

      if (croppedFile) {
        const uploadResponse = await uploadImage({
          type: 'category',
          file: croppedFile,
        });
        imageId = uploadResponse.mediaId; 
        
        if (!imageId) {
          throw new Error("Failed to retrieve image ID from media upload.");
        }
      } else if (editingId) {
        const currentCategory = categories.find(cat => cat.id === editingId);
        imageId = currentCategory ? (currentCategory as any).image_id : null;
      }

      if (!editingId && !imageId) {
        toast.error("Please upload and crop a thumbnail photo first.");
        return;
      }

      if (editingId) {
        const updatePayload = {
          id: editingId,
          categoryName: name,
          imageId: imageId as number,
        };
        await updateCategory(updatePayload);
        toast.success("Category updated successfully!"); // 4. UPDATE SUCCESS TOAST
      } else {
        const categoryPayload = {
          categoryName: name,
          imageId: imageId as number,
        };
        await storeCategory(categoryPayload);
        toast.success("Category saved successfully!"); // 5. ADD SUCCESS TOAST
      }

      const updatedResponse = await getCategories(searchQuery);
      if (updatedResponse && Array.isArray(updatedResponse.data)) {
        setCategories(updatedResponse.data);
      }

      setName('');
      setEditingId(null);
      clearImageSelection();

    } catch (error) {
      console.error("Pipeline execution failed:", error);
      const errMsg = typeof error === 'string' ? error : "An unexpected error occurred during save.";
      toast.error(errMsg); // 6. MUTATION ERROR TOAST
    } finally {
      hideLoader(); 
    }
  };

  const startEdit = (cat: Category) => {
    setEditingId(cat.id);
    setName(cat.category_name);
    setSelectedFile(cat.imageName);
    setImagePreview(cat.presignedUrl || '');
  };

  const clearImageSelection = () => {
    setSelectedFile('');
    setCroppedFile(null);
    setImagePreview('');
  };

  const dropdownOptions = categories.map((cat) => ({ value: cat.id, label: cat.category_name }));
  
  const filteredCategories = selectedFilterId 
    ? categories.filter((cat) => cat.id === selectedFilterId) 
    : categories;

  const sharedProps = {
    categories, filteredCategories, name, setName, editingId,
    selectedFilterId, setSelectedFilterId, selectedFile, imagePreview,
    dropdownOptions, handleSave, handleCancelEdit: () => { setEditingId(null); setName(''); clearImageSelection(); },
    startEdit, handleDelete, handleFileUpload, clearImageSelection,
    searchQuery, setSearchQuery
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <div className="flex justify-between items-center mb-1">
        <h2 className="text-xl font-bold">Category Administration</h2>
      </div>
      <p className="text-sm text-text-muted mb-6">Create base collection rules for items.</p>

      <BlockLoader isLoading={loading}>
        <div className="block lg:hidden">
          <CategoryMobileView {...sharedProps} />
        </div>

        <div className="hidden lg:block">
          <CategoryDesktopView {...sharedProps} />
        </div>
      </BlockLoader>

      {srcImage && (
        <ImageCropperModal
          imageSrc={srcImage}
          onCropComplete={(file, url) => { setCroppedFile(file); setImagePreview(url); setSrcImage(null); }}
          onClose={() => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); }}
        />
      )}
    </div>
  );
};