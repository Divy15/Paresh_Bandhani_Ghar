import React, { useState } from 'react';
import { type Category } from './categoryManager.types';
import { CategoryDesktopView } from './categoryDesktopView';
import { CategoryMobileView } from './categoryMobileView';
import { ImageCropperModal } from '../../commonComponents/ImageCropperModal';

export const CategoryManager: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([
    { id: '1', name: 'Saree', imageName: 'saree_thumb.jpg' },
    { id: '2', name: 'Dress Materials', imageName: 'dress_thumb.jpg' },
  ]);
  const [name, setName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedFilterId, setSelectedFilterId] = useState<string | null>(null);
  
  // Image cropping states
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [croppedFile, setCroppedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  const handleFileUpload = (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      setSelectedFile(file.name);
      const reader = new FileReader();
      reader.addEventListener('load', () => setSrcImage(reader.result as string));
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!name.trim()) return;
    if (editingId) {
      setCategories(categories.map((cat) => cat.id === editingId ? { ...cat, name, imageName: selectedFile || cat.imageName, imagePreview: imagePreview || cat.imagePreview } : cat));
      setEditingId(null);
    } else {
      setCategories([...categories, { id: Date.now().toString(), name, imageName: selectedFile || 'placeholder.jpg', imagePreview }]);
    }
    setName('');
    clearImageSelection();
  };

  const startEdit = (cat: Category) => {
    setEditingId(cat.id);
    setName(cat.name);
    setSelectedFile(cat.imageName);
    setImagePreview(cat.imagePreview || '');
  };

  const clearImageSelection = () => {
    setSelectedFile('');
    setCroppedFile(null);
    setImagePreview('');
  };

  const dropdownOptions = categories.map((cat) => ({ value: cat.id, label: cat.name }));
  const filteredCategories = selectedFilterId ? categories.filter((cat) => cat.id === selectedFilterId) : categories;

  // Packet of data passed straight down to the child view layers
  const sharedProps = {
    categories, filteredCategories, name, setName, editingId,
    selectedFilterId, setSelectedFilterId, selectedFile, imagePreview,
    dropdownOptions, handleSave, handleCancelEdit: () => { setEditingId(null); setName(''); clearImageSelection(); },
    startEdit, handleDelete: (id: string) => {
      setCategories(categories.filter((cat) => cat.id !== id));
      if (editingId === id) { setEditingId(null); setName(''); clearImageSelection(); }
      if (selectedFilterId === id) setSelectedFilterId(null);
    },
    handleFileUpload, clearImageSelection
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm text-text-main">
      <h2 className="text-xl font-bold mb-1">Category Administration</h2>
      <p className="text-sm text-text-muted mb-6">Create base collection rules for items.</p>

      {/* RENDER FOR TABLETS & MOBILES (< 1024px) */}
      <div className="block lg:hidden">
        <CategoryMobileView {...sharedProps} />
      </div>

      {/* RENDER FOR DESKTOPS (>= 1024px) */}
      <div className="hidden lg:block">
        <CategoryDesktopView {...sharedProps} />
      </div>

      {srcImage && (
        <ImageCropperModal
          imageSrc={srcImage}
          onCropComplete={(file, url) => { setCroppedFile(file); setImagePreview(url); setSrcImage(null); }}
          onClose={() => { setSrcImage(null); if (!imagePreview) setSelectedFile(''); }}
        />
      )}
    </div>
  );
};