export interface Category {
  id: string;
  name: string;
  imageName: string;
  imagePreview?: string; 
}

// These are the exact properties both your views will consume
export interface CategoryViewProps {
  categories: Category[];
  filteredCategories: Category[];
  name: string;
  setName: (name: string) => void;
  editingId: string | null;
  selectedFilterId: string | null;
  setSelectedFilterId: (id: string | null) => void;
  selectedFile: string;
  imagePreview: string;
  dropdownOptions: { value: string; label: string }[];
  handleSave: () => void;
  handleCancelEdit: () => void;
  startEdit: (cat: Category) => void;
  handleDelete: (id: string) => void;
  handleFileUpload: (files: FileList) => void;
  clearImageSelection: () => void;
}