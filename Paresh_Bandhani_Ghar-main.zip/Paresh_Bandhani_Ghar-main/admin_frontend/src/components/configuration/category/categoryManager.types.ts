export interface Category {
  id: string;
  category_name: string;
  imageName: string;
  presignedUrl?: string; 
}

// These are the exact properties both your views will consume
export interface CategoryViewProps {
  categories: Category[];
  filteredCategories: Category[];
  name: string;
  setName: (name: string) => void;
  editingId: string | null;
  selectedFilterId: string | null;
  setSelectedFilterId: (id: string | null) => void;
  selectedFile: string;
  imagePreview: string;
  dropdownOptions: { value: string; label: string }[];
  handleSave: () => void;
  handleCancelEdit: () => void;
  startEdit: (cat: Category) => void;
  handleDelete: (id: string) => void;
  handleFileUpload: (files: FileList) => void;
  clearImageSelection: () => void;
}