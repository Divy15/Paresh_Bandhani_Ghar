import React, { useState, useEffect } from 'react';
import { Trash2, Edit2, Plus, X, Check } from 'lucide-react';
import { Input } from '../commonComponents/Input';
import { TextArea } from '../commonComponents/TextArea';
import { useLoader, BlockLoader } from '../../context/LoaderContext'; // Imported both loader contexts
import { toast } from 'react-hot-toast';
import {
  getWashingInstructions,
  storeWashingInstruction,
  updateWashingInstruction,
  deleteWashingInstruction,
} from "../../service/Configuration.service";

interface WashingInstruction {
  id: number;
  instruction: string;
  instructionDescription: string | null;
}

export const WashingInstructionManager: React.FC = () => {
  const [instructions, setInstructions] = useState<WashingInstruction[]>([]);
  const [instructionText, setInstructionText] = useState('');
  const [descriptionText, setDescriptionText] = useState(''); 
  const [editingId, setEditingId] = useState<number | null>(null);
  const [tableLoading, setTableLoading] = useState(false); // Fine-grained loader variable state for the micro list grid

  const { showLoader, hideLoader } = useLoader(); // Global backdrop layout context instance triggers

  // 1. FETCH ALL DATA FROM BACKEND ON MOUNT (Silent Loader rule maintained)
  const fetchInstructions = async () => {
    setTableLoading(true);
    try {
      const response = await getWashingInstructions();
      if (response.success && response.data) {
        const mappedData = response.data.map((item: any) => ({
          id: item.id,
          instruction: item.instruction,
          instructionDescription: item.instruction_description,
        }));
        setInstructions(mappedData);
      }
    } catch (error) {
      toast.error(typeof error === 'string' ? error : 'Failed to retrieve instruction matrices.');
    } finally {
      setTableLoading(false);
    }
  };

  useEffect(() => {
    fetchInstructions();
  }, []);

  // 2. SAVE OR UPDATE DATA (Global Overlay triggers + Success Toasts applied)
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!instructionText.trim()) return;

    showLoader(); // Freezes UI view interactions during mutation process tasks
    try {
      if (editingId !== null) {
        const response = await updateWashingInstruction({
          id: editingId,
          instruction: instructionText.trim(),
          instructionDescription: descriptionText.trim() || null
        });

        if (response.success) {
          toast.success(response.message || 'Instruction matrix altered successfully.');
          setEditingId(null);
        }
      } else {
        const response = await storeWashingInstruction({
          instruction: instructionText.trim(),
          instructionDescription: descriptionText.trim() || null
        });

        if (response.success) {
          toast.success(response.message || 'New care item logged into system.');
        }
      }
      
      setInstructionText('');
      setDescriptionText('');
      await fetchInstructions(); // Re-syncs latest backend modifications
    } catch (error) {
      toast.error(typeof error === 'string' ? error : 'Operation processing layout faulted.');
    } finally {
      hideLoader();
    }
  };

  const startEdit = (item: WashingInstruction) => {
    setEditingId(item.id);
    setInstructionText(item.instruction);
    setDescriptionText(item.instructionDescription || '');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setInstructionText('');
    setDescriptionText('');
  };

  // 3. REMOVE RECORD DATA (Global Overlay triggers + Success Toasts applied)
  const handleDelete = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this washing instruction?')) return;
    
    showLoader();
    try {
      const response = await deleteWashingInstruction(id);
      if (response.success) {
        toast.success(response.message || 'Care standard removed.');
        await fetchInstructions();
      }
    } catch (error) {
      toast.error(typeof error === 'string' ? error : 'Could not completely clear index line entry.');
    } finally {
      hideLoader();
    }
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-text-main">Washing Instructions Registry</h2>
        <p className="text-xs text-text-muted mt-1">Configure fabric care directions. Press Enter in the description field to create list points.</p>
      </div>

      {/* Entry Management Form */}
      <form onSubmit={handleSave} className="space-y-4 bg-bg-main/40 p-4 rounded-xl border border-border-main/60">
        <div className="w-full">
          <Input
            label="Instruction Title"
            placeholder="e.g., Delicate Linen Settings"
            value={instructionText}
            onChange={(e) => setInstructionText(e.target.value)}
            required
          />
        </div>
        
        <div className="w-full">
          <TextArea
            label="Care Instructions (Press Enter for new points)"
            placeholder="e.g.,&#10;Hand wash only&#10;Use mild liquid detergents"
            value={descriptionText}
            onChange={(e) => setDescriptionText(e.target.value)}
            showPointsPreview={true}
          />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          {editingId !== null && (
            <button
              type="button"
              onClick={cancelEdit}
              className="flex items-center gap-1.5 px-4 py-2 border border-border-main text-text-main text-sm font-medium rounded-lg hover:bg-bg-main transition-colors"
            >
              <X className="w-4 h-4" /> Cancel
            </button>
          )}
          <button
            type="submit"
            disabled={!instructionText.trim()}
            className="flex items-center gap-1.5 bg-brand-maroon-500 text-white px-4 py-2 text-sm font-semibold rounded-lg hover:bg-brand-maroon-600 transition-colors disabled:opacity-50"
          >
            {editingId !== null ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            {editingId !== null ? 'Update Care Rule' : 'Add Care Rule'}
          </button>
        </div>
      </form>

      {/* Active Data Table View protected inside BlockLoader Mask wrapper */}
      <BlockLoader isLoading={tableLoading}>
        <div className="border border-border-main rounded-xl overflow-hidden bg-bg-main/20">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-bg-main/60 border-b border-border-main text-xs font-mono font-bold uppercase tracking-wider text-text-muted">
                <th className="p-3.5 w-1/3">Instruction</th>
                <th className="p-3.5">Point-wise Guidelines</th>
                <th className="p-3.5 text-right w-24">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-main/50 text-sm">
              {instructions.length === 0 ? (
                <tr>
                  <td colSpan={3} className="p-8 text-center text-text-muted text-xs">
                    {tableLoading ? 'Spinning textile records...' : 'No washing instructions registered yet.'}
                  </td>
                </tr>
              ) : (
                instructions.map((item) => (
                  <tr key={item.id} className="hover:bg-bg-main/30 transition-colors align-top">
                    <td className="p-3.5 font-medium text-text-main pt-4">{item.instruction}</td>
                    <td className="p-3.5 text-xs text-text-muted pt-4">
                      {item.instructionDescription ? (
                        <ul className="list-disc list-inside space-y-1 pl-0">
                          {item.instructionDescription.split('\n').map((point, idx) => (
                            point.trim() && <li key={idx}><span className="text-text-main">{point.trim()}</span></li>
                          ))}
                        </ul>
                      ) : (
                        <span className="italic text-text-muted/60">No points added</span>
                      )}
                    </td>
                    <td className="p-3.5 text-right flex justify-end gap-2.5 pt-4">
                      <button
                        type="button"
                        onClick={() => startEdit(item)}
                        className="p-1 text-text-muted hover:text-brand-maroon-500 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(item.id)}
                        className="p-1 text-text-muted hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </BlockLoader>
    </div>
  );
};