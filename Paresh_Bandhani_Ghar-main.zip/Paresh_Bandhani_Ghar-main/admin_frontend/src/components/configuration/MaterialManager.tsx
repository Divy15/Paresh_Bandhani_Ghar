import React, { useState, useEffect } from 'react';
import { Input } from '../commonComponents/Input';
import { Trash2, Plus } from 'lucide-react';
import { useLoader } from '../../context/LoaderContext'; 
import { toast } from 'react-hot-toast';
import {
  storeMaterial,
  deleteMaterial,
  getMaterials
} from "../../service/Configuration.service";

// Assuming your Material structure from backend has an id and material_name
interface MaterialItem {
  id: string | number;
  material_name: string;
}

export const MaterialManager: React.FC = () => {
  const { showLoader, hideLoader } = useLoader();
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [item, setItem] = useState('');

  // 1. Fetch Materials (No Toaster on Success, Toast on Error)
  const fetchMaterials = async () => {
    showLoader();
    try {
      const response = await getMaterials();
      // Adjust payload extraction depending on your API wrapping structure (e.g., response.data)
      setMaterials(response?.data || response || []);
    } catch (error: any) {
      toast.error(error || 'Failed to fetch materials');
    } finally {
      hideLoader();
    }
  };

  // Run on component mount
  useEffect(() => {
    fetchMaterials();
  }, []);

  // 2. Add/Store Material (Has Toaster)
  const handleAddMaterial = async () => {
    const trimmedItem = item.trim();
    if (!trimmedItem) {
      toast.error('Material name cannot be empty');
      return;
    }

    // Check for local duplicates before calling API
    if (materials.some(m => m.material_name.toLowerCase() === trimmedItem.toLowerCase())) {
      toast.error('This material already exists');
      return;
    }

    showLoader();
    try {
      await storeMaterial({ materialName: trimmedItem });
      toast.success('✨ New material added cleanly!');
      setItem('');
      fetchMaterials(); // Refresh list from backend
    } catch (error: any) {
      toast.error(error || 'Failed to add material');
    } finally {
      hideLoader();
    }
  };

  // 3. Delete Material (Has Toaster)
  const handleDeleteMaterial = async (id: string | number) => {
    if (!window.confirm('Are you sure you want to drop this material?')) return;

    showLoader();
    try {
      await deleteMaterial({ id: String(id) });
      toast.success('Deleted item mapping entry');
      fetchMaterials(); // Refresh list from backend
    } catch (error: any) {
      toast.error(error || 'Failed to eliminate material record');
    } finally {
      hideLoader();
    }
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-6 shadow-sm">
      <h2 className="text-xl font-bold mb-1">Material Registry Base</h2>
      <p className="text-sm text-text-muted mb-6">Manage base production yarn and clothing material types.</p>

      <div className="flex gap-3 mb-6 max-w-md">
        <Input 
          label="Add Raw Fabric Variant" 
          placeholder="e.g., Organza Silk" 
          value={item} 
          onChange={(e) => setItem(e.target.value)} 
        />
        <button 
          onClick={handleAddMaterial} 
          className="flex items-center justify-center p-2.5 bg-brand-maroon-500 hover:bg-brand-maroon-600 text-white rounded-lg transition-colors self-end h-10.5 w-10.5 shrink-0 shadow-sm"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {materials.length > 0 ? (
          materials.map((mat) => (
            <div key={mat.id} className="flex items-center justify-between p-3 rounded-xl border border-border-main bg-bg-main/30 hover:border-brand-maroon-500/40 transition-colors">
              <span className="text-sm font-medium">{mat.material_name}</span>
              <button 
                onClick={() => handleDeleteMaterial(mat.id)} 
                className="p-1.5 text-text-muted hover:text-red-500 hover:bg-bg-main rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        ) : (
          <div className="col-span-2 p-8 text-center text-xs text-text-muted border border-dashed border-border-main rounded-xl bg-bg-card">
            No production yarn records loaded.
          </div>
        )}
      </div>
    </div>
  );
};