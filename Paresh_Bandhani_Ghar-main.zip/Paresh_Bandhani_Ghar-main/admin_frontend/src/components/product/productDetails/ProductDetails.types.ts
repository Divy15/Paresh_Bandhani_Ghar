export interface MediaFile {
  url: string;
  type: 'image' | 'video';
}

export interface MatrixRow {
  componentName: string; // e.g., 'Top', 'Bottom', 'Dupatta'
  material: string;
  color: string;
  length: string; // in meters
  width: string;  // in meters
  weight: string;
}

export interface CatalogProductMedia {
  url: string;             // Ephemeral local object blob URL for <img> tags
  fileBlob: File;          // CRITICAL: The physical file data payload for S3 uploading
  type: 'image' | 'video';
  isCover: boolean;        // Handles cover photo selection
  permanentUrl?: string;   // Populated post-upload
}

export interface CatalogProduct {
  id: string;              // Client-side generated unique tracking key
  backendProductId?: string; // Populated after your batch setup call
  files: CatalogProductMedia[];
  name: string;
  price: string;
  quantity: string;
  matrixType: string;
  matrixRows: any[];
  washingInstruction: string;
  description: string;
}

export interface SharedWizardState {
  category: string;          // Acts as categoryid string
  category_name: string;     // Acts as categoryname string
  subCategory: string;       // Acts as subcategoryid string
  subcategory_name: string;  // Acts as subcategoryname string
  catalogId: string;         // The unique string integer generated from timestamp
  catalogProducts: CatalogProduct[];
}