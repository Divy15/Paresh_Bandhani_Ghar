export interface MediaFile {
  url: string;
  type: 'image' | 'video';
}

export interface MatrixRow {
  componentName: string; // e.g., 'Top', 'Bottom', 'Dupatta'
  material: string;
  color: string;
  length: string; // in meters
  width: string;  // in meters
  weight: string;
}

export interface CatalogProduct {
  id: string;
  files: MediaFile[];
  name: string;
  price: string;
  quantity: string;
  matrixType: string; // 'Dress' | 'Saree' | 'Dupatta'
  matrixRows: MatrixRow[];
  washingInstruction: string;
  description: string;
}

export interface SharedWizardState {
  category: string;
  subCategory: string;
  catalogProducts: CatalogProduct[];
}