import React from 'react';
import type { SharedWizardState } from './ProductDetails.types';
import { Select } from "../../commonComponents/Select";

interface StepProps {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
}

const CATEGORY_MAP: Record<string, string[]> = {
  'Ethnic Wear': ['Saree', 'Lehenga', 'Anarkali Suit'],
  'Unstitched Fabric': ['Dress Material', 'Kurtis Fabric'],
  'Accessories': ['Dupatta', 'Stoles', 'Shawls'],
  'Western Wear': [] // No subcategories condition mapping test
};

export const Step1Form: React.FC<StepProps> = ({ state, updateState, onNext }) => {
  const subCategoriesAvailable = state.category ? CATEGORY_MAP[state.category]?.length > 0 : false;

  // Format the primary categories for the Select component options prop
  const categoryOptions = [
    { value: '', label: '-- Choose Category --' },
    ...Object.keys(CATEGORY_MAP).map(cat => ({ value: cat, label: cat }))
  ];

  // Format subcategories based on active parent category selection
  const subCategoryOptions = state.category 
    ? [
        { value: '', label: '-- Choose Subcategory --' },
        ...(CATEGORY_MAP[state.category] || []).map(sub => ({ value: sub, label: sub }))
      ]
    : [];

  return (
    <div className="space-y-4 max-w-md mx-auto py-4">
      <h3 className="text-lg font-semibold text-text-main font-serif">Select Catalog Classification</h3>
      
      {/* Primary Category Dropdown using shared Select component */}
      <Select
        label="Primary Category"
        options={categoryOptions}
        value={state.category}
        onChange={(e) => updateState({ category: e.target.value, subCategory: '' })}
      />

      {/* Conditional Subcategory Dropdown using shared Select component */}
      {subCategoriesAvailable && (
        <div className="animate-fade-in">
          <Select
            label="Subcategory Selection"
            options={subCategoryOptions}
            value={state.subCategory}
            onChange={(e) => updateState({ subCategory: e.target.value })}
          />
        </div>
      )}

      <button 
        disabled={!state.category || (subCategoriesAvailable && !state.subCategory)}
        onClick={onNext}
        className="w-full mt-4 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        Continue to Media Upload
      </button>
    </div>
  );
};