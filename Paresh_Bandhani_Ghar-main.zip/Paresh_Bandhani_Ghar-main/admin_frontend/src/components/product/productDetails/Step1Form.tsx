import React, { useEffect, useState } from 'react';
import type { SharedWizardState } from './ProductDetails.types';
import { Select } from "../../commonComponents/Select";
import {
  getCategories,
  getSubCategories,
} from "../../../service/Configuration.service";

interface StepProps {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
}

// Define TypeScript interfaces based on your backend response structures
interface BackendCategory {
  id: number;
  category_name: string;
}

interface BackendSubCategory {
  id: number;
  subcategory_name: string;
}

export const Step1Form: React.FC<StepProps> = ({ state, updateState, onNext }) => {
  const [categories, setCategories] = useState<BackendCategory[]>([]);
  const [subCategories, setSubCategories] = useState<BackendSubCategory[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 1. Fetch main categories when the component mounts
  useEffect(() => {
    const fetchInitialCategories = async () => {
      try {
        setLoading(true);
        // Passing an empty string or default search term to getCategories
        const data = await getCategories("");
        setCategories(data.data || []);
      } catch (err) {
        setErrorMsg(typeof err === 'string' ? err : 'Failed to load categories');
      } finally {
        setLoading(false);
      }
    };

    fetchInitialCategories();
  }, []);

  // 2. Fetch subcategories whenever the primary category changes
  useEffect(() => {
    if (!state.category) {
      setSubCategories([]);
      return;
    }

    const fetchSubCategoriesData = async () => {
      try {
        setLoading(true);
        // Convert the string category ID to a number as expected by service 2
        const categoryId = Number(state.category);
        const data = await getSubCategories(categoryId);
        setSubCategories(data.data || []);
      } catch (err) {
        setErrorMsg(typeof err === 'string' ? err : 'Failed to load subcategories');
      } finally {
        setLoading(false);
      }
    };

    fetchSubCategoriesData();
  }, [state.category]);

  // Format main categories for the UI Select dropdown
  const categoryOptions = [
    { value: '', label: loading && categories.length === 0 ? 'Loading...' : '-- Choose Category --' },
    ...categories.map(cat => ({ value: String(cat.id), label: cat.category_name }))
  ];

  // Format subcategories for the UI Select dropdown
  const subCategoryOptions = [
    { value: '', label: '-- Choose Subcategory --' },
    ...subCategories.map(sub => ({ value: String(sub.id), label: sub.subcategory_name }))
  ];

  // Show subcategories only if the active parent has elements returned from API
  const subCategoriesAvailable = subCategories.length > 0;

  return (
    <div className="space-y-4 max-w-md mx-auto py-4">
      <h3 className="text-lg font-semibold text-text-main font-serif">Select Catalog Classification</h3>
      
      {errorMsg && (
        <div className="p-3 text-xs bg-red-50 text-red-600 rounded-lg">
          {errorMsg}
        </div>
      )}
      
      {/* Primary Category Dropdown */}
      <Select
        label="Primary Category"
        options={categoryOptions}
        value={state.category_name}
        onChange={(e) => {
          setErrorMsg(null);
          // Reset subcategory selection when primary category switches
          updateState({ category: e.target.value, category_name: e.target.value, subCategory: '' });
        }}
      />

      {/* Conditional Subcategory Dropdown */}
      {subCategoriesAvailable && (
        <div className="animate-fade-in">
          <Select
            label="Subcategory Selection"
            options={subCategoryOptions}
            value={state.subcategory_name}
            onChange={(e) => updateState({ subCategory: e.target.value, subcategory_name: e.target.value, })}
          />
        </div>
      )}

      <button 
        disabled={loading || !state.category || (subCategoriesAvailable && !state.subCategory)}
        onClick={onNext}
        className="w-full mt-4 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {loading ? 'Processing...' : 'Continue to Media Upload'}
      </button>
    </div>
  );
};