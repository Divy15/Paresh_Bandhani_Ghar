import React, { useEffect, useState } from 'react';
import type { SharedWizardState } from './ProductDetails.types';
import { Select } from "../../commonComponents/Select";
import { getCategories, getSubCategories } from "../../../service/Configuration.service";
import { StoreCategorySubcategory } from "../../../service/Product.service";

interface StepProps {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
}

interface BackendCategory {
  id: number;
  category_name: string;
}

interface BackendSubCategory {
  id: number;
  subcategory_name: string;
}

export const Step1Form: React.FC<StepProps> = ({ state, updateState, onNext }) => {
  const [categories, setCategories] = useState<BackendCategory[]>([]);
  const [subCategories, setSubCategories] = useState<BackendSubCategory[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false); // Tracks backend API submission
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 1. Fetch primary categories
  useEffect(() => {
    const fetchInitialCategories = async () => {
      try {
        setLoading(true);
        const data = await getCategories("");
        setCategories(data.data || []);
      } catch (err) {
        setErrorMsg(typeof err === 'string' ? err : 'Failed to load categories');
      } finally {
        setLoading(false);
      }
    };
    fetchInitialCategories();
  }, []);

  // 2. Fetch subcategories whenever state.category (the ID string) changes
  useEffect(() => {
    if (!state.category) {
      setSubCategories([]);
      return;
    }

    const fetchSubCategoriesData = async () => {
      try {
        setLoading(true);
        const categoryId = Number(state.category);
        const data = await getSubCategories(categoryId);
        setSubCategories(data.data || []);
      } catch (err) {
        setErrorMsg(typeof err === 'string' ? err : 'Failed to load subcategories');
      } finally {
        setLoading(false);
      }
    };

    fetchSubCategoriesData();
  }, [state.category]);

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedId = e.target.value;
    const matchedCategory = categories.find(cat => String(cat.id) === selectedId);
    
    setErrorMsg(null);
    updateState({
      category: selectedId,
      category_name: matchedCategory ? matchedCategory.category_name : '',
      subCategory: '',
      subcategory_name: '',
      catalogId: '' // Clear catalog ID if they reset classifications
    });
  };

  const handleSubCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedSubId = e.target.value;
    const matchedSub = subCategories.find(sub => String(sub.id) === selectedSubId);

    updateState({
      subCategory: selectedSubId,
      subcategory_name: matchedSub ? matchedSub.subcategory_name : '',
      catalogId: '' // Clear catalog ID if they reset classifications
    });
  };

  // 3. New Submit Handler to communicate with your backend controller
  const handleSubmitClassification = async () => {
    try {
      setSubmitting(true);
      setErrorMsg(null);

      // Prepare payload required by your backend
      const payload = {
        categoryid: Number(state.category),
        subcategoryid: Number(state.subCategory)
      };

      // Call API Service
      const res = await StoreCategorySubcategory(payload);

      if (res && res.success && res.catalogId) {
        // Save backend generated catalog ID to the global state state object
        updateState({ catalogId: String(res.catalogId) });
        
        // Progress to Step 2 (Media Upload)
        onNext();
      } else {
        throw new Error("Backend did not provide a valid catalog ID.");
      }

    } catch (err) {
      console.error("Form step 1 submission failed:", err);
      setErrorMsg(typeof err === 'string' ? err : 'Failed to register catalog classification on server.');
    } finally {
      setSubmitting(false);
    }
  };

  const categoryOptions = [
    { value: '', label: loading && categories.length === 0 ? 'Loading...' : '-- Choose Category --' },
    ...categories.map(cat => ({ value: String(cat.id), label: cat.category_name }))
  ];

  const subCategoryOptions = [
    { value: '', label: '-- Choose Subcategory --' },
    ...subCategories.map(sub => ({ value: String(sub.id), label: sub.subcategory_name }))
  ];

  const subCategoriesAvailable = subCategories.length > 0;
  const isButtonDisabled = loading || submitting || !state.category || (subCategoriesAvailable && !state.subCategory);

  return (
    <div className="space-y-4 max-w-md mx-auto py-4">
      <h3 className="text-lg font-semibold text-text-main font-serif">Select Catalog Classification</h3>
      
      {errorMsg && (
        <div className="p-3 text-xs bg-red-50 text-red-600 rounded-lg">
          {errorMsg}
        </div>
      )}
      
      <Select
        label="Primary Category"
        options={categoryOptions}
        value={state.category}
        onChange={handleCategoryChange}
        disabled={submitting}
      />

      {subCategoriesAvailable && (
        <div className="animate-fade-in">
          <Select
            label="Subcategory Selection"
            options={subCategoryOptions}
            value={state.subCategory}
            onChange={handleSubCategoryChange}
            disabled={submitting}
          />
        </div>
      )}

      <button 
        disabled={isButtonDisabled}
        onClick={handleSubmitClassification}
        className="w-full mt-4 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {submitting ? 'Registering Catalog...' : 'Continue to Media Upload'}
      </button>
    </div>
  );
};