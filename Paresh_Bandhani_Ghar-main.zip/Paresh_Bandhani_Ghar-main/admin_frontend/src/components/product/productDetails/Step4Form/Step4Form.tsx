import React, { useState, useEffect } from 'react';
import type { SharedWizardState, MatrixRow } from '../ProductDetails.types';
import { Select } from '../../../commonComponents/Select';
import { getStructures, getMaterials, getWashingInstructions } from "../../../../service/Configuration.service";
import { uploadProductMatrix } from "../../../../service/Product.service";

import { ProductSelector } from './ProductSelector';
import { MatrixCard } from './MatrixCard';

interface Step4Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  onBack: () => void;
}

interface WashingInstructionRecord {
  id: number;
  instruction: string;
  instruction_description: string;
}

export const Step4Form: React.FC<Step4Props> = ({ state, updateState, onNext }) => {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  
  const [matrixTemplateMap, setMatrixTemplateMap] = useState<Record<string, string[]>>({});
  const [materialsList, setMaterialsList] = useState<string[]>([]);
  const [washInstructions, setWashInstructions] = useState<WashingInstructionRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const currentItem = state.catalogProducts[activeIdx];

  useEffect(() => {
    const fetchConfigurationData = async () => {
      try {
        setIsLoading(true);
        const [structuresRes, materialsRes, washRes] = await Promise.all([
          getStructures(""),
          getMaterials(),
          getWashingInstructions()
        ]);

        if (structuresRes?.success && Array.isArray(structuresRes.data)) {
          const generatedMap: Record<string, string[]> = {};
          structuresRes.data.forEach((item: any) => {
            generatedMap[item.main_name] = item.includes.map((inc: any) => inc.product);
          });
          setMatrixTemplateMap(generatedMap);
        }

        if (materialsRes?.success && Array.isArray(materialsRes.data)) {
          const textList = materialsRes.data.map((item: any) => item.material_name);
          setMaterialsList(textList);
        }

        if (washRes) {
          const washData = Array.isArray(washRes) ? washRes : washRes?.data || [];
          setWashInstructions(washData);
        }
      } catch (error) {
        console.error("Configuration framework loading crash:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchConfigurationData();
  }, []);

  const handleMatrixSelection = (type: string) => {
    const componentNames = matrixTemplateMap[type] || [];
    const rows: MatrixRow[] = componentNames.map(name => ({
      componentName: name, material: '', color: '', length: '', width: '', washingInstruction: ''
    }));
    updateProductFields({ matrixType: type, matrixRows: rows });
  };

  const updateProductFields = (fields: Partial<typeof currentItem>) => {
    const updated = [...state.catalogProducts];
    updated[activeIdx] = { ...currentItem, ...fields };
    updateState({ catalogProducts: updated });
  };

  const updateRowValue = (rowIdx: number, field: string, value: string) => {
    const updatedRows = [...currentItem.matrixRows];
    updatedRows[rowIdx] = { ...updatedRows[rowIdx], [field]: value };
    updateProductFields({ matrixRows: updatedRows });
  };

  const applyMatrixStructureToAll = () => {
    const updated = state.catalogProducts.map(p => ({
      ...p,
      matrixType: currentItem.matrixType,
      matrixRows: JSON.parse(JSON.stringify(currentItem.matrixRows))
    }));
    updateState({ catalogProducts: updated });
  };

  const matrixOptions = [
    { value: '', label: '-- Choose Matrix Base --' },
    ...Object.keys(matrixTemplateMap).map(k => ({ value: k, label: k }))
  ];

  const washOptions = [
    { value: '', label: '-- Choose Care Routine --' },
    ...washInstructions.map(item => ({ value: item.instruction, label: item.instruction }))
  ];

  const checkIsFormValid = (): boolean => {
    if (!state.catalogProducts || state.catalogProducts.length === 0) return false;

    return state.catalogProducts.every((product) => {
      if (!product.matrixType || !product.matrixRows || product.matrixRows.length === 0) {
        return false;
      }

      return product.matrixRows.every((row) => {
        const materialValid = typeof row.material === 'string' && row.material.trim() !== '';
        const colorValid = typeof row.color === 'string' && row.color.trim() !== '';
        const washValid = typeof row.washingInstruction === 'string' && row.washingInstruction.trim() !== '';
        const lengthValid = row.length !== undefined && row.length !== null && row.length.toString().trim() !== '';
        const widthValid = row.width !== undefined && row.width !== null && row.width.toString().trim() !== '';

        return materialValid && colorValid && washValid && lengthValid && widthValid;
      });
    });
  };

  const isFormValid = checkIsFormValid();

  const handleSaveAndContinue = async () => {
    try {
      setIsSaving(true);

      if (!isFormValid) {
        alert("Please complete all layouts and fill up every product matrix detail before moving forward.");
        return;
      }

      const payload = state.catalogProducts.map((productItem: any) => ({
        productId: productItem.backendProductId, 
        productMatrix: productItem.matrixRows.map((row: any) => {
          const matchedWash = washInstructions.find(w => w.instruction === row.washingInstruction);

          return {
            product: row.componentName,
            material: row.material,
            colour: row.color, 
            length: row.length?.toString() || "0", 
            width: row.width?.toString() || "0",
            washingInstructionId: matchedWash ? matchedWash.id : null 
          };
        })
      }));

      await uploadProductMatrix(payload as any);
      onNext();
    } catch (err) {
      console.error("Failed to store matrix arrays:", err);
      alert(typeof err === 'string' ? err : 'Failed to synchronize product configurations with backend.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="py-12 flex flex-col items-center justify-center space-y-3 text-text-muted text-xs">
        <div className="animate-spin rounded-full h-6 w-6 border-2 border-brand-maroon-500 border-t-transparent"></div>
        <span>Syncing matrix configuration rules...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Dynamic Selector Slider */}
      <ProductSelector 
        activeIdx={activeIdx}
        totalProducts={state.catalogProducts.length}
        onPrev={() => setActiveIdx(p => p - 1)}
        onNext={() => setActiveIdx(p => p + 1)}
      />

      {/* Blueprint Picker Info */}
      <div className="flex gap-4 items-end">
        <div className="w-16 h-16 rounded-xl border border-border-main overflow-hidden shrink-0 bg-bg-main shadow-sm">
          {currentItem?.files?.[0]?.type === 'image' && (
            <img src={currentItem.files[0].url} className="w-full h-full object-cover" alt="Thumb" />
          )}
        </div>
        <div className="flex-1 max-w-xs">
          <Select 
            label="Layout Matrix Configuration Blueprint"
            value={currentItem?.matrixType || ''} 
            options={matrixOptions}
            onChange={(e) => handleMatrixSelection(e.target.value)} 
          />
        </div>
      </div>

      {/* Rows Map View */}
      {currentItem?.matrixRows?.length > 0 && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {currentItem.matrixRows.map((row, rIdx) => (
              <MatrixCard 
                key={rIdx}
                row={row}
                rIdx={rIdx}
                totalRowsCount={currentItem.matrixRows.length}
                materialsList={materialsList}
                washOptions={washOptions}
                updateRowValue={updateRowValue}
              />
            ))}
          </div>

          {/* Conditional Layout Replicate Option */}
          {state.catalogProducts.length > 1 && (
            <button 
              onClick={applyMatrixStructureToAll} 
              className="w-full text-xs border border-brand-gold-500 bg-brand-gold-500/5 text-brand-gold-500 p-2.5 rounded-xl font-bold hover:bg-brand-gold-500/10 transition-colors shadow-sm"
            >
              ⚡ Replicate this identical matrix structure layout to all catalog variants
            </button>
          )}
        </div>
      )}

      {/* Footer Navigation Panel */}
      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button 
          onClick={handleSaveAndContinue} 
          disabled={isSaving || !isFormValid}
          className="flex-1 bg-brand-maroon-500 disabled:bg-gray-300 disabled:cursor-not-allowed disabled:text-text-muted text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors flex items-center justify-center space-x-2"
        >
          {isSaving ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
              <span>Saving structural data...</span>
            </>
          ) : (
            <span>{isFormValid ? "Continue to Instructions" : "Fill All Matrices to Continue"}</span>
          )}
        </button>
      </div>
    </div>
  );
};