import React, { useState, useRef, useEffect } from 'react';
import { Input } from '../../../commonComponents/Input';

interface MaterialInputProps {
  value: string;
  onChange: (val: string) => void;
  materialsList: string[];
  label?: string;
  className?: string;
}

export const MaterialAutoSuggest: React.FC<MaterialInputProps> = ({ 
  value, 
  onChange, 
  materialsList, 
  label = "", 
  className = "" 
}) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const filtered = materialsList.filter(m => 
    m.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div ref={containerRef} className="relative w-full">
      <Input 
        label={label} 
        value={value} 
        onChange={(e) => { onChange(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder="Type fabric structure..."
        className={className}
      />
      {open && filtered.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-bg-card border border-border-main rounded-md shadow-lg z-30 divide-y divide-border-main max-h-48 overflow-y-auto">
          {filtered.map(m => (
            <div 
              key={m} 
              onClick={() => { onChange(m); setOpen(false); }} 
              className="p-2 cursor-pointer hover:bg-bg-main text-text-main text-xs transition-colors"
            >
              {m}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};