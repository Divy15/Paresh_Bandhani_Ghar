import React from 'react';
import { Input } from '../../../commonComponents/Input';
import { Select } from '../../../commonComponents/Select';
import { NumberInput } from "../../../commonComponents/NumberInput";
import { MaterialAutoSuggest } from './MaterialAutoSuggest';
import type { MatrixRow as BaseMatrixRow } from '../ProductDetails.types';

interface MatrixCardProps {
  row: MatrixRow;
  rIdx: number;
  totalRowsCount: number;
  materialsList: string[];
  washOptions: Array<{ value: string; label: string }>;
  updateRowValue: (rowIdx: number, field: string, value: string) => void;
}

// Extend the base interface locally
export interface MatrixRow extends BaseMatrixRow {
  washingInstruction?: string;
}

export const MatrixCard: React.FC<MatrixCardProps> = ({
  row,
  rIdx,
  totalRowsCount,
  materialsList,
  washOptions,
  updateRowValue,
}) => {
  return (
    <div 
      className="border border-border-main rounded-xl bg-bg-card shadow-sm hover:border-brand-maroon-500/30 transition-all flex flex-col relative"
      style={{ zIndex: totalRowsCount + 10 - rIdx }}
    >
      {/* Header Badge Area */}
      <div className="p-3 bg-bg-main/40 border-b border-border-main rounded-t-xl flex justify-between items-center">
        <span className="text-xs font-bold tracking-wide text-text-main truncate max-w-[80%]">
          {row.componentName}
        </span>
        <span className="text-[10px] uppercase font-bold tracking-widest bg-brand-maroon-500/10 text-brand-maroon-500 px-2 py-0.5 rounded-md">
          Item {rIdx + 1}
        </span>
      </div>

      {/* Form Inputs Body */}
      <div className="p-4 space-y-4 flex-1">
        <MaterialAutoSuggest 
          label="Material Variant"
          value={row.material}
          onChange={(val) => updateRowValue(rIdx, 'material', val)}
          materialsList={materialsList}
          className="bg-bg-main/20 text-xs"
        />

        <Input 
          label="Color / Shade"
          value={row.color}
          onChange={(e) => updateRowValue(rIdx, 'color', e.target.value)}
          placeholder="e.g. Royal Blue"
          className="bg-bg-main/20 text-xs"
        />

        <Select
          label="Washing Instruction Rule"
          value={row.washingInstruction || ''}
          options={washOptions}
          onChange={(e) => updateRowValue(rIdx, 'washingInstruction', e.target.value)}
          className="bg-bg-main/20 text-xs"
        />

        {/* Dimensional Metrics Cluster */}
        <div className="pt-2 border-t border-border-main/40">
          <span className="block text-[10px] uppercase font-bold tracking-wider text-text-muted mb-2">Specifications</span>
          <div className="grid grid-cols-3 gap-2">
            <NumberInput 
              label="Len (Mtr)" 
              value={row.length} 
              onChange={(val) => updateRowValue(rIdx, 'length', val)} 
              className="bg-bg-main/20 text-xs text-center" 
            />
            <NumberInput 
              label="Wid (Mtr)" 
              value={row.width} 
              onChange={(val) => updateRowValue(rIdx, 'width', val)} 
              className="bg-bg-main/20 text-xs text-center" 
            />
          </div>
        </div>
      </div>
    </div>
  );
};