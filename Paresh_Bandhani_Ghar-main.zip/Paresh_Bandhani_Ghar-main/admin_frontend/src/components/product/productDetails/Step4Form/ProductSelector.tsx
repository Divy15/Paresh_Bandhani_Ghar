import React from 'react';

interface ProductSelectorProps {
  activeIdx: number;
  totalProducts: number;
  onPrev: () => void;
  onNext: () => void;
}

export const ProductSelector: React.FC<ProductSelectorProps> = ({
  activeIdx,
  totalProducts,
  onPrev,
  onNext
}) => {
  return (
    <div className="flex items-center justify-between bg-bg-main p-2 rounded-xl border border-border-main">
      <button 
        disabled={activeIdx === 0} 
        onClick={onPrev} 
        className="px-3 py-1 bg-bg-card rounded-md text-xs font-bold disabled:opacity-40 transition-opacity"
      >
        ← Previous
      </button>
      <span className="text-sm font-semibold text-brand-maroon-500">
        Structural Matrix for Slot #{activeIdx + 1} of {totalProducts}
      </span>
      <button 
        disabled={activeIdx === totalProducts - 1} 
        onClick={onNext} 
        className="px-3 py-1 bg-bg-card rounded-md text-xs font-bold disabled:opacity-40 transition-opacity"
      >
        Next →
      </button>
    </div>
  );
};