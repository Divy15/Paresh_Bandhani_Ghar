import React, { useState } from 'react';
import type { SharedWizardState, CatalogProduct } from '../ProductDetails.types';
import { generateBatchPresignedUrls, storeProductMedia } from "../../../../service/Product.service";
import axios from 'axios';

// Component Imports
import { CatalogHeader } from './CatalogHeader';
import { ProductMediaCard } from './ProductMediaCard';

interface Step2Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  createProduct: () => CatalogProduct;
}

export const Step2Form: React.FC<Step2Props> = ({ state, updateState, onNext, createProduct }) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Check if every item slot has at least one media asset uploaded
  const hasUploadedMediaInAllSlots = state.catalogProducts.every(p => p.files.length > 0);

  const addProductSlot = () => {
    updateState({ catalogProducts: [...state.catalogProducts, createProduct()] });
  };

  const removeProductSlot = (indexToRemove: number) => {
    const updated = state.catalogProducts.filter((_, idx) => idx !== indexToRemove);
    updateState({ catalogProducts: updated });
  };

  const handleFileChange = (index: number, fileList: FileList) => {
    const updated = [...state.catalogProducts];
    const currentFiles = updated[index].files;

    Array.from(fileList).forEach(file => {
      const isVideo = file.type.startsWith('video/');
      const localUrl = URL.createObjectURL(file);

      // Set default cover if this is the first image added
      const shouldBeCover = !isVideo && !currentFiles.some(f => f.isCover);

      currentFiles.push({
        url: localUrl,
        fileBlob: file,
        type: isVideo ? 'video' : 'image',
        isCover: shouldBeCover
      });
    });

    updateState({ catalogProducts: updated });
  };

  const removeFile = (productIndex: number, fileIndex: number) => {
    const updated = [...state.catalogProducts];
    const removedWasCover = updated[productIndex].files[fileIndex].isCover;

    URL.revokeObjectURL(updated[productIndex].files[fileIndex].url);
    updated[productIndex].files.splice(fileIndex, 1);

    // Cover Fallback reassignment strategy
    if (removedWasCover && updated[productIndex].files.length > 0) {
      const nextImageIdx = updated[productIndex].files.findIndex(f => f.type === 'image');
      if (nextImageIdx !== -1) {
        updated[productIndex].files[nextImageIdx].isCover = true;
      }
    }

    updateState({ catalogProducts: updated });
  };

  const setCoverPhoto = (productIndex: number, fileIndex: number) => {
    const updated = [...state.catalogProducts];

    if (updated[productIndex].files[fileIndex].type === 'video') return;

    updated[productIndex].files = updated[productIndex].files.map((file, idx) => ({
      ...file,
      isCover: idx === fileIndex
    }));

    updateState({ catalogProducts: updated });
  };

  const handleMediaUploadSync = async () => {
    setUploadError(null);

    if (!hasUploadedMediaInAllSlots) {
      setUploadError("Please provide at least one media asset for each item slot.");
      return;
    }

    setIsUploading(true);
    try {
      const payload = {
        catalogId: state.catalogId,
        products: state.catalogProducts.map(prod => ({
          files: prod.files.map(f => ({
            clientFilename: f.fileBlob.name,
            contentType: f.fileBlob.type,
            contentLength: f.fileBlob.size
          }))
        }))
      };

      const response = await generateBatchPresignedUrls(payload);
      const updatedProducts = [...state.catalogProducts];

      for (let i = 0; i < response.products.length; i++) {
        const backendProduct = response.products[i];
        const clientProduct = updatedProducts[i];

        clientProduct.backendProductId = backendProduct.productId;

        for (let j = 0; j < clientProduct.files.length; j++) {
          const clientFile = clientProduct.files[j];
          const presignedInfo = backendProduct.uploads[j];

          await axios.put(presignedInfo.uploadUrl, clientFile.fileBlob, {
            headers: { 'Content-Type': clientFile.fileBlob.type }
          });

          clientFile.permanentUrl = presignedInfo.permanentUrl;
        }
      }

      const mediaConfirmationPayload = {
        catalogId: state.catalogId,
        media: updatedProducts.flatMap(prod =>
          prod.files.map(file => ({
            productId: prod.backendProductId,
            path: file.permanentUrl,
            isCover: !!file.isCover
          }))
        )
      };

      await storeProductMedia(mediaConfirmationPayload);
      updateState({ catalogProducts: updatedProducts });
      onNext();
    } catch (err: any) {
      console.error(err);
      setUploadError(err?.response?.data?.message || err?.message || "Failed uploading asset pipelines or writing to database.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <CatalogHeader state={state} />

      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h3 className="text-lg font-semibold text-text-main font-serif">Upload Media Registry Assets</h3>
          <p className="text-xs text-text-muted">Upload media files and set your primary item cover display thumbnails.</p>
        </div>
        <button
          onClick={addProductSlot}
          disabled={isUploading}
          className="disabled:opacity-50 border border-brand-maroon-500/30 text-brand-maroon-500 bg-brand-maroon-500/5 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-brand-maroon-500/10 transition-colors"
        >
          + Add Item Slot to Catalog
        </button>
      </div>

      {uploadError && (
        <div className="p-3 text-xs font-semibold rounded-xl bg-red-50 text-red-600 border border-red-200">
          ⚠️ {uploadError}
        </div>
      )}

      {/* Grid containing modular product cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {state.catalogProducts.map((prod, idx) => (
          <ProductMediaCard
            key={prod.id}
            product={prod}
            index={idx}
            totalProducts={state.catalogProducts.length}
            isUploading={isUploading}
            onRemoveSlot={removeProductSlot}
            onFileChange={handleFileChange}
            onRemoveFile={removeFile}
            onSetCover={setCoverPhoto}
          />
        ))}
      </div>

      {/* Navigation Controls Bar */}
      <div className="pt-4 border-t border-border-main/60">
        <button
          onClick={handleMediaUploadSync}
          disabled={isUploading || !hasUploadedMediaInAllSlots}
          className="w-full bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-zinc-300 dark:disabled:bg-zinc-800 disabled:text-text-muted"
        >
          {isUploading ? (
            <>
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Uploading Media to Cloud...
            </>
          ) : (
            "Continue to Primary Details"
          )}
        </button>
      </div>
    </div>
  );
};