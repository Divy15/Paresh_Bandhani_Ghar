import React from 'react';
import type { SharedWizardState } from '../ProductDetails.types';

interface CatalogHeaderProps {
  state: SharedWizardState;
}

export const CatalogHeader: React.FC<CatalogHeaderProps> = ({ state }) => {
  if (!state.catalogId) return null;

  return (
    <div className="bg-bg-main border border-border-main/70 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
      {/* Left Side: Registry Metadata */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-text-muted font-bold">Catalog ID</p>
          <p className="font-mono text-sm font-bold text-text-main tracking-wide">{state.catalogId}</p>
        </div>
      </div>

      {/* Right Side: Categorization Path */}
      {(state.category_name || state.subcategory_name) && (
        <div className="flex flex-col md:items-end justify-center border-t md:border-t-0 border-border-main/50 pt-3 md:pt-0">
          <p className="text-[10px] uppercase tracking-wider text-text-muted font-bold mb-1">Target Classification</p>
          <div className="flex items-center gap-2 flex-wrap">
            {state.category_name && (
              <span className="bg-brand-maroon-500/10 border border-brand-maroon-500/20 text-brand-maroon-600 px-3 py-1 rounded-lg font-bold text-[11px] shadow-sm">
                {state.category_name}
              </span>
            )}
            {state.category_name && state.subcategory_name && (
              <span className="text-text-muted text-xs font-semibold px-1">/</span>
            )}
            {state.subcategory_name && (
              <span className="bg-brand-maroon-500/10 border border-brand-maroon-500/20 text-brand-maroon-600 px-3 py-1 rounded-lg font-bold text-[11px] shadow-sm">
                {state.subcategory_name}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};