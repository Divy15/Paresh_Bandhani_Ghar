import React from 'react';
import type { CatalogProduct } from '../ProductDetails.types';
import { FileUpload } from "../../../commonComponents/FileUpload";

interface ProductMediaCardProps {
  product: CatalogProduct;
  index: number;
  totalProducts: number;
  isUploading: boolean;
  onRemoveSlot: (index: number) => void;
  onFileChange: (index: number, files: FileList) => void;
  onRemoveFile: (productIndex: number, fileIndex: number) => void;
  onSetCover: (productIndex: number, fileIndex: number) => void;
}

export const ProductMediaCard: React.FC<ProductMediaCardProps> = ({
  product,
  index,
  totalProducts,
  isUploading,
  onRemoveSlot,
  onFileChange,
  onRemoveFile,
  onSetCover,
}) => {
  return (
    <div className="border border-border-main bg-bg-card p-5 rounded-2xl space-y-4 shadow-sm relative">
      <div className="flex justify-between items-center border-b border-border-main/50 pb-2">
        <span className="text-xs font-mono font-bold text-brand-maroon-500 bg-brand-maroon-500/5 px-2 py-0.5 rounded">
          Item #{index + 1}
        </span>
        {totalProducts > 1 && (
          <button
            type="button"
            disabled={isUploading}
            onClick={() => onRemoveSlot(index)}
            className="text-xs text-red-500 hover:text-red-700 font-medium disabled:opacity-30"
          >
            ✕ Remove Item
          </button>
        )}
      </div>

      <FileUpload
        label="Select Media Assets"
        onChange={(files) => onFileChange(index, files)}
        multiple={true}
        accept="image/*,video/*"
      />

      {product.files.length > 0 && (
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-text-muted">
            Uploaded Files ({product.files.length}) — Click image to set as Cover Photo
          </span>
          <div className="grid grid-cols-4 gap-2">
            {product.files.map((file, fileIdx) => (
              <div
                key={fileIdx}
                onClick={() => onSetCover(index, fileIdx)}
                className={`aspect-square rounded-lg bg-bg-main border overflow-hidden relative cursor-pointer transition-all group ${
                  file.isCover 
                    ? 'border-brand-maroon-500 ring-2 ring-brand-maroon-500/30 shadow-md' 
                    : 'border-border-main hover:border-text-muted'
                }`}
              >
                {file.type === 'image' ? (
                  <img src={file.url} className="w-full h-full object-cover" alt="preview" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-zinc-800 text-white text-[9px] font-bold p-1 text-center">
                    <span>🎥 VIDEO</span>
                  </div>
                )}

                {/* Cover Photo Badge Overlay */}
                {file.isCover && (
                  <div className="absolute bottom-0 left-0 right-0 bg-brand-maroon-500 text-white text-[8px] font-bold text-center py-0.5 uppercase tracking-wide">
                    ★ Cover
                  </div>
                )}

                {/* Delete button */}
                <button
                  type="button"
                  disabled={isUploading}
                  onClick={(e) => {
                    e.stopPropagation(); // Stop cover switch triggering
                    onRemoveFile(index, fileIdx);
                  }}
                  className="absolute top-1 right-1 w-4 h-4 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center text-[10px] z-10 disabled:opacity-30"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};