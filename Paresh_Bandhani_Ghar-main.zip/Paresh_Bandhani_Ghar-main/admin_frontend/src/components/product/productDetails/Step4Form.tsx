import React, { useState, useRef, useEffect } from 'react';
import type { SharedWizardState, MatrixRow } from './ProductDetails.types';
import { Input } from '../../commonComponents/Input';
import { Select } from '../../commonComponents/Select';
import { NumberInput } from "../../commonComponents/NumberInput";

interface Step4Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  onBack: () => void;
}

const MATRIX_TEMPLATE_MAP: Record<string, string[]> = {
  'Dress': ['Top', 'Bottom', 'Dupatta'],
  'Saree': ['Saree Body', 'Blouse Piece'],
  'Dupatta': ['Dupatta Body']
};

const DUMMY_MATERIALS = ['Gaji Silk', 'Pure Georgette', 'Kora Cotton', 'Chanderi', 'Modal Silk'];
const DUMMY_COLORS = ['Crimson Red', 'Mustard Yellow', 'Royal Blue', 'Emerald Green', 'Indigo', 'Maroon', 'Ivory White', 'Charcoal Black', 'Olive Green', 'Peach Pink'];

/* -------------------------------------------------------------------------- */
/*                 STANDALONE AUTO-SUGGEST MATERIAL COMPONENT                 */
/* -------------------------------------------------------------------------- */
interface MaterialInputProps {
  value: string;
  onChange: (val: string) => void;
  label?: string;
  className?: string;
}

const MaterialAutoSuggest: React.FC<MaterialInputProps> = ({ value, onChange, label = "", className = "" }) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const filtered = DUMMY_MATERIALS.filter(m => 
    m.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div ref={containerRef} className="relative w-full">
      <Input 
        label={label} 
        value={value} 
        onChange={(e) => { onChange(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder="Type fabric structure..."
        className={className}
      />
      {open && filtered.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-bg-card border border-border-main rounded-md shadow-lg z-30 divide-y divide-border-main max-h-48 overflow-y-auto">
          {filtered.map(m => (
            <div 
              key={m} 
              onClick={() => { onChange(m); setOpen(false); }} 
              className="p-2 cursor-pointer hover:bg-bg-main text-text-main text-xs transition-colors"
            >
              {m}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/*                  STANDALONE AUTO-SUGGEST COLOR COMPONENT                   */
/* -------------------------------------------------------------------------- */
interface ColorInputProps {
  value: string;
  onChange: (val: string) => void;
  label?: string;
  className?: string;
}

const ColorAutoSuggest: React.FC<ColorInputProps> = ({ value, onChange, label = "", className = "" }) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const filtered = DUMMY_COLORS.filter(c => 
    c.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div ref={containerRef} className="relative w-full">
      <Input 
        label={label} 
        value={value} 
        onChange={(e) => { onChange(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder="e.g. Indigo"
        className={className}
      />
      {open && filtered.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-bg-card border border-border-main rounded-md shadow-lg z-30 divide-y divide-border-main max-h-48 overflow-y-auto">
          {filtered.map(c => (
            <div 
              key={c} 
              onClick={() => { onChange(c); setOpen(false); }} 
              className="p-2 cursor-pointer hover:bg-bg-main text-text-main text-xs transition-colors"
            >
              {c}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/*                             MAIN FORM COMPONENT                            */
/* -------------------------------------------------------------------------- */
export const Step4Form: React.FC<Step4Props> = ({ state, updateState, onNext, onBack }) => {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  const currentItem = state.catalogProducts[activeIdx];

  const handleMatrixSelection = (type: string) => {
    const componentNames = MATRIX_TEMPLATE_MAP[type] || [];
    const rows: MatrixRow[] = componentNames.map(name => ({
      componentName: name, material: '', color: '', length: '', width: '', weight: ''
    }));
    updateProductFields({ matrixType: type, matrixRows: rows });
  };

  const updateProductFields = (fields: Partial<typeof currentItem>) => {
    const updated = [...state.catalogProducts];
    updated[activeIdx] = { ...currentItem, ...fields };
    updateState({ catalogProducts: updated });
  };

  const updateRowValue = (rowIdx: number, field: keyof MatrixRow, value: string) => {
    const updatedRows = [...currentItem.matrixRows];
    updatedRows[rowIdx] = { ...updatedRows[rowIdx], [field]: value };
    updateProductFields({ matrixRows: updatedRows });
  };

  const applyMatrixStructureToAll = () => {
    const updated = state.catalogProducts.map(p => ({
      ...p,
      matrixType: currentItem.matrixType,
      matrixRows: JSON.parse(JSON.stringify(currentItem.matrixRows))
    }));
    updateState({ catalogProducts: updated });
  };

  const matrixOptions = [
    { value: '', label: '-- Choose Matrix Base --' },
    ...Object.keys(MATRIX_TEMPLATE_MAP).map(k => ({ value: k, label: k }))
  ];

  return (
    <div className="space-y-6">
      {/* Product Selector Control */}
      <div className="flex items-center justify-between bg-bg-main p-2 rounded-xl border border-border-main">
        <button disabled={activeIdx === 0} onClick={() => setActiveIdx(p => p - 1)} className="px-3 py-1 bg-bg-card rounded-md text-xs font-bold disabled:opacity-40 transition-opacity">← Previous</button>
        <span className="text-sm font-semibold text-brand-maroon-500">Structural Matrix for Slot #{activeIdx + 1}</span>
        <button disabled={activeIdx === state.catalogProducts.length - 1} onClick={() => setActiveIdx(p => p + 1)} className="px-3 py-1 bg-bg-card rounded-md text-xs font-bold disabled:opacity-40 transition-opacity">Next →</button>
      </div>

      <div className="flex gap-4 items-end">
        <div className="w-16 h-16 rounded-xl border border-border-main overflow-hidden shrink-0 bg-bg-main shadow-sm">
          {currentItem?.files?.[0]?.type === 'image' && <img src={currentItem.files[0].url} className="w-full h-full object-cover" alt="Thumb" />}
        </div>
        <div className="flex-1 max-w-xs">
          <Select 
            label="Layout Matrix Configuration Blueprint"
            value={currentItem?.matrixType || ''} 
            options={matrixOptions}
            onChange={(e) => handleMatrixSelection(e.target.value)} 
          />
        </div>
      </div>

      {currentItem?.matrixRows?.length > 0 && (
        <div className="space-y-4">
          {/* A. DESKTOP WORKSPACE TABLE VIEW */}
          <div className="hidden lg:block border border-border-main rounded-xl overflow-hidden bg-bg-card shadow-sm">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-bg-main border-b border-border-main text-text-muted uppercase font-bold tracking-wider">
                  <th className="p-3">Component Item</th>
                  <th className="p-3">Material Descriptor</th>
                  <th className="p-3">Color Space</th>
                  <th className="p-3">Length (Mtr)</th>
                  <th className="p-3">Width (Mtr)</th>
                  <th className="p-3">Weight (Grms)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-main align-middle">
                {currentItem.matrixRows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-bg-main/10 transition-colors">
                    <td className="p-3 font-semibold text-text-main bg-bg-main/10 w-48">{row.componentName}</td>
                    
                    {/* Desktop Material Search Input */}
                    <td className="p-2 w-60">
                      <MaterialAutoSuggest 
                        value={row.material} 
                        onChange={(val) => updateRowValue(rIdx, 'material', val)} 
                        className="py-1.5 px-2.5 text-xs rounded-md"
                      />
                    </td>

                    {/* Desktop Color Search Input */}
                    <td className="p-2 w-48">
                      <ColorAutoSuggest 
                        value={row.color} 
                        onChange={(val) => updateRowValue(rIdx, 'color', val)} 
                        className="py-1.5 px-2.5 text-xs rounded-md" 
                      />
                    </td>

                    <td className="p-2">
                      <NumberInput value={row.length} onChange={(val) => updateRowValue(rIdx, 'length', val)} placeholder="Meters" className="py-1.5 px-2.5 text-xs rounded-md" />
                    </td>
                    <td className="p-2">
                      <NumberInput value={row.width} onChange={(val) => updateRowValue(rIdx, 'width', val)} placeholder="Meters" className="py-1.5 px-2.5 text-xs rounded-md" />
                    </td>
                    <td className="p-2">
                      <NumberInput value={row.weight} onChange={(val) => updateRowValue(rIdx, 'weight', val)} placeholder="Grams" className="py-1.5 px-2.5 text-xs rounded-md" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* B. MOBILE COMPONENT STACKING RESPONSIVE PANELS */}
          <div className="block lg:hidden space-y-4">
            {currentItem.matrixRows.map((row, rIdx) => (
              <div key={rIdx} className="border border-border-main rounded-xl p-4 bg-bg-main/20 space-y-4 shadow-sm">
                <div className="text-xs font-bold text-brand-maroon-500 border-b border-border-main pb-1.5 tracking-wide">{row.componentName} Attributes</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Mobile Material Search Input */}
                  <MaterialAutoSuggest 
                    label="Material"
                    value={row.material}
                    onChange={(val) => updateRowValue(rIdx, 'material', val)}
                    className="bg-bg-card text-xs"
                  />

                  {/* Mobile Color Search Input */}
                  <ColorAutoSuggest 
                    label="Color Variant"
                    value={row.color}
                    onChange={(val) => updateRowValue(rIdx, 'color', val)}
                    className="bg-bg-card text-xs"
                  />

                  <div className="grid grid-cols-3 gap-2 col-span-1 md:col-span-2">
                    <NumberInput 
                      label="Len (M)" 
                      value={row.length} 
                      onChange={(val) => updateRowValue(rIdx, 'length', val)} 
                      className="bg-bg-card text-xs text-center" 
                    />
                    <NumberInput 
                      label="Wid (M)" 
                      value={row.width} 
                      onChange={(val) => updateRowValue(rIdx, 'width', val)} // fixed a missing argument bug here
                      className="bg-bg-card text-xs text-center" 
                    />
                    <NumberInput 
                      label="Wt (G)" 
                      value={row.weight} 
                      onChange={(val) => updateRowValue(rIdx, 'weight', val)} 
                      className="bg-bg-card text-xs text-center" 
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button onClick={applyMatrixStructureToAll} className="w-full text-xs border border-brand-gold-500 bg-brand-gold-500/5 text-brand-gold-500 p-2.5 rounded-xl font-bold hover:bg-brand-gold-500/10 transition-colors shadow-sm">
            ⚡ Replicate this identical matrix structure layout to all catalog variants
          </button>
        </div>
      )}

      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button onClick={onBack} className="flex-1 border border-border-main p-2.5 rounded-xl font-semibold text-sm text-text-muted hover:bg-bg-main transition-colors">Back</button>
        <button onClick={onNext} className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors">Continue to Instructions</button>
      </div>
    </div>
  );
};