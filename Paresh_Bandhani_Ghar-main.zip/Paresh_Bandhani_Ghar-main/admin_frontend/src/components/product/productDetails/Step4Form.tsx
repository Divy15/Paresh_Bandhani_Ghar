import React, { useState, useRef, useEffect } from 'react';
import type { SharedWizardState, MatrixRow } from './ProductDetails.types';
import { Input } from '../../commonComponents/Input';
import { Select } from '../../commonComponents/Select';
import { NumberInput } from "../../commonComponents/NumberInput";
import { getStructures, getMaterials, getWashingInstructions } from "../../../service/Configuration.service"
import { uploadProductMatrix } from "../../../service/Product.service"

interface Step4Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  onBack: () => void;
}

interface WashingInstructionRecord {
  id: number;
  instruction: string;
  instruction_description: string;
}

/* -------------------------------------------------------------------------- */
/*                 STANDALONE AUTO-SUGGEST MATERIAL COMPONENT                 */
/* -------------------------------------------------------------------------- */
interface MaterialInputProps {
  value: string;
  onChange: (val: string) => void;
  materialsList: string[];
  label?: string;
  className?: string;
}

const MaterialAutoSuggest: React.FC<MaterialInputProps> = ({ value, onChange, materialsList, label = "", className = "" }) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const filtered = materialsList.filter(m => 
    m.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div ref={containerRef} className="relative w-full">
      <Input 
        label={label} 
        value={value} 
        onChange={(e) => { onChange(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder="Type fabric structure..."
        className={className}
      />
      {open && filtered.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-bg-card border border-border-main rounded-md shadow-lg z-30 divide-y divide-border-main max-h-48 overflow-y-auto">
          {filtered.map(m => (
            <div 
              key={m} 
              onClick={() => { onChange(m); setOpen(false); }} 
              className="p-2 cursor-pointer hover:bg-bg-main text-text-main text-xs transition-colors"
            >
              {m}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/*                             MAIN FORM COMPONENT                            */
/* -------------------------------------------------------------------------- */
export const Step4Form: React.FC<Step4Props> = ({ state, updateState, onNext, onBack }) => {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  
  const [matrixTemplateMap, setMatrixTemplateMap] = useState<Record<string, string[]>>({});
  const [materialsList, setMaterialsList] = useState<string[]>([]);
  const [washInstructions, setWashInstructions] = useState<WashingInstructionRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const currentItem = state.catalogProducts[activeIdx];

  useEffect(() => {
    const fetchConfigurationData = async () => {
      try {
        setIsLoading(true);
        // 1. Pulled getWashingInstructions directly into initial parallel load framework
        const [structuresRes, materialsRes, washRes] = await Promise.all([
          getStructures(""),
          getMaterials(),
          getWashingInstructions()
        ]);

        if (structuresRes?.success && Array.isArray(structuresRes.data)) {
          const generatedMap: Record<string, string[]> = {};
          structuresRes.data.forEach((item: any) => {
            generatedMap[item.main_name] = item.includes.map((inc: any) => inc.product);
          });
          setMatrixTemplateMap(generatedMap);
        }

        if (materialsRes?.success && Array.isArray(materialsRes.data)) {
          const textList = materialsRes.data.map((item: any) => item.material_name);
          setMaterialsList(textList);
        }

        // 2. Unpack care items cleanly into reference state
        if (washRes) {
          const washData = Array.isArray(washRes) ? washRes : washRes?.data || [];
          setWashInstructions(washData);
        }
      } catch (error) {
        console.error("Configuration framework loading crash:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchConfigurationData();
  }, []);

  const handleMatrixSelection = (type: string) => {
    const componentNames = matrixTemplateMap[type] || [];
    // Initialize matrix rows with an empty washingInstruction string value
    const rows: MatrixRow[] = componentNames.map(name => ({
      componentName: name, material: '', color: '', length: '', width: '', washingInstruction: ''
    }));
    updateProductFields({ matrixType: type, matrixRows: rows });
  };

  const updateProductFields = (fields: Partial<typeof currentItem>) => {
    const updated = [...state.catalogProducts];
    updated[activeIdx] = { ...currentItem, ...fields };
    updateState({ catalogProducts: updated });
  };

  const updateRowValue = (rowIdx: number, field: string, value: string) => {
    const updatedRows = [...currentItem.matrixRows];
    updatedRows[rowIdx] = { ...updatedRows[rowIdx], [field]: value };
    updateProductFields({ matrixRows: updatedRows });
  };

  const applyMatrixStructureToAll = () => {
    const updated = state.catalogProducts.map(p => ({
      ...p,
      matrixType: currentItem.matrixType,
      matrixRows: JSON.parse(JSON.stringify(currentItem.matrixRows))
    }));
    updateState({ catalogProducts: updated });
  };

  const matrixOptions = [
    { value: '', label: '-- Choose Matrix Base --' },
    ...Object.keys(matrixTemplateMap).map(k => ({ value: k, label: k }))
  ];

  // Dynamic dropdown conversion map for care selectors
  const washOptions = [
    { value: '', label: '-- Choose Care Routine --' },
    ...washInstructions.map(item => ({ value: item.instruction, label: item.instruction }))
  ];

  const handleSaveAndContinue = async () => {
    try {
      setIsSaving(true);

      const baselineInvalid = state.catalogProducts.some(p => !p.matrixType || !p.matrixRows || p.matrixRows.length === 0);
      if (baselineInvalid) {
        alert("Please select a Layout Matrix Blueprint and ensure row values are set for all items before moving forward.");
        return;
      }

      // 3. Map values structurally while pulling instruction database relational IDs
      const payload = state.catalogProducts.map((productItem: any) => ({
        productId: productItem.backendProductId, 
        productMatrix: productItem.matrixRows.map((row: any) => {
          // Look up primary key ID matched to row-level selected care string name
          const matchedWash = washInstructions.find(w => w.instruction === row.washingInstruction);

          return {
            product: row.componentName,
            material: row.material,
            colour: row.color, 
            length: row.length?.toString() || "0", 
            width: row.width?.toString() || "0",
            // Appends individual component instruction IDs downstream safely
            washingInstructionId: matchedWash ? matchedWash.id : null 
          };
        })
      }));

      await uploadProductMatrix(payload as any);
      onNext();
    } catch (err) {
      console.error("Failed to store matrix arrays:", err);
      alert(typeof err === 'string' ? err : 'Failed to synchronize product configurations with backend.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="py-12 flex flex-col items-center justify-center space-y-3 text-text-muted text-xs">
        <div className="animate-spin rounded-full h-6 w-6 border-2 border-brand-maroon-500 border-t-transparent"></div>
        <span>Syncing matrix configuration rules...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Product Selector Control */}
      <div className="flex items-center justify-between bg-bg-main p-2 rounded-xl border border-border-main">
        <button disabled={activeIdx === 0} onClick={() => setActiveIdx(p => p - 1)} className="px-3 py-1 bg-bg-card rounded-md text-xs font-bold disabled:opacity-40 transition-opacity">← Previous</button>
        <span className="text-sm font-semibold text-brand-maroon-500">Structural Matrix for Slot #{activeIdx + 1}</span>
        <button disabled={activeIdx === state.catalogProducts.length - 1} onClick={() => setActiveIdx(p => p + 1)} className="px-3 py-1 bg-bg-card rounded-md text-xs font-bold disabled:opacity-40 transition-opacity">Next →</button>
      </div>

      <div className="flex gap-4 items-end">
        <div className="w-16 h-16 rounded-xl border border-border-main overflow-hidden shrink-0 bg-bg-main shadow-sm">
          {currentItem?.files?.[0]?.type === 'image' && <img src={currentItem.files[0].url} className="w-full h-full object-cover" alt="Thumb" />}
        </div>
        <div className="flex-1 max-w-xs">
          <Select 
            label="Layout Matrix Configuration Blueprint"
            value={currentItem?.matrixType || ''} 
            options={matrixOptions}
            onChange={(e) => handleMatrixSelection(e.target.value)} 
          />
        </div>
      </div>

      {currentItem?.matrixRows?.length > 0 && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {currentItem.matrixRows.map((row, rIdx) => (
              <div 
                key={rIdx} 
                className="border border-border-main rounded-xl bg-bg-card shadow-sm hover:border-brand-maroon-500/30 transition-all flex flex-col relative"
                style={{ zIndex: currentItem.matrixRows.length + 10 - rIdx }}
              >
                {/* Header Badge Area */}
                <div className="p-3 bg-bg-main/40 border-b border-border-main rounded-t-xl flex justify-between items-center">
                  <span className="text-xs font-bold tracking-wide text-text-main truncate max-w-[80%]">
                    {row.componentName}
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-widest bg-brand-maroon-500/10 text-brand-maroon-500 px-2 py-0.5 rounded-md">
                    Item {rIdx + 1}
                  </span>
                </div>

                {/* Form Inputs Body */}
                <div className="p-4 space-y-4 flex-1">
                  <MaterialAutoSuggest 
                    label="Material Variant"
                    value={row.material}
                    onChange={(val) => updateRowValue(rIdx, 'material', val)}
                    materialsList={materialsList}
                    className="bg-bg-main/20 text-xs"
                  />

                  <Input 
                    label="Color / Shade"
                    value={row.color}
                    onChange={(e) => updateRowValue(rIdx, 'color', e.target.value)}
                    placeholder="e.g. Royal Blue"
                    className="bg-bg-main/20 text-xs"
                  />

                  {/* 4. COMPONENT CARE SELECTOR INSERTION BLOCK */}
                  <Select
                    label="Washing Instruction Rule"
                    value={row.washingInstruction || ''}
                    options={washOptions}
                    onChange={(e) => updateRowValue(rIdx, 'washingInstruction', e.target.value)}
                    className="bg-bg-main/20 text-xs"
                  />

                  {/* Dimensional Metrics Cluster */}
                  <div className="pt-2 border-t border-border-main/40">
                    <span className="block text-[10px] uppercase font-bold tracking-wider text-text-muted mb-2">Specifications</span>
                    <div className="grid grid-cols-3 gap-2">
                      <NumberInput 
                        label="Len (Mtr)" 
                        value={row.length} 
                        onChange={(val) => updateRowValue(rIdx, 'length', val)} 
                        className="bg-bg-main/20 text-xs text-center" 
                      />
                      <NumberInput 
                        label="Wid (Mtr)" 
                        value={row.width} 
                        onChange={(val) => updateRowValue(rIdx, 'width', val)} 
                        className="bg-bg-main/20 text-xs text-center" 
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Action Footer */}
          <button onClick={applyMatrixStructureToAll} className="w-full text-xs border border-brand-gold-500 bg-brand-gold-500/5 text-brand-gold-500 p-2.5 rounded-xl font-bold hover:bg-brand-gold-500/10 transition-colors shadow-sm">
            ⚡ Replicate this identical matrix structure layout to all catalog variants
          </button>
        </div>
      )}

      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button 
          onClick={onBack} 
          disabled={isSaving}
          className="flex-1 border border-border-main p-2.5 rounded-xl font-semibold text-sm text-text-muted hover:bg-bg-main transition-colors disabled:opacity-50"
        >
          Back
        </button>
        <button 
          onClick={handleSaveAndContinue} 
          disabled={isSaving}
          className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors disabled:opacity-75 flex items-center justify-center space-x-2"
        >
          {isSaving ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
              <span>Saving structural data...</span>
            </>
          ) : (
            <span>Continue to Instructions</span>
          )}
        </button>
      </div>
    </div>
  );
};