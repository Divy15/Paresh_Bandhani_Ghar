import React, { useState } from 'react';
import type { SharedWizardState } from './ProductDetails.types';
import { NumberInput } from "../../commonComponents/NumberInput";
import { Input } from "../../commonComponents/Input";

interface Step3Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  onBack: () => void;
}

export const Step3Form: React.FC<Step3Props> = ({ state, updateState, onNext, onBack }) => {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  const currentItem = state.catalogProducts[activeIdx];

  const updateCurrentItem = (fields: Partial<typeof currentItem>) => {
    const updated = [...state.catalogProducts];
    updated[activeIdx] = { ...currentItem, ...fields };
    updateState({ catalogProducts: updated });
  };

  const applyToAll = () => {
    const updated = state.catalogProducts.map(p => ({
      ...p,
      name: currentItem.name,
      price: currentItem.price,
      quantity: currentItem.quantity
    }));
    updateState({ catalogProducts: updated });
  };

  return (
    <div className="space-y-6">
      {/* Dynamic Item Switcher */}
      <div className="flex items-center justify-between bg-bg-main p-2 rounded-xl border border-border-main">
        <button 
          disabled={activeIdx === 0} 
          onClick={() => setActiveIdx(p => p - 1)} 
          className="px-3 py-1 bg-bg-card rounded-md border border-border-main text-xs font-bold disabled:opacity-40 transition-opacity"
        >
          ← Prev Item
        </button>
        <span className="text-sm font-semibold text-brand-maroon-500">
          Editing Catalog Slot {activeIdx + 1} of {state.catalogProducts.length}
        </span>
        <button 
          disabled={activeIdx === state.catalogProducts.length - 1} 
          onClick={() => setActiveIdx(p => p + 1)} 
          className="px-3 py-1 bg-bg-card rounded-md border border-border-main text-xs font-bold disabled:opacity-40 transition-opacity"
        >
          Next Item →
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Cover Art Visual Column */}
        <div className="md:col-span-1 h-48 md:h-full bg-bg-main rounded-xl border border-border-main overflow-hidden relative">
          {currentItem?.files?.[0]?.type === 'image' ? (
            <img src={currentItem.files[0].url} className="w-full h-full object-cover" alt="Cover product" />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-text-muted text-xs p-4 text-center">
              <span>No cover art image configured for item.</span>
              <span className="text-[10px] mt-1 opacity-60">Upload assets in Step 2 to populate cover placeholder.</span>
            </div>
          )}
        </div>

        {/* Input Fields Panel */}
        <div className="md:col-span-2 space-y-4">
          {/* Custom Standard String Input */}
          <Input
            label="Product Descriptor Title"
            type="text"
            value={currentItem?.name || ''}
            onChange={(e) => updateCurrentItem({ name: e.target.value })}
            placeholder="Enter custom name variant..."
          />

          <div className="grid grid-cols-2 gap-4">
            {/* Custom Digit-Only Number Input */}
            <NumberInput
              label="Stock Quantity"
              value={currentItem?.quantity || ''}
              onChange={(val) => updateCurrentItem({ quantity: val })}
              placeholder="e.g. 50"
            />

            {/* Custom Price Input (Using standard input for symbols like ₹/$) */}
            <NumberInput
              label="Price Point"
              value={currentItem?.price || ''}
              onChange={(value) => updateCurrentItem({ price: value })}
              placeholder="e.g. ₹1,250"
            />
          </div>

          <button 
            onClick={applyToAll} 
            className="w-full mt-2 text-xs border border-brand-gold-500 bg-brand-gold-500/5 text-brand-gold-500 p-2.5 rounded-xl font-bold hover:bg-brand-gold-500/10 transition-colors"
          >
            ⚡ Apply these data points across all catalog slots
          </button>
        </div>
      </div>

      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button 
          onClick={onBack} 
          className="flex-1 border border-border-main p-2.5 rounded-xl font-semibold text-sm text-text-muted hover:bg-bg-main transition-colors"
        >
          Back
        </button>
        <button 
          onClick={onNext} 
          className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors"
        >
          Continue to Matrix Structural Properties
        </button>
      </div>
    </div>
  );
};