import React, { useState } from 'react';
import type { SharedWizardState } from './ProductDetails.types';
import { NumberInput } from "../../commonComponents/NumberInput";
import { Input } from "../../commonComponents/Input";
import { updateProductBatchDetails } from "../../../service/Product.service";

interface Step3Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  goToStep6: () => void; // New prop to jump straight to Step 6
}

export const Step3Form: React.FC<Step3Props> = ({ state, updateState, onNext, goToStep6 }) => {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const totalProducts = state.catalogProducts.length;
  const isSingleProduct = totalProducts === 1;
  const currentItem = state.catalogProducts[activeIdx];

  const updateCurrentItem = (fields: Partial<typeof currentItem>) => {
    const updated = [...state.catalogProducts];
    updated[activeIdx] = { ...currentItem, ...fields };
    updateState({ catalogProducts: updated });
  };

  const applyToAll = () => {
    const updated = state.catalogProducts.map(p => ({
      ...p,
      name: currentItem.name,
      price: currentItem.price,
      quantity: currentItem.quantity
    }));
    updateState({ catalogProducts: updated });
  };

  // Validation function: Ensures name, price, and quantity are filled out across EVERY product
  const isFormFullyFilled = () => {
    return state.catalogProducts.every(product => 
      product.name && 
      product.name.trim() !== '' && 
      product.quantity !== undefined && 
      product.quantity !== '' && 
      product.price !== undefined && 
      product.price !== ''
    );
  };

  // Shared network process logic
  const runBatchSubmission = async (): Promise<boolean> => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const payload = state.catalogProducts.map(product => ({
        productId: String(product.backendProductId || product.id),
        productName: String(product.name || ''),
        quantity: Math.max(0, parseInt(String(product.quantity || 0), 10)),
        price: Math.max(0, parseInt(String(product.price || 0), 10))
      }));

      await updateProductBatchDetails(payload);
      return true;
    } catch (err: any) {
      console.error("Failed batch updating products:", err);
      setSubmitError(typeof err === 'string' ? err : 'Failed to update catalog variants. Please verify inputs.');
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveAndContinue = async () => {
    const success = await runBatchSubmission();
    if (success) onNext();
  };

  const handleDirectPrintJump = async () => {
    const success = await runBatchSubmission();
    if (success) {
      // Small delayed micro-task to guarantee layout rendering updates before browser print call
      goToStep6();
      setTimeout(() => {
        window.print();
      }, 250);
    }
  };

  const formValid = isFormFullyFilled();

  return (
    <div className="space-y-6">
      {/* Error message block */}
      {submitError && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-semibold">
          ⚠️ {submitError}
        </div>
      )}

      {/* Dynamic Item Switcher: Hidden if only one product exists */}
      {!isSingleProduct && (
        <div className="flex items-center justify-between bg-bg-main p-2 rounded-xl border border-border-main">
          <button 
            disabled={activeIdx === 0} 
            onClick={() => setActiveIdx(p => p - 1)} 
            className="px-3 py-1 bg-bg-card rounded-md border border-border-main text-xs font-bold disabled:opacity-40 transition-opacity"
          >
            ← Prev Item
          </button>
          <span className="text-sm font-semibold text-brand-maroon-500">
            Editing Catalog Slot {activeIdx + 1} of {totalProducts}
          </span>
          <button 
            disabled={activeIdx === totalProducts - 1} 
            onClick={() => setActiveIdx(p => p + 1)} 
            className="px-3 py-1 bg-bg-card rounded-md border border-border-main text-xs font-bold disabled:opacity-40 transition-opacity"
          >
            Next Item →
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Cover Art Visual Column */}
        <div className="md:col-span-1 h-48 md:h-full bg-bg-main rounded-xl border border-border-main overflow-hidden relative">
          {currentItem?.files?.[0]?.type === 'image' ? (
            <img src={currentItem.files[0].url} className="w-full h-full object-cover" alt="Cover product" />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-text-muted text-xs p-4 text-center">
              <span>No cover art image configured for item.</span>
              <span className="text-[10px] mt-1 opacity-60">Upload assets in Step 2 to populate cover placeholder.</span>
            </div>
          )}
        </div>

        {/* Input Fields Panel */}
        <div className="md:col-span-2 space-y-4">
          <Input
            label="Product Descriptor Title"
            type="text"
            value={currentItem?.name || ''}
            onChange={(e) => updateCurrentItem({ name: e.target.value })}
            placeholder="Enter custom name variant..."
            disabled={isSubmitting}
          />

          <div className="grid grid-cols-2 gap-4">
            <NumberInput
              label="Stock Quantity"
              value={currentItem?.quantity || ''}
              onChange={(val) => updateCurrentItem({ quantity: val })}
              placeholder="e.g. 50"
              disabled={isSubmitting}
            />

            <NumberInput
              label="Price Point"
              value={currentItem?.price || ''}
              onChange={(value) => updateCurrentItem({ price: value })}
              placeholder="e.g. 1250"
              disabled={isSubmitting}
            />
          </div>

          {/* Bulk Action Button: Hidden if only one product exists */}
          {!isSingleProduct && (
            <button 
              onClick={applyToAll} 
              disabled={isSubmitting}
              className="w-full mt-2 text-xs border border-brand-gold-500 bg-brand-gold-500/5 text-brand-gold-500 p-2.5 rounded-xl font-bold hover:bg-brand-gold-500/10 transition-colors disabled:opacity-50"
            >
              ⚡ Apply these data points across all catalog slots
            </button>
          )}
        </div>
      </div>

      {/* Action Deck Buttons Area */}
      <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-border-main/60">
        {/* Save & Fast-Print Button */}
        <button
          onClick={handleDirectPrintJump}
          disabled={isSubmitting || !formValid}
          className="flex-1 border border-brand-gold-500 bg-brand-gold-500/10 text-brand-gold-600 p-2.5 rounded-xl font-semibold text-sm hover:bg-brand-gold-500/20 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {isSubmitting ? 'Processing...' : '💾 Save & Print QR Codes Now'}
        </button>

        {/* Standard Wizard Flow Step Button */}
        <button 
          onClick={handleSaveAndContinue} 
          disabled={isSubmitting || !formValid}
          className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {isSubmitting ? 'Saving Batch...' : 'Continue to Matrix Properties'}
        </button>
      </div>
    </div>
  );
};