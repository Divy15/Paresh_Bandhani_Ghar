import React, { useState } from 'react';
import type { SharedWizardState, CatalogProduct, MatrixRow } from './ProductDetails.types';
import { Step1Form } from './Step1Form';
import { Step2Form } from './Step2Form';
import { Step3Form } from './Step3Form';
import { Step4Form } from './Step4Form';
import { Step5Form } from './Step5Form';

interface ManagerProps {
  onComplete: (finalProducts: CatalogProduct[], generalData: { category: string; subCategory: string }) => void;
}

export const ProductDetailsManager: React.FC<ManagerProps> = ({ onComplete }) => {
  const [step, setStep] = useState<number>(1);
  const [globalState, setGlobalState] = useState<SharedWizardState>({
    category: '',
    category_name: '',
    subCategory: '',
    subcategory_name: '',
    catalogProducts: [createNewProductInstance()]
  });

  function createNewProductInstance(): CatalogProduct {
    const hasRandomUUID = typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function';
  
  return {
    id: hasRandomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 11),
    files: [],
      name: '',
      price: '',
      quantity: '1',
      matrixType: '',
      matrixRows: [],
      washingInstruction: '',
      description: ''
    };
  }

  const updateGlobalState = (updater: Partial<SharedWizardState>) => {
    setGlobalState(prev => ({ ...prev, ...updater }));
  };

  const handleNext = () => setStep(p => p + 1);
  const handleBack = () => setStep(p => p - 1);

  const handleFinalSubmit = () => {
    onComplete(globalState.catalogProducts, {
      category: globalState.category,
      subCategory: globalState.subCategory
    });
  };

  return (
    <div className="bg-bg-card border border-border-main rounded-2xl p-4 md:p-6 shadow-sm space-y-6">
      {/* Step Header Timeline Indicator Bar */}
      <div className="flex items-center justify-between border-b border-border-main pb-4">
        <span className="text-xs font-mono font-bold uppercase tracking-wider text-brand-maroon-500">
          Step {step} of 5
        </span>
        <div className="flex gap-1 h-1.5 w-32 bg-bg-main rounded-full overflow-hidden">
          {[1, 2, 3, 4, 5].map(s => (
            <div key={s} className={`flex-1 transition-all ${s <= step ? 'bg-brand-maroon-500' : 'bg-border-main/40'}`} />
          ))}
        </div>
      </div>

      {/* Dynamic wizard screen component router */}
      {step === 1 && <Step1Form state={globalState} updateState={updateGlobalState} onNext={handleNext} />}
      {step === 2 && <Step2Form state={globalState} updateState={updateGlobalState} onNext={handleNext} onBack={handleBack} createProduct={createNewProductInstance} />}
      {step === 3 && <Step3Form state={globalState} updateState={updateGlobalState} onNext={handleNext} onBack={handleBack} />}
      {step === 4 && <Step4Form state={globalState} updateState={updateGlobalState} onNext={handleNext} onBack={handleBack} />}
      {step === 5 && <Step5Form state={globalState} updateState={updateGlobalState} onComplete={handleFinalSubmit} onBack={handleBack} />}
    </div>
  );
};