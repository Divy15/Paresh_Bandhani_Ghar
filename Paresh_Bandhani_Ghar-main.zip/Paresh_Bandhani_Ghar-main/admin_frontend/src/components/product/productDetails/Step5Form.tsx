import React from 'react';
import type { SharedWizardState, CatalogProduct } from './ProductDetails.types';

interface Step5Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onComplete: () => void;
  onBack: () => void;
}

const WASHING_TEMPLATES = [
  'Dry clean only',
  'Hand wash or gentle machine wash'
];

export const Step5Form: React.FC<Step5Props> = ({ state, updateState, onComplete, onBack }) => {
  // Read baseline reference values safely from the first product in your catalog array
  const baseProduct = state.catalogProducts[0] as CatalogProduct | undefined;
  const descriptionValue = baseProduct?.description || '';
  const currentWashInstruction = baseProduct?.washingInstruction || '';

  // Helper function to update specific fields across all products in the batch catalog
  const updateGlobalProductFields = (fields: Partial<CatalogProduct>) => {
    const updatedProducts = state.catalogProducts.map(product => ({
      ...product,
      ...fields
    }));
    updateState({ catalogProducts: updatedProducts });
  };

  const handleWashChange = (value: string) => {
    updateGlobalProductFields({ washingInstruction: value });
  };

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    updateGlobalProductFields({ description: e.target.value });
  };

  const insertBulletPoint = () => {
    const textarea = document.getElementById('catalog-description') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    
    const bulletStr = text.length === 0 ? '• ' : '\n• ';
    const updatedText = text.substring(0, start) + bulletStr + text.substring(end);

    updateGlobalProductFields({ description: updatedText });

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + bulletStr.length, start + bulletStr.length);
    }, 0);
  };

  return (
    <div className="space-y-6 max-w-xl mx-auto py-2">
      <h3 className="text-lg font-semibold text-text-main font-serif">Finalize Operational Instructions</h3>
      
      {/* 1. CLOTH WASH INSTRUCTIONS */}
      <div>
        <label className="block text-xs font-bold text-text-muted uppercase tracking-wider mb-1.5">
          Washing Maintenance Parameters
        </label>
        <div className="space-y-2">
          {WASHING_TEMPLATES.map((tpl, i) => (
            <label 
              key={i} 
              className={`flex items-start gap-3 p-3 border rounded-xl cursor-pointer transition-colors text-xs text-text-main font-medium ${
                currentWashInstruction === tpl 
                  ? 'border-brand-maroon-500 bg-brand-maroon-500/5' 
                  : 'border-border-main bg-bg-main/40 hover:border-brand-maroon-500'
              }`}
            >
              <input 
                type="radio" 
                name="washOpt" 
                checked={currentWashInstruction === tpl}
                onChange={() => handleWashChange(tpl)}
                className="mt-0.5 accent-brand-maroon-500" 
              />
              <span>{tpl}</span>
            </label>
          ))}
        </div>
      </div>

      {/* 2. TEXTAREA WITH BULLET POINT BUILDER */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="block text-xs font-bold text-text-muted uppercase tracking-wider">
            Catalog Public Description Overview
          </label>
          <button
            type="button"
            onClick={insertBulletPoint}
            className="text-[11px] px-2 py-0.5 border border-brand-maroon-500/30 text-brand-maroon-500 rounded bg-brand-maroon-500/5 hover:bg-brand-maroon-500 hover:text-white font-semibold transition-all"
          >
            + Add Point Line
          </button>
        </div>
        
        <textarea 
          id="catalog-description"
          rows={6} 
          value={descriptionValue}
          onChange={handleDescriptionChange}
          className="w-full p-3 rounded-xl border border-border-main bg-bg-main text-text-main text-xs focus:outline-none focus:border-brand-maroon-500 leading-relaxed font-sans" 
          placeholder="Example: &#10;• Premium pure silk fabrication&#10;• Detailed traditional embroidery work on borders" 
        />
        <p className="text-[10px] text-text-muted mt-1">
          💡 Click the <span className="font-semibold text-brand-maroon-500">+ Add Point Line</span> button above or type "•" directly to list product details cleanly.
        </p>
      </div>

      <div className="p-4 rounded-xl bg-brand-maroon-500/5 border border-brand-maroon-500/10 text-xs text-brand-maroon-600 font-medium">
        ℹ️ Finalizing will execute multi-batch compilation indexing for all <strong>{state.catalogProducts.length} items</strong> embedded inside your dynamic staging structure.
      </div>

      <div className="flex gap-3 pt-2">
        <button onClick={onBack} className="flex-1 border border-border-main p-2.5 rounded-xl font-semibold text-sm text-text-muted hover:bg-bg-main">Back</button>
        <button onClick={onComplete} className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600">Compile & Register Catalog</button>
      </div>
    </div>
  );
};