import React, { useState } from 'react';
import type { SharedWizardState, CatalogProduct } from './ProductDetails.types';
import { updateProductDescriptionsBulk } from '../../../service/Product.service';

interface Step5Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onComplete: () => void;
}

export const Step5Form: React.FC<Step5Props> = ({ state, updateState, onComplete }) => {
  // Wizard Sub-Navigation Pointer State
  const [activeIdx, setActiveIdx] = useState<number>(0);

  // Dynamic Reference State Declarations
  const [isSaving, setIsSaving] = useState<boolean>(false);
  // 2. ADD AN ERROR STATE TO CATCH AND DISPLAY BACKEND API ERRORS
  const [errorMsg, setErrorMsg] = useState<string | null>(null); 

  // Read baseline reference values dynamically from the current selected item index
  const currentItem = state.catalogProducts[activeIdx] as CatalogProduct | undefined;
  const descriptionValue = currentItem?.description || '';

  // Helper function to update parameters exclusively on the working product index item
  const updateActiveProductFields = (fields: Partial<CatalogProduct>) => {
    const updated = [...state.catalogProducts];
    updated[activeIdx] = { ...currentItem, ...fields } as CatalogProduct;
    updateState({ catalogProducts: updated });
  };

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    updateActiveProductFields({ description: e.target.value });
  };

  // Replicates identical text configurations outward onto all items in the setup batch array
  const applyInstructionsToAll = () => {
    if (!currentItem) return;
    const updated = state.catalogProducts.map(product => ({
      ...product,
      description: currentItem.description || ''
    }));
    updateState({ catalogProducts: updated });
  };

  const insertBulletPoint = () => {
    const textarea = document.getElementById('catalog-description') as HTMLTextAreaElement;
    if (!textarea || !currentItem) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;

    const bulletStr = text.length === 0 ? '• ' : '\n• ';
    const updatedText = text.substring(0, start) + bulletStr + text.substring(end);

    updateActiveProductFields({ description: updatedText });

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + bulletStr.length, start + bulletStr.length);
    }, 0);
  };

  // 3. INTEGRATE SERVICE EXECUTION INSIDE THE COMPILATION HANDLER
  const handleFinalCompilation = async () => {
    try {
      setErrorMsg(null);
      setIsSaving(true);

      // Transform the local state into the exact shape expected by your Joi validation array schema
      const structuredPayload = state.catalogProducts.map((productItem: any) => {
        return {
          productId: String(productItem.backendProductId || productItem.id),
          description: productItem.description || ''
        };
      });

      console.log("Structured Payload to API:", structuredPayload);
      
      // Execute the bulk endpoint network transmission 
      await updateProductDescriptionsBulk(structuredPayload);
      
      // Advance to Step 6 only upon a successful 200 HTTP response status sequence
      onComplete();
    } catch (err: any) {
      console.error("Batch processing error during registration pipeline:", err);
      // Capture standard text strings thrown directly out from your axios catch middleware block
      setErrorMsg(typeof err === 'string' ? err : 'An unexpected pipeline tracking failure occurred.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-xl mx-auto py-2">

      {/* Dynamic Product Index Navigation Bar */}
      <div className="flex items-center justify-between bg-bg-main p-2 rounded-xl border border-border-main">
        <button
          type="button"
          disabled={activeIdx === 0}
          onClick={() => setActiveIdx(p => p - 1)}
          className="px-3 py-1 bg-bg-card border border-border-main rounded-md text-xs font-bold disabled:opacity-40 transition-opacity"
        >
          ← Previous Item
        </button>
        <span className="text-xs font-bold text-brand-maroon-500 tracking-wide uppercase">
          Description Blueprint for Slot #{activeIdx + 1} of {state.catalogProducts.length}
        </span>
        <button
          type="button"
          disabled={activeIdx === state.catalogProducts.length - 1}
          onClick={() => setActiveIdx(p => p + 1)}
          className="px-3 py-1 bg-bg-card border border-border-main rounded-md text-xs font-bold disabled:opacity-40 transition-opacity"
        >
          Next Item →
        </button>
      </div>

      {/* Product Thumbnail Indicator Row */}
      <div className="flex gap-4 items-center bg-bg-main/20 p-3 border border-border-main/60 rounded-xl">
        <div className="w-12 h-12 rounded-lg border border-border-main overflow-hidden shrink-0 bg-bg-main shadow-sm">
          {currentItem?.files?.[0]?.type === 'image' && (
            <img src={currentItem.files[0].url} className="w-full h-full object-cover" alt="Selected variant thumbnail preview" />
          )}
        </div>
        <div className="truncate">
          <span className="block text-xs font-bold text-text-main truncate">{currentItem?.name || 'Unnamed Product Reference Variant'}</span>
          <span className="block text-[10px] text-text-muted tracking-wide mt-0.5">ID Hash: {currentItem?.backendProductId || 'Staged Temporary Memory ID'}</span>
        </div>
      </div>

      {/* 4. VISUAL BACKEND ERROR INTERCEPT BANNER RENDERER */}
      {errorMsg && (
        <div className="text-xs text-red-600 bg-red-50 p-3 rounded-xl border border-red-200 mb-2 animate-pulse">
          ⚠️ {errorMsg}
        </div>
      )}

      {/* TEXTAREA WITH BULLET POINT BUILDER */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-xs font-bold text-text-muted uppercase tracking-wider">
            Catalog Public Description Profile
          </label>
          <button
            type="button"
            onClick={insertBulletPoint}
            className="text-[11px] px-2 py-0.5 border border-brand-maroon-500/30 text-brand-maroon-500 rounded bg-brand-maroon-500/5 hover:bg-brand-maroon-500 hover:text-white font-semibold transition-all shadow-sm"
          >
            + Add Point Line
          </button>
        </div>

        <textarea
          id="catalog-description"
          rows={5}
          value={descriptionValue}
          onChange={handleDescriptionChange}
          className="w-full p-3 rounded-xl border border-border-main bg-bg-card text-text-main text-xs focus:outline-none focus:border-brand-maroon-500 leading-relaxed font-sans shadow-inner"
          placeholder="Example: &#10;• Premium pure silk fabrication&#10;• Detailed traditional embroidery work on borders"
        />
        <p className="text-[10px] text-text-muted mt-1">
          💡 Click the <span className="font-semibold text-brand-maroon-500">+ Add Point Line</span> button above or type "•" directly to split rows.
        </p>
      </div>

      {/* Global Replication Control Mechanism */}
      <button
        type="button"
        onClick={applyInstructionsToAll}
        className="w-full text-xs border border-brand-gold-500 bg-brand-gold-500/5 text-brand-gold-500 p-2.5 rounded-xl font-bold hover:bg-brand-gold-500/10 transition-colors shadow-sm"
      >
        ⚡ Replicate this current description template to all catalog variants
      </button>

      {/* Navigation and Batch Execution Footer Area */}
      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button
          type="button"
          onClick={handleFinalCompilation}
          disabled={isSaving}
          className="w-full bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors disabled:opacity-75 flex items-center justify-center space-x-2"
        >
          {isSaving ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
              <span>Registering Descriptions...</span>
            </>
          ) : (
            <span>Compile & Register Catalog</span>
          )}
        </button>
      </div>
    </div>
  );
};