import React from 'react';
import type { SharedWizardState, CatalogProduct } from './ProductDetails.types';
import { FileUpload } from "../../commonComponents/FileUpload";

interface Step2Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  onBack: () => void;
  createProduct: () => CatalogProduct;
}

export const Step2Form: React.FC<Step2Props> = ({ state, updateState, onNext, onBack, createProduct }) => {
  const addProductSlot = () => {
    updateState({ catalogProducts: [...state.catalogProducts, createProduct()] });
  };

  // Handles real file selection and generates mock preview links locally
  const handleFileChange = (index: number, fileList: FileList) => {
    const updated = [...state.catalogProducts];
    
    Array.from(fileList).forEach(file => {
      // Check if the file is a video or image based on its system type
      const isVideo = file.type.startsWith('video/');
      
      // Create a local temporary blob URL for instant UI previewing
      const localUrl = URL.createObjectURL(file);
      
      updated[index].files.push({
        url: localUrl,
        type: isVideo ? 'video' : 'image'
      });
    });

    updateState({ catalogProducts: updated });
  };

  const removeFile = (productIndex: number, fileIndex: number) => {
    const updated = [...state.catalogProducts];
    // Revoke the temporary object URL to prevent browser memory leaks
    URL.revokeObjectURL(updated[productIndex].files[fileIndex].url);
    updated[productIndex].files.splice(fileIndex, 1);
    updateState({ catalogProducts: updated });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-text-main font-serif">Upload Media Registry Assets</h3>
          <p className="text-xs text-text-muted">Upload high-resolution media matching your catalog items.</p>
        </div>
        <button 
          onClick={addProductSlot} 
          className="border border-brand-maroon-500/30 text-brand-maroon-500 bg-brand-maroon-500/5 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-brand-maroon-500/10 transition-colors"
        >
          + Add Item Slot to Catalog
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {state.catalogProducts.map((prod, idx) => (
          <div key={prod.id} className="border border-border-main bg-bg-card p-5 rounded-2xl space-y-4 shadow-sm">
            <div className="flex justify-between items-center border-b border-border-main/50 pb-2">
              <span className="text-xs font-mono font-bold text-brand-maroon-500 bg-brand-maroon-500/5 px-2 py-0.5 rounded">
                Item #{idx + 1}
              </span>
              <span className="text-[10px] text-text-muted font-mono">{prod.id}</span>
            </div>

            {/* Common Shared File Upload Component Dropzone */}
            <FileUpload 
              label="Select Media Assets"
              onChange={(files) => handleFileChange(idx, files)}
              multiple={true}
              accept="image/*,video/*"
            />

            {/* Media Grid Preview Panel */}
            {prod.files.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-text-muted">Uploaded Files ({prod.files.length})</span>
                <div className="grid grid-cols-4 gap-2">
                  {prod.files.map((f, fIdx) => (
                    <div key={fIdx} className="aspect-square rounded-lg bg-bg-main border border-border-main overflow-hidden relative group">
                      {f.type === 'image' ? (
                        <img src={f.url} className="w-full h-full object-cover" alt="preview" />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-800 text-white text-[9px] font-bold p-1 text-center">
                          <span>🎥 VIDEO</span>
                        </div>
                      )}
                      
                      {/* Hover Remove Media Button Overlay */}
                      <button 
                        onClick={() => removeFile(idx, fIdx)}
                        className="absolute inset-0 bg-red-600/80 text-white text-[10px] font-bold flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button 
          onClick={onBack} 
          className="flex-1 border border-border-main p-2.5 rounded-xl font-semibold text-sm text-text-muted hover:bg-bg-main transition-colors"
        >
          Back
        </button>
        <button 
          onClick={onNext} 
          className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors"
        >
          Continue to Primary Details
        </button>
      </div>
    </div>
  );
};