import React, { useState } from 'react';
import type { SharedWizardState, CatalogProduct } from './ProductDetails.types';
import { FileUpload } from "../../commonComponents/FileUpload";
import { generateBatchPresignedUrls, storeProductMedia } from "../../../service/Product.service";
import axios from 'axios';

interface Step2Props {
  state: SharedWizardState;
  updateState: (updater: Partial<SharedWizardState>) => void;
  onNext: () => void;
  onBack: () => void;
  createProduct: () => CatalogProduct;
}

export const Step2Form: React.FC<Step2Props> = ({ state, updateState, onNext, onBack, createProduct }) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const addProductSlot = () => {
    updateState({ catalogProducts: [...state.catalogProducts, createProduct()] });
  };

  const removeProductSlot = (indexToRemove: number) => {
    const updated = state.catalogProducts.filter((_, idx) => idx !== indexToRemove);
    updateState({ catalogProducts: updated });
  };

  const handleFileChange = (index: number, fileList: FileList) => {
    const updated = [...state.catalogProducts];
    const currentFiles = updated[index].files;
    
    Array.from(fileList).forEach(file => {
      const isVideo = file.type.startsWith('video/');
      const localUrl = URL.createObjectURL(file);
      
      // If this is the absolute first image dropped in, mark it default cover
      const shouldBeCover = !isVideo && !currentFiles.some(f => f.isCover);
      
      currentFiles.push({
        url: localUrl,
        fileBlob: file, // Stash native blob for upload
        type: isVideo ? 'video' : 'image',
        isCover: shouldBeCover
      });
    });

    updateState({ catalogProducts: updated });
  };

  const removeFile = (productIndex: number, fileIndex: number) => {
    const updated = [...state.catalogProducts];
    const removedWasCover = updated[productIndex].files[fileIndex].isCover;
    
    URL.revokeObjectURL(updated[productIndex].files[fileIndex].url);
    updated[productIndex].files.splice(fileIndex, 1);
    
    // Fallback: If we deleted the active cover, assign a new image if possible
    if (removedWasCover && updated[productIndex].files.length > 0) {
      const nextImageIdx = updated[productIndex].files.findIndex(f => f.type === 'image');
      if (nextImageIdx !== -1) {
        updated[productIndex].files[nextImageIdx].isCover = true;
      }
    }

    updateState({ catalogProducts: updated });
  };

  // Toggle selection for cover image status flag
  const setCoverPhoto = (productIndex: number, fileIndex: number) => {
    const updated = [...state.catalogProducts];
    
    // Videos are not eligible to be cover images
    if (updated[productIndex].files[fileIndex].type === 'video') return;

    updated[productIndex].files = updated[productIndex].files.map((file, idx) => ({
      ...file,
      isCover: idx === fileIndex // Sets target to true, clears all other siblings
    }));

    updateState({ catalogProducts: updated });
  };

  // Process batch pre-signed coordination & direct AWS/S3 uploads
  // Process batch pre-signed coordination & direct AWS/S3 uploads, then store in DB
  const handleMediaUploadSync = async () => {
    setUploadError(null);

    // Guard Clause: Ensure each product block has at least 1 media item
    const missingMedia = state.catalogProducts.some(p => p.files.length === 0);
    if (missingMedia) {
      setUploadError("Please provide at least one media asset for each item slot.");
      return;
    }

    setIsUploading(true);
    try {
      // 1. Build validation request payload for backend
      const payload = {
        catalogId: state.catalogId,
        products: state.catalogProducts.map(prod => ({
          files: prod.files.map(f => ({
            clientFilename: f.fileBlob.name,
            contentType: f.fileBlob.type,
            contentLength: f.fileBlob.size
          }))
        }))
      };

      // 2. Fetch presigned coordination structures from server API
      const response = await generateBatchPresignedUrls(payload);
      
      // Deep copy globalState's catalog products to save permanent links
      const updatedProducts = [...state.catalogProducts];


      // response.products matches sequential array positioning
      for (let i = 0; i < response.products.length; i++) {
        const backendProduct = response.products[i];
        const clientProduct = updatedProducts[i];

        // Store the official backend generated unique productId link
        clientProduct.backendProductId = backendProduct.productId;

        // Loop files inside this product block and stream out directly to S3
        for (let j = 0; j < clientProduct.files.length; j++) {
          const clientFile = clientProduct.files[j];
          const presignedInfo = backendProduct.uploads[j];

          // Direct Axios binary PUT request directly bypassing standard app routers
          await axios.put(presignedInfo.uploadUrl, clientFile.fileBlob, {
            headers: { 'Content-Type': clientFile.fileBlob.type }
          });

          // Save the target delivery path / key inside the client side collection record
          // Note: If your backend validator expects 'path', match whatever property name holds your S3 Key string here.
          clientFile.permanentUrl = presignedInfo.permanentUrl; 
        }
      }

      // ==========================================
      // NEW CODE: 3. Assemble Confirmation Payload & Hit Database Service
      // ==========================================
      const mediaConfirmationPayload = {
        catalogId: state.catalogId,
        media: updatedProducts.flatMap(prod => 
          prod.files.map(file => ({
            productId: prod.backendProductId, // Received from step 2 response
            path: file.permanentUrl,          // The generated S3 Object Key path
            isCover: !!file.isCover
          }))
        )
      };

      // Fire your Joi-validated database storage route service
      await storeProductMedia(mediaConfirmationPayload);

      // 4. Update globalState state tracking layers
      updateState({ catalogProducts: updatedProducts });
      
      // Advance execution flow safely into Step 3
      onNext();
    } catch (err: any) {
      console.error(err);
      setUploadError(err?.response?.data?.message || err?.message || "Failed uploading asset pipelines or writing to database.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Active Catalog ID Display */}
      {state.catalogId && (
        <div className="bg-bg-main border border-border-main/60 rounded-xl px-4 py-3 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-text-muted font-sans font-medium">Active Catalog Registry:</span>
            <span className="font-bold text-text-main tracking-wider">{state.catalogId}</span>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h3 className="text-lg font-semibold text-text-main font-serif">Upload Media Registry Assets</h3>
          <p className="text-xs text-text-muted">Upload media files and set your primary item cover display thumbnails.</p>
        </div>
        <button 
          onClick={addProductSlot} 
          disabled={isUploading}
          className="disabled:opacity-50 border border-brand-maroon-500/30 text-brand-maroon-500 bg-brand-maroon-500/5 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-brand-maroon-500/10 transition-colors"
        >
          + Add Item Slot to Catalog
        </button>
      </div>

      {uploadError && (
        <div className="p-3 text-xs font-semibold rounded-xl bg-red-50 text-red-600 border border-red-200">
          ⚠️ {uploadError}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {state.catalogProducts.map((prod, idx) => (
          <div key={prod.id} className="border border-border-main bg-bg-card p-5 rounded-2xl space-y-4 shadow-sm relative">
            <div className="flex justify-between items-center border-b border-border-main/50 pb-2">
              <span className="text-xs font-mono font-bold text-brand-maroon-500 bg-brand-maroon-500/5 px-2 py-0.5 rounded">
                Item #{idx + 1}
              </span>
              {state.catalogProducts.length > 1 && (
                <button
                  type="button"
                  disabled={isUploading}
                  onClick={() => removeProductSlot(idx)}
                  className="text-xs text-red-500 hover:text-red-700 font-medium disabled:opacity-30"
                >
                  ✕ Remove Item
                </button>
              )}
            </div>

            <FileUpload 
              label="Select Media Assets"
              onChange={(files) => handleFileChange(idx, files)}
              multiple={true}
              accept="image/*,video/*"
            />

            {prod.files.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-text-muted">
                  Uploaded Files ({prod.files.length}) — Click image to set as Cover Photo
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {prod.files.map((f, fIdx) => (
                    <div 
                      key={fIdx} 
                      onClick={() => setCoverPhoto(idx, fIdx)}
                      className={`aspect-square rounded-lg bg-bg-main border overflow-hidden relative cursor-pointer transition-all group ${
                        f.isCover ? 'border-brand-maroon-500 ring-2 ring-brand-maroon-500/30 shadow-md' : 'border-border-main hover:border-text-muted'
                      }`}
                    >
                      {f.type === 'image' ? (
                        <img src={f.url} className="w-full h-full object-cover" alt="preview" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-zinc-800 text-white text-[9px] font-bold p-1 text-center">
                          <span>🎥 VIDEO</span>
                        </div>
                      )}

                      {/* Cover Photo Badge Overlay */}
                      {f.isCover && (
                        <div className="absolute bottom-0 left-0 right-0 bg-brand-maroon-500 text-white text-[8px] font-bold text-center py-0.5 uppercase tracking-wide">
                          ★ Cover
                        </div>
                      )}
                      
                      {/* Delete button wrapper inside layout spaces */}
                      <button 
                        type="button"
                        disabled={isUploading}
                        onClick={(e) => {
                          e.stopPropagation(); // Stop parent execution firing setCoverPhoto
                          removeFile(idx, fIdx);
                        }}
                        className="absolute top-1 right-1 w-4 h-4 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center text-[10px] z-10 disabled:opacity-30"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Controller Buttons Navigation Bar */}
      <div className="flex gap-3 pt-4 border-t border-border-main/60">
        <button 
          onClick={onBack} 
          disabled={isUploading}
          className="flex-1 border border-border-main p-2.5 rounded-xl font-semibold text-sm text-text-muted hover:bg-bg-main transition-colors disabled:opacity-50"
        >
          Back
        </button>
        <button 
          onClick={handleMediaUploadSync} 
          disabled={isUploading}
          className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-75"
        >
          {isUploading ? (
            <>
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Uploading Media to Cloud...
            </>
          ) : (
            "Continue to Primary Details"
          )}
        </button>
      </div>
    </div>
  );
};