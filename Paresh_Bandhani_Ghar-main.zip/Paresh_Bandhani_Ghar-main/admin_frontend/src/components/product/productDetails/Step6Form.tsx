import React, { useState, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import type { SharedWizardState } from './ProductDetails.types';

interface Step6Props {
  state: SharedWizardState;
  onComplete: () => void;
}

interface PrintQueueItem {
  id: string;
  name: string;
  backendProductId?: string;
  qrValue: string;
}

export const Step6Form: React.FC<Step6Props> = ({ state, onComplete }) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  // 1. Maintain a local state of how many stickers to print for each product.
  // We initialize it with the product's default stock quantity (default to 1 if empty/invalid)
  const [printQuantities, setPrintQuantities] = useState<Record<string, number>>(() => {
    const initialQuantities: Record<string, number> = {};
    state.catalogProducts.forEach((product) => {
      const qty = parseInt(String(product.quantity), 10);
      initialQuantities[product.id] = isNaN(qty) || qty <= 0 ? 1 : qty;
    });
    return initialQuantities;
  });

  // 2. Holds the temporary list of items about to be fed to the physical print spool
  const [printQueue, setPrintQueue] = useState<PrintQueueItem[]>([]);

  // Generates the raw payload string for the QR code scanner
  const getQrValue = (backendProductId?: string) => {
    return JSON.stringify({
      catalogId: state.catalogId,
      productId: backendProductId || "PENDING_ID"
    });
  };

  // Helper: Safely updates print quantities for a specific product block
  const handleQuantityChange = (productId: string, value: number) => {
    const safeValue = Math.max(1, value); // Enforce minimum of 1 print
    setPrintQuantities((prev) => ({
      ...prev,
      [productId]: safeValue,
    }));
  };

  // Triggers print action for a SINGLE selected product with its specific quantity
  const handlePrintProduct = (productId: string) => {
    const product = state.catalogProducts.find((p) => p.id === productId);
    if (!product) return;

    const count = printQuantities[productId] || 1;
    const qrVal = getQrValue(product.backendProductId);

    // Build duplicates equivalent to chosen count
    const queue: PrintQueueItem[] = Array.from({ length: count }).map((_, idx) => ({
      id: `${product.id}-print-${idx}`,
      name: product.name || 'Unnamed Product',
      backendProductId: product.backendProductId,
      qrValue: qrVal,
    }));

    setPrintQueue(queue);

    // Give React 100ms to render the updated hidden print nodes before opening the print spool
    setTimeout(() => {
      window.print();
    }, 100);
  };

  // Triggers print action for ALL products, multiplying each by its respective print quantity
  const handlePrintAllStickers = () => {
    const queue: PrintQueueItem[] = [];

    state.catalogProducts.forEach((product) => {
      const count = printQuantities[product.id] || 1;
      const qrVal = getQrValue(product.backendProductId);

      for (let i = 0; i < count; i++) {
        queue.push({
          id: `${product.id}-all-${i}`,
          name: product.name || 'Unnamed Product',
          backendProductId: product.backendProductId,
          qrValue: qrVal,
        });
      }
    });

    if (queue.length === 0) return;

    setPrintQueue(queue);

    setTimeout(() => {
      window.print();
    }, 100);
  };

  // Calculations for total sticker counter helper text
  const totalStickersCount = Object.values(printQuantities).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6">
      {/* Visual Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold text-text-main font-serif">Product QR Code Registry</h3>
          <p className="text-xs text-text-muted">
            Configure individual quantities and print QR codes formatted directly for standard thermal label roles.
          </p>
        </div>
        <div className="bg-brand-maroon-500/5 border border-brand-maroon-500/10 rounded-xl px-3 py-2 text-right">
          <div className="text-[10px] uppercase font-mono tracking-wider text-brand-maroon-500 font-bold">Total Roll Copies</div>
          <div className="text-xl font-bold text-brand-maroon-500">{totalStickersCount} Labels</div>
        </div>
      </div>

      {/* Screen Interface Display Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {state.catalogProducts.map((product, idx) => {
          const currentQty = printQuantities[product.id] || 1;
          return (
            <div 
              key={product.id} 
              className="border border-border-main bg-bg-main rounded-xl p-4 flex flex-col justify-between space-y-4 shadow-sm"
            >
              {/* Product Info */}
              <div className="flex flex-col items-center text-center space-y-3">
                <span className="text-[10px] font-mono font-bold text-brand-maroon-500 bg-brand-maroon-500/5 px-2 py-0.5 rounded">
                  Item #{idx + 1}: {product.name || "Unnamed Product"}
                </span>
                
                <div className="bg-white p-3 rounded-xl shadow-inner border border-zinc-100">
                  <QRCodeSVG 
                    value={getQrValue(product.backendProductId)} 
                    size={100} 
                    level="M" 
                    marginSize={1}
                  />
                </div>

                <div className="text-[10px] font-mono text-text-muted break-all max-w-full px-2">
                  <p>Prod ID: <span className="text-text-main font-semibold">{product.backendProductId || 'N/A'}</span></p>
                </div>
              </div>

              {/* Printing controls */}
              <div className="space-y-2 pt-2 border-t border-border-main/40">
                <div className="flex items-center justify-between gap-2">
                  <label className="text-[10px] font-bold text-text-muted uppercase">Labels to print:</label>
                  <div className="flex items-center border border-border-main rounded-lg overflow-hidden bg-bg-card">
                    <button
                      type="button"
                      onClick={() => handleQuantityChange(product.id, currentQty - 1)}
                      className="px-2 py-1 text-xs hover:bg-bg-main active:bg-border-main/20 font-bold border-r border-border-main"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      min="1"
                      value={currentQty}
                      onChange={(e) => handleQuantityChange(product.id, parseInt(e.target.value, 10) || 1)}
                      className="w-10 text-center bg-transparent text-xs font-mono font-bold focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => handleQuantityChange(product.id, currentQty + 1)}
                      className="px-2 py-1 text-xs hover:bg-bg-main active:bg-border-main/20 font-bold border-l border-border-main"
                    >
                      +
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handlePrintProduct(product.id)}
                  className="w-full bg-bg-card hover:bg-border-main/20 border border-border-main text-[11px] font-bold text-text-main py-1.5 rounded-lg transition-colors"
                >
                  🖨️ Print ({currentQty}) Labels
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Enhanced CSS Injection with Thermal Sticker dimension constraints (e.g. 2in x 1in label) */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          /* Enforce targeted small label dimensions */
          @page {
            size: 2in 1in;
            margin: 0 !important;
          }

          /* General browser page reset rules */
          html, body {
            width: 2in;
            height: 1in;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff;
          }

          /* Hide everything on screen */
          body * {
            visibility: hidden;
          }

          /* Only make the hidden printing registry block visible */
          #qr-sticker-print-registry, #qr-sticker-print-registry * {
            visibility: visible;
          }

          #qr-sticker-print-registry {
            position: absolute;
            left: 0;
            top: 0;
            width: 2in;
            height: 1in;
          }

          /* Style each sticker block to completely fill the 2"x1" target page limits */
          .sticker-page-break {
            width: 2in;
            height: 1in;
            display: flex !important;
            align-items: center;
            justify-content: center;
            page-break-after: always;
            break-after: page;
            box-sizing: border-box;
            padding: 2px;
          }
        }
      `}} />

      {/* Hidden print registry. Contains exact physical sticker output nodes */}
      <div id="qr-sticker-print-registry" className="hidden print:block" ref={printAreaRef}>
        {printQueue.map((item) => (
          <div key={item.id} className="sticker-page-break">
            {/* Optimized layout structure to fit perfectly inside the 2in x 1in boundary size */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%' }}>
              <QRCodeSVG 
                value={item.qrValue} 
                size={68} // Compact footprint to prevent clip errors on tiny label systems
                level="M"
                marginSize={0}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Actions Navigation Deck */}
      <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-border-main/60">
        <button
          type="button"
          onClick={handlePrintAllStickers}
          className="flex-1 border border-brand-maroon-500/30 text-brand-maroon-500 bg-brand-maroon-500/5 p-2.5 rounded-xl font-semibold text-sm hover:bg-brand-maroon-500/10 transition-colors flex items-center justify-center gap-2"
        >
          🖨️ Print All ({totalStickersCount}) Stickers
        </button>
        <button
          type="button"
          onClick={onComplete}
          className="flex-1 bg-brand-maroon-500 text-white p-2.5 rounded-xl font-semibold text-sm shadow hover:bg-brand-maroon-600 transition-colors flex items-center justify-center"
        >
          Save & Exit Wizard
        </button>
      </div>
    </div>
  );
};