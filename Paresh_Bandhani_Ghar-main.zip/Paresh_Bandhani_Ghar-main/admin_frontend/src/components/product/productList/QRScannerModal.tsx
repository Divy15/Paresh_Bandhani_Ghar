import React, { useEffect } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (catalogId: string, productId: string) => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({ isOpen, onClose, onScanSuccess }) => {
  useEffect(() => {
    if (!isOpen) return;

    // Initialize camera grid region
    const scanner = new Html5QrcodeScanner(
      "qr-reader-target",
      { fps: 10, qrbox: { width: 250, height: 250 } },
      /* verbose= */ false
    );

    scanner.render(
      (decodedText) => {
        try {
          // Expecting JSON string layout: {"catalogId": "...", "productId": "..."}
          const parsed = JSON.parse(decodedText);
          if (parsed.catalogId || parsed.productId) {
            onScanSuccess(parsed.catalogId || '', parsed.productId || '');
            scanner.clear();
            onClose();
          }
        } catch (e) {
          console.error("Invalid QR structure format detected:", e);
        }
      },
      (error) => {
        // Silent capture of frame reading misses
        console.log(error);
      }
    );

    return () => {
      scanner.clear().catch(err => console.error("Failed to clean camera stream:", err));
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-zinc-900 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-100">Scan Product QR Code</h3>
          <button onClick={onClose} className="px-3 py-1 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-sm">Close</button>
        </div>
        <div id="qr-reader-target" className="overflow-hidden rounded-xl border border-zinc-200 dark:border-zinc-800"></div>
        <p className="text-xs text-center text-zinc-500">Center the QR code inside the frame to scan automatically.</p>
      </div>
    </div>
  );
};