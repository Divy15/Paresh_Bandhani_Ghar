import React, { useEffect, useRef } from 'react';
import { type ViewProps } from './ProductList.types';

export const ProductListDesktopView: React.FC<ViewProps> = ({ products, hasMore, loadMore, isLoadingMore }) => {
  const sentinelRef = useRef<HTMLTableRowElement | null>(null);

  useEffect(() => {
    const observerTarget = sentinelRef.current;
    if (!observerTarget || !hasMore) return;

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !isLoadingMore) {
        loadMore();
      }
    }, { threshold: 0.1 });

    observer.observe(observerTarget);
    return () => observer.disconnect();
  }, [hasMore, loadMore, isLoadingMore]);

  return (
    <div className="border border-[var(--border-main)] rounded-2xl overflow-hidden bg-[var(--bg-card)] shadow-sm">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-zinc-50 dark:bg-zinc-900 border-b border-[var(--border-main)] text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">
            <th className="p-4 w-24">Media</th>
            <th className="p-4">Identity String</th>
            <th className="p-4">Product Name & Category</th>
            <th className="p-4">Pipeline Status</th>
            <th className="p-4">Stock Ledger</th>
            <th className="p-4 text-right">Unit Price</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[var(--border-main)] text-sm text-[var(--text-main)]">
          {products.map((p) => (
            <tr 
              key={p.id} 
              className="hover:bg-[var(--color-brand-maroon-50)]/20 dark:hover:bg-zinc-900/30 transition-colors group"
            >
              {/* Media Thumbnail */}
              <td className="p-4">
                <div className="relative w-12 h-16 overflow-hidden rounded-xl border border-[var(--border-main)] bg-zinc-100 dark:bg-zinc-800">
                  <img 
                    src={p.imageUrl || `https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=150&q=80`} 
                    alt={p.name} 
                    className="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
              </td>

              {/* ID Code with Brand Gold */}
              <td className="p-4 font-mono text-xs font-bold text-[var(--text-muted)] group-hover:text-[var(--color-brand-gold-500)] transition-colors">
                {p.id}
              </td>

              {/* Identity & Category Tag */}
              <td className="p-4">
                <div className="font-semibold text-[var(--text-main)] group-hover:text-[var(--color-brand-maroon-500)] transition-colors">
                  {p.name}
                </div>
                <div className="text-[10px] font-bold tracking-widest text-[var(--text-muted)] uppercase mt-0.5">
                  {p.categoryName || "Traditional Wear"}
                </div>
              </td>

              {/* Pipeline Status Badges */}
              <td className="p-4">
                <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider shadow-sm inline-block ${
                  p.productStatus === 'Online' 
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' 
                    : p.productStatus === 'Offline' 
                    ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20' 
                    : 'bg-zinc-500/10 text-zinc-600 dark:text-zinc-400 border border-zinc-500/20'
                }`}>
                  {p.productStatus}
                </span>
              </td>

              {/* Stock Level Tracker */}
              <td className="p-4 text-[var(--text-muted)] font-medium">
                {p.stock > 0 ? (
                  <span>{p.stock} units</span>
                ) : (
                  <span className="text-rose-500 font-semibold uppercase text-xs">Out of Stock</span>
                )}
              </td>

              {/* Price Point */}
              <td className="p-4 text-right font-bold text-[var(--text-main)] text-base">
                {p.price}
              </td>
            </tr>
          ))}

          {/* Infinite Scroll Trigger Row Anchor */}
          {hasMore && (
            <tr ref={sentinelRef}>
              <td colSpan={6} className="p-6 text-center text-[var(--text-muted)] text-xs font-semibold tracking-wider uppercase bg-zinc-50/50 dark:bg-zinc-900/10">
                {isLoadingMore ? (
                  <span className="animate-pulse text-[var(--color-brand-gold-500)]">Querying database for next batch...</span>
                ) : (
                  "Scroll down to fetch more products"
                )}
              </td>
            </tr>
          )}

          {/* Fallback Empty State */}
          {products.length === 0 && !isLoadingMore && (
            <tr>
              <td colSpan={6} className="p-16 text-center text-[var(--text-muted)] text-sm font-medium">
                No matched product profiles found inside memory cache grids.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};