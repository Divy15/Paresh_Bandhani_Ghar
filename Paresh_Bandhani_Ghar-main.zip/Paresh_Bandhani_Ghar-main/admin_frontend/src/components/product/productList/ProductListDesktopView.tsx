import React from 'react';
import { type ViewProps } from './ProductList.types';

export const ProductListDesktopView: React.FC<ViewProps> = ({ products }) => {
  return (
    <div className="border border-border-main rounded-xl overflow-hidden bg-bg-card">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-bg-main border-b border-border-main text-xs font-bold uppercase tracking-wider text-text-muted">
            <th className="p-3 w-24">Image</th>
            <th className="p-3">Product ID</th>
            <th className="p-3">Item Detail Descriptor</th>
            <th className="p-3">In-Stock</th>
            <th className="p-3 text-right">Price Point</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border-main text-sm text-text-main">
          {products.length > 0 ? (
            products.map((p) => (
              <tr key={p.id} className="hover:bg-bg-main/40 transition-colors">
                <td className="p-3">
                  <img 
                    src={p.imageUrl || `https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=80&q=80`} 
                    alt={p.name} 
                    className="w-12 h-12 object-cover rounded-md border border-border-main"
                  />
                </td>
                <td className="p-3 font-mono text-brand-maroon-500 font-bold">{p.id}</td>
                <td className="p-3 font-medium">{p.name}</td>
                <td className="p-3 text-text-muted">{p.stock} units</td>
                <td className="p-3 text-right font-semibold">{p.price}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={5} className="p-6 text-center text-text-muted opacity-60">
                No matched profiles found inside memory grid.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};