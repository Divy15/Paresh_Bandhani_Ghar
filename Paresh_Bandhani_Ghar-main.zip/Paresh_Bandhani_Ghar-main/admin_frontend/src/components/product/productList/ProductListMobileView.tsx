import React, { useEffect, useRef } from 'react';
import { type ViewProps, type Product } from './ProductList.types';
import { ProductCard } from '../../commonComponents/ProductCard';

export const ProductListMobileView: React.FC<ViewProps> = ({ products, hasMore, loadMore, isLoadingMore }) => {
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const observerTarget = sentinelRef.current;
    if (!observerTarget || !hasMore) return;

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !isLoadingMore) {
        loadMore();
      }
    }, { threshold: 0.1 });

    observer.observe(observerTarget);
    return () => observer.disconnect();
  }, [hasMore, loadMore, isLoadingMore]);

  // Curated Fallback Empty State
  if (products.length === 0 && !isLoadingMore) {
    return (
      <div className="p-12 text-center text-[var(--text-muted)] border border-dashed border-[var(--border-main)] rounded-2xl text-sm bg-[var(--bg-card)]">
        No matched product profiles found inside memory cache grids.
      </div>
    );
  }

  const handleViewProduct = (product: Product) => {
      alert(`Viewing Details for: ${product.name}`);
    };

  return (
    <div className="space-y-6">
      {/* Grid adapts beautifully from mobile viewports up to larger screens */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product}  onViewClick={handleViewProduct} />
        ))}
      </div>

      {/* Infinite Scroll Trigger Block Box Anchor */}
      {hasMore && (
        <div 
          ref={sentinelRef} 
          className="p-6 text-center text-xs text-[var(--text-muted)] font-semibold tracking-wider uppercase bg-[var(--bg-card)]/50 border border-[var(--border-main)] rounded-2xl"
        >
          {isLoadingMore ? (
            <span className="animate-pulse text-[var(--color-brand-gold-500)]">Syncing next page stream...</span>
          ) : (
            "Loading more items..."
          )}
        </div>
      )}
    </div>
  );
};