import React from 'react';
import { type ViewProps } from './ProductList.types';
import { ProductCard } from '../../commonComponents/ProductCard';

export const ProductListMobileView: React.FC<ViewProps> = ({ products }) => {
  if (products.length === 0) {
    return (
      <div className="p-8 text-center text-text-muted opacity-60 border border-dashed border-border-main rounded-xl bg-bg-card text-sm">
        No matched profiles found inside memory grid.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};