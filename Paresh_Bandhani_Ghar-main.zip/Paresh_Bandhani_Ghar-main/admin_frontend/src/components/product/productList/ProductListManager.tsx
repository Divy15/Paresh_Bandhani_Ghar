import React, { useState, useEffect, useCallback } from 'react';
import { Input } from '../../commonComponents/Input';
import { type Product, type Category } from './ProductList.types';
import { ProductCard } from '../../commonComponents/ProductCard';
import { QRScannerModal } from './QRScannerModal';
import { getProductsAndRefreshMedia } from '../../../service/Product.service';
import { getCategories } from "../../../service/Configuration.service";

export const ProductListManager: React.FC = () => {
  // Query Filters & State Hooks
  const [searchName, setSearchName] = useState('');
  const [debouncedSearchName, setDebouncedSearchName] = useState('');
  const [selectedCatalogId, setSelectedCatalogId] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  
  // Category Autocomplete Dropdown State
  const [categorySearch, setCategorySearch] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeCategory, setActiveCategory] = useState<Category | null>(null);
  const [showCatDropdown, setShowCatDropdown] = useState(false);

  // Pagination & Flow Control
  const [products, setProducts] = useState<Product[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  // Name query filter input debounce
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedSearchName(searchName), 400);
    return () => clearTimeout(handler);
  }, [searchName]);

  // Handle Fetching of Categories on Demand
  useEffect(() => {
    if (!categorySearch) {
      setCategories([]);
      return;
    }
    const fetchCats = setTimeout(async () => {
      try {
        const res = await getCategories(categorySearch);
        if (res?.success) setCategories(res.data || []);
      } catch (err) {
        console.error(err);
      }
    }, 300);
    return () => clearTimeout(fetchCats);
  }, [categorySearch]);

  // Primary Data Fetch Pipeline
  const fetchProductGrid = useCallback(async (pageNum: number, clearPrevious = false) => {
    if (isLoading) return;
    setIsLoading(true);

    try {
      const payload = {
        catalogId: selectedCatalogId || null,
        productId: selectedProductId || null,
        productName: debouncedSearchName || null,
        pageNumber: pageNum
      };

      const result = await getProductsAndRefreshMedia(payload);
      
      if (result?.success && Array.isArray(result.data)) {
        const mapped: Product[] = result.data.map((p: any) => {
          const coverMedia = p.product_media?.find((m: any) => m.is_cover) || p.product_media?.[0];
          return {
            id: p.product_id,
            name: p.product_name,
            catalogId: p.catalog_id,
            categoryId: p.category_id,
            categoryName: p.category_name,
            stock: p.quantity,
            price: `₹${Number(p.price).toLocaleString('en-IN')}`,
            productStatus: p.product_status,
            imageUrl: coverMedia ? coverMedia.presigned_url : undefined,
            productMedia: p.product_media
          };
        });

        const filteredDataset = activeCategory 
          ? mapped.filter(item => item.categoryId === activeCategory.id)
          : mapped;

        setProducts(prev => clearPrevious ? filteredDataset : [...prev, ...filteredDataset]);
        setHasMore(mapped.length === 20); // Continue if the returned count matches the default page size
      } else {
        setHasMore(false);
      }
    } catch (err) {
      console.error("Data listing fetch pipeline error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [debouncedSearchName, selectedCatalogId, selectedProductId, activeCategory]);

  // Trigger Reset on main search query events
  useEffect(() => {
    setPage(1);
    fetchProductGrid(1, true);
  }, [debouncedSearchName, selectedCatalogId, selectedProductId, activeCategory]);

  // 80% Infinite Scroll Event Listener (LinkedIn/Instagram style)
  useEffect(() => {
    const handleScroll = () => {
      if (isLoading || !hasMore) return;

      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const windowHeight = window.innerHeight;
      const totalHeight = document.documentElement.scrollHeight;

      // Trigger standard API pagination call when user scrolls past 80% of total document height
      if ((scrollTop + windowHeight) >= (totalHeight * 0.8)) {
        const nextPage = page + 1;
        setPage(nextPage);
        fetchProductGrid(nextPage, false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoading, hasMore, page, fetchProductGrid]);

  const handleQRSuccess = (catId: string, prodId: string) => {
    setSelectedCatalogId(catId);
    setSelectedProductId(prodId);
    setSearchName('');
  };

  const clearAllFilters = () => {
    setSearchName('');
    setSelectedCatalogId('');
    setSelectedProductId('');
    setActiveCategory(null);
    setCategorySearch('');
  };

  const handleViewProduct = (product: Product) => {
    alert(`Viewing Details for: ${product.name}`);
  };

  return (
    <div className="space-y-8 px-4 py-6 max-w-7xl mx-auto text-[var(--text-main)] min-h-screen bg-[var(--bg-main)]">
      
      {/* Search Filter Strip - Styled using your specific CSS Variables */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-[var(--bg-card)] p-5 rounded-2xl border border-[var(--border-main)] shadow-sm">
        
        {/* Name input */}
        <Input 
          label="Search Database Products" 
          placeholder="Type product name keyword..." 
          value={searchName}
          onChange={(e) => setSearchName(e.target.value)}
        />

        {/* Dynamic Category Selector */}
        <div className="relative flex flex-col justify-end">
          <label className="text-xs font-semibold text-[var(--text-muted)] mb-1">
            Product Category Filter
          </label>
          <input
            type="text"
            className="w-full px-3 py-2 border rounded-xl bg-[var(--bg-main)] border-[var(--border-main)] text-[var(--text-main)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-brand-maroon-500)]"
            placeholder={activeCategory ? `Category: ${activeCategory.category_name}` : "Search categories..."}
            value={categorySearch}
            onChange={(e) => {
              setCategorySearch(e.target.value);
              setShowCatDropdown(true);
            }}
            onFocus={() => setShowCatDropdown(true)}
          />
          {showCatDropdown && categories.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-[var(--bg-card)] border border-[var(--border-main)] shadow-xl rounded-xl max-h-48 overflow-y-auto z-50 divide-y divide-[var(--border-main)]">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  className="w-full text-left px-4 py-2.5 text-sm text-[var(--text-main)] hover:bg-[var(--color-brand-maroon-50)] dark:hover:bg-zinc-800 transition"
                  onClick={() => {
                    setActiveCategory(cat);
                    setCategorySearch('');
                    setShowCatDropdown(false);
                  }}
                >
                  {cat.category_name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls Frame */}
        <div className="flex items-end gap-2">
          <button
            onClick={() => setIsScannerOpen(true)}
            className="flex-1 bg-[var(--color-brand-maroon-500)] hover:bg-[var(--color-brand-maroon-600)] text-white font-semibold py-2 px-4 text-sm rounded-xl transition flex items-center justify-center gap-2 h-[38px] shadow-sm"
          >
            📷 Scan QR
          </button>
          
          {(selectedCatalogId || selectedProductId || activeCategory || searchName) && (
            <button
              onClick={clearAllFilters}
              className="px-4 bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-muted)] hover:text-[var(--text-main)] text-sm font-semibold rounded-xl h-[38px] transition"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Active Filter Badges */}
      {(selectedCatalogId || selectedProductId || activeCategory) && (
        <div className="bg-[var(--bg-card)] border border-[var(--border-main)] px-4 py-2.5 rounded-xl text-xs font-mono inline-flex flex-wrap gap-4 text-[var(--text-muted)] shadow-sm">
          {selectedCatalogId && <span><strong>Catalog:</strong> {selectedCatalogId}</span>}
          {selectedProductId && <span><strong>Product ID:</strong> {selectedProductId}</span>}
          {activeCategory && <span><strong>Category:</strong> {activeCategory.category_name}</span>}
        </div>
      )}

      {/* Main Viewport Container Grid - Responsive Myntra Card Grid (No Desktop Tables) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product} 
            onViewClick={handleViewProduct} 
          />
        ))}
      </div>

      {/* Empty State Feed Message */}
      {products.length === 0 && !isLoading && (
        <div className="p-16 text-center text-sm text-[var(--text-muted)] bg-[var(--bg-card)] border border-dashed border-[var(--border-main)] rounded-2xl shadow-inner">
          No matches found. Try modifying your search filter keys.
        </div>
      )}

      {/* Loading Status Indicator */}
      {isLoading && (
        <div className="py-10 text-center text-xs text-[var(--color-brand-gold-500)] font-semibold uppercase tracking-widest animate-pulse">
          Fetching curated products...
        </div>
      )}

      {/* QR Camera Portal */}
      <QRScannerModal 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        onScanSuccess={handleQRSuccess} 
      />
    </div>
  );
};