import React, { useState } from 'react';
import { Input } from '../../commonComponents/Input';
import { type Product } from './ProductList.types';
import { ProductListDesktopView } from './ProductListDesktopView';
import { ProductListMobileView } from './ProductListMobileView';

export const ProductListManager: React.FC = () => {
  const [search, setSearch] = useState('');
  
  // Refactored Mock Data to include Unsplash images for rich layout display
  const mockProducts: Product[] = [
    { 
      id: 'PROD-90812', 
      name: 'Silk Bandhani Dupatta', 
      stock: 12, 
      price: '₹1,250',
      imageUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=300&q=80'
    },
    { 
      id: 'PROD-32451', 
      name: 'Gaji Silk Saree Crimson', 
      stock: 4, 
      price: '₹8,900',
      imageUrl: 'https://images.unsplash.com/photo-1610030469668-93535c17b6b3?auto=format&fit=crop&w=300&q=80'
    },
    { 
      id: 'PROD-11029', 
      name: 'Cotton Dress Material Indigo', 
      stock: 24, 
      price: '₹750',
      imageUrl: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=300&q=80'
    },
  ];

  const filtered = mockProducts.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5 p-4 max-w-7xl mx-auto">
      <Input 
        label="Filter Registered Database" 
        placeholder="Type to filter by Product Name or Catalog ID..." 
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* ==========================================
          1. DESKTOP VIEW: Showed at >= 'lg' Breakpoint
         ========================================== */}
      <div className="hidden lg:block">
        <ProductListDesktopView products={filtered} />
      </div>

      {/* ==========================================
          2. MOBILE/TABLET VIEW: Showed below 'lg' Breakpoint
         ========================================== */}
      <div className="block lg:hidden">
        <ProductListMobileView products={filtered} />
      </div>
    </div>
  );
};