export interface ProductMediaItem {
  path: string;
  presigned_url: string;
  url_expires_at: string;
  is_cover: boolean;
}

export interface Product {
  id: string; // Maps to product_id
  name: string; // Maps to product_name
  catalogId: string; // Maps to catalog_id
  categoryId: number;
  categoryName: string;
  stock: number; // Maps to quantity
  price: string;
  productStatus: 'Online' | 'Offline' | 'Incomplete';
  imageUrl?: string; 
  productMedia?: ProductMediaItem[];
}

export interface ViewProps {
  products: Product[];
  hasMore: boolean;
  loadMore: () => void;
  isLoadingMore: boolean;
}

export interface Category {
  id: number;
  category_name: string;
}