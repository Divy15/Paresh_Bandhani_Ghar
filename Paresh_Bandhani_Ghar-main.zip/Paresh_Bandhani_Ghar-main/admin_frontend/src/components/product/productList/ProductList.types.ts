export interface Product {
  id: string;
  name: string;
  stock: number;
  price: string;
  imageUrl?: string; // Added to support product images
}

export interface ViewProps {
  products: Product[];
}