import React, { useState } from 'react';
import { ProductListManager } from '../components/product/productList/ProductListManager';
import { ProductDetailsManager } from '../components/product/productDetails/ProductDetailsManager';
import type { CatalogProduct } from '../components/product/productDetails/ProductDetails.types';

export interface ProductItem {
  id: string;
  files: { url: string; type: 'image' | 'video' }[];
  name: string;
  material: string;
  color: string; 
  measurements: Record<string, string>;
  optionalFields: Record<string, string>;
  price: string;
  quantity: string;
}

interface ApiResponseProduct {
  productId: string;
  name: string;
  quantity: number;
}

export const ProductRegistrationPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'list' | 'register'>('list');
  const [apiResponse, setApiResponse] = useState<ApiResponseProduct[]>([]);

  // Receives the structured data from our step wizard compiler manager
  const handleWizardRegistrationComplete = async (compiledProducts: CatalogProduct[], contextualData: { category: string; subCategory: string }) => {
    console.log("Category Classification context captured:", contextualData);
    
    // Transform catalog wizard array parameters directly down into backend api target fields
    const submittablePayload = compiledProducts.map(p => ({
      name: p.name || "Unnamed Catalog Item",
      matrixType: p.matrixType,
      matrixRows: p.matrixRows,
      price: parseFloat(p.price) || 0,
      quantity: parseInt(p.quantity) || 1,
      mediaCount: p.files.length,
      meta: { category: contextualData.category, subCategory: contextualData.subCategory }
    }));

    console.log("Dispatching compiled API structural payload:", submittablePayload);

    const simulatedResponse: ApiResponseProduct[] = compiledProducts.map((p, index) => ({
      productId: `PBG-${Math.floor(10000 + Math.random() * 90000)}`,
      name: p.name || `Catalog Item Block #${index + 1}`,
      quantity: parseInt(p.quantity) || 1
    }));

    setApiResponse(simulatedResponse);
    setActiveTab('list'); // Returns focus safely back to lists upon generation execution completion
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Updated Header Layout: Stacks on mobile (flex-col), side-by-side on desktop (sm:flex-row) */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-border-main pb-4">
        <div>
          <h1 className="text-2xl font-serif font-bold text-brand-maroon-500">Product Administration</h1>
          <p className="text-xs text-text-muted">Manage product directories and catalog prints.</p>
        </div>
        
        {/* Updated Toggle Wrapper: Full-width on mobile (w-full), standard on desktop (sm:w-auto) */}
        <div className="flex w-full sm:w-auto bg-bg-card p-1 rounded-lg border border-border-main">
          <button 
            onClick={() => setActiveTab('list')}
            className={`flex-1 sm:flex-none text-center px-4 py-1.5 text-xs font-semibold rounded-md transition-all ${
              activeTab === 'list' 
                ? 'bg-brand-maroon-500 text-white shadow' 
                : 'text-text-muted hover:text-text-main'
            }`}
          >
            All Listed Products
          </button>
          <button 
            onClick={() => setActiveTab('register')}
            className={`flex-1 sm:flex-none text-center px-4 py-1.5 text-xs font-semibold rounded-md transition-all ${
              activeTab === 'register' 
                ? 'bg-brand-maroon-500 text-white shadow' 
                : 'text-text-muted hover:text-text-main'
            }`}
          >
            Register Product Catalog
          </button>
        </div>
      </div>

      {activeTab === 'list' ? (
        <div className="space-y-6">
          {apiResponse.length > 0 && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-xl text-xs space-y-1">
              <div className="font-bold">✓ Catalog Compiled Successfully!</div>
              {apiResponse.map(res => <div key={res.productId} className="font-mono text-[11px]">{res.productId} - {res.name} ({res.quantity} units indexed)</div>)}
            </div>
          )}
          <ProductListManager />
        </div>
      ) : (
        <ProductDetailsManager onComplete={handleWizardRegistrationComplete} />
      )}
    </div>
  );
};