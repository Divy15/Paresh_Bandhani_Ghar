import React, { useState } from 'react';
import { LoginForm } from '../components/login/Login';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast'; 
import { AnimatePresence } from 'motion/react';
import { loginMobileVerify, verifyOtp } from '../service/Login.service';
import { useLoader } from '../context/LoaderContext'; // 1. IMPORT LOADER HOOK

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const { showLoader, hideLoader } = useLoader(); // 2. EXTRACT SCREEN LOCK HOOKS
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');

  // 1. Handle requesting OTP verification code from backend
  const handlePhoneSubmit = async (phone: string) => {
    showLoader(); // Engage the spinning textile hoop veil
    try {
      await loginMobileVerify({ mobileNo: phone });
      setPhoneNumber(phone);
      
      toast.success('🔑 OTP Code sent to +91 ' + phone, {
        icon: '✨',
        style: { background: 'var(--bg-card)', color: 'var(--text-main)' }
      });
      setStep('otp');
    } catch (backendError: any) {
      toast.error(backendError);
    } finally {
      hideLoader(); // Drop the veil down safely
    }
  };

  // 2. Handle validating the entered OTP values against backend
  const handleOtpVerify = async (otp: string) => {
    showLoader(); // Lock viewport during authentication verification
    try {
      const result = await verifyOtp({ mobileNo: phoneNumber, otp: otp });
      const token = result?.token;
      localStorage.setItem('pbg_auth_token', token);
      
      toast.success('Access Authenticated Successfully!', { icon: '🎉' });
      
      // Delay to let the user see the success toast before route shift takes place
      setTimeout(() => {
        hideLoader(); // Lower loader right before redirecting
        login(phoneNumber);
      }, 1000);
    } catch (backendError: any) {
      toast.error(backendError);
      hideLoader(); // Release loader on error so they can re-enter numbers
    }
  };

  return (
    <div className="min-h-screen bg-bg-main text-text-main flex items-center justify-center p-4 transition-colors duration-300">
      
      <div className="w-full max-w-md bg-bg-card border border-border-main rounded-2xl shadow-xl overflow-hidden p-8 relative">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-linear-to-r from-brand-maroon-500 via-brand-gold-500 to-brand-maroon-600" />
        
        <div className="text-center mb-8">
          <h1 className="font-serif text-2xl font-extrabold text-brand-maroon-500 tracking-wide">
            Paresh Bandhani Ghar
          </h1>
          <p className="text-sm text-text-muted mt-1">Saree & Dress Enterprise Portal</p>
        </div>

        <AnimatePresence mode="wait">
          <LoginForm 
            step={step} 
            onPhoneSubmit={handlePhoneSubmit} 
            onOtpSubmit={handleOtpVerify} 
            phoneNumber={phoneNumber}
            onBackToPhone={() => setStep('phone')}
          />
        </AnimatePresence>
      </div>
    </div>
  );
};