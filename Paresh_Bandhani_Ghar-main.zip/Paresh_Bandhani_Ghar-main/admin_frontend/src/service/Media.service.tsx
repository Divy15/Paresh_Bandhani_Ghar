import { ApiObject } from '../api/endpoints';
import { apiClient } from '../api/client';
import axios from 'axios';

export const uploadImage = async (data: { type: string; file: File | Blob }) => {
    try {
        // Construct multipart form payload
        const formData = new FormData();
        formData.append('type', data.type);
        formData.append('file', data.file); // Matches backend mediaUpload.single('file')

        const response = await apiClient.post(ApiObject.Media.uploadFile, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            // FIX: Check for error.response.data.error to match your backend error payload structure
            throw error.response.data.error || error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const getPresignedURL = async (data: number) => {
    try {
        const response = await apiClient.get(`${ApiObject.Media.getPresignedUrl}/${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}