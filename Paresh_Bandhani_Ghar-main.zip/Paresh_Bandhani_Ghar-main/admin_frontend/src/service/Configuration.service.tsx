import { ApiObject } from '../api/endpoints';
import { apiClient } from '../api/client';
import axios from 'axios';

export interface WashingInstructionPayload {
  instruction: string;
  instructionDescription?: string | null;
}

export interface UpdateWashingInstructionPayload extends WashingInstructionPayload {
  id: number;
}

export interface WashingInstructionResponse {
  id: number;
  instruction: string;
  instruction_description: string | null;
  created_at: string;
}

export const storeCategory = async (data: { categoryName: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const updateCategory = async (data: { id: string; categoryName: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.updateCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const getCategories = async (data: string) => {
    try {
        const response = await apiClient.get(`${ApiObject.Configuration.getCategories}?search=${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const deleteCategory = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const storeSubCategory = async (data: { subcategoryName: string; categoryId: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeSubCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const updateSubCategory = async (data: { id: string; subcategoryName: string; categoryId: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.updateSubCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const getSubCategories = async (data: number) => {
    try {
        const response = await apiClient.get(`${ApiObject.Configuration.getSubCategories}?categoryId=${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const deleteSubCategory = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteSubCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const storeMaterial = async (data: { materialName: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeMaterial, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const deleteMaterial = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteMaterial, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const getMaterials = async () => {
    try {
        const response = await apiClient.get(ApiObject.Configuration.getMaterials);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const storeStructure = async (data: { mainName: string, includes: Array<[]> }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeStructure, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const getStructures = async (data: string) => {
    try {
        const response = await apiClient.get(`${ApiObject.Configuration.getStructures}?search=${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const deleteStructure = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteStructure, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const updateStructure = async (data: {id: number, mainName: string, includes: Array<[]>}) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.updateStructure, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

/**
 * 1. GET ALL OR SINGLE WASHING INSTRUCTION
 * Pass an optional ID to fetch a specific instruction item.
 */
export const getWashingInstructions = async (id?: number) => {
    try {
        const url = id 
            ? `${ApiObject.Configuration.getWashingInstruction}?id=${id}` 
            : ApiObject.Configuration.getWashingInstruction;
            
        const response = await apiClient.get(url);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

/**
 * 2. STORE NEW WASHING INSTRUCTION
 */
export const storeWashingInstruction = async (data: WashingInstructionPayload) => {
    try {
        const response = await apiClient.post(
            ApiObject.Configuration.storeWashingInstruction, 
            data
        );
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

/**
 * 3. UPDATE EXISTING WASHING INSTRUCTION
 */
export const updateWashingInstruction = async (data: UpdateWashingInstructionPayload) => {
    try {
        const response = await apiClient.put(
            ApiObject.Configuration.updateWashingInstruction, 
            data
        );
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

/**
 * 4. DELETE WASHING INSTRUCTION
 * Expects { id } passed inside the request body matching your backend controller validation rule
 */
export const deleteWashingInstruction = async (id: number) => {
    try {
        const response = await apiClient.delete(
            ApiObject.Configuration.deleteWashingInstruction, 
            { data: { id } } // In axios, body payloads for DELETE methods must be enclosed within a 'data' block config
        );
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};