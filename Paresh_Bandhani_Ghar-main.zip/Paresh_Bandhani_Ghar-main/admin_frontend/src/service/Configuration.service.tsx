import { ApiObject } from '../api/endpoints';
import { apiClient } from '../api/client';
import axios from 'axios';

export const storeCategory = async (data: { categoryName: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const updateCategory = async (data: { id: string; categoryName: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.updateCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const getCategories = async (data: string) => {
    try {
        const response = await apiClient.get(`${ApiObject.Configuration.getCategories}?search=${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const deleteCategory = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const storeSubCategory = async (data: { subcategoryName: string; categoryId: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeSubCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const updateSubCategory = async (data: { id: string; subcategoryName: string; categoryId: string, imageId: number }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.updateSubCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const getSubCategories = async (data: number) => {
    try {
        const response = await apiClient.get(`${ApiObject.Configuration.getSubCategories}?categoryId=${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const deleteSubCategory = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteSubCategory, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

export const storeMaterial = async (data: { materialName: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeMaterial, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const deleteMaterial = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteMaterial, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const getMaterials = async () => {
    try {
        const response = await apiClient.get(ApiObject.Configuration.getMaterials);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const storeStructure = async (data: { mainName: string, includes: Array<[]> }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.storeStructure, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const getStructures = async (data: string) => {
    try {
        const response = await apiClient.get(`${ApiObject.Configuration.getStructures}?search=${data}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const deleteStructure = async (data: { id: string }) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.deleteStructure, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

export const updateStructure = async (data: {id: number, mainName: string, includes: Array<[]>}) => {
    try {
        const response = await apiClient.post(ApiObject.Configuration.updateStructure, data);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            throw error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}