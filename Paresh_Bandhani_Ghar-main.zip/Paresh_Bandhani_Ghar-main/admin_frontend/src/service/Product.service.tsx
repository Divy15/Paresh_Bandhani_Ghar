import { ApiObject } from '../api/endpoints';
import { apiClient } from '../api/client';
import axios from 'axios';

export const StoreCategorySubcategory = async (payload: { categoryid: number; subcategoryid: number }) => {
    try {
    const response = await apiClient.post(ApiObject.Product.storeCategorySubcategory, payload);
    return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            // FIX: Check for error.response.data.error to match your backend error payload structure
            throw error.response.data.error || error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
};

interface FileMetadataInput {
  clientFilename: string;
  contentType: string;
  contentLength: number;
}

interface ProductBatchInput {
  files: FileMetadataInput[];
}

interface GenerateBatchPayload {
  catalogId: string;
  products: ProductBatchInput[];
}

export const generateBatchPresignedUrls = async (payload: GenerateBatchPayload) => {
  try {
    const response = await apiClient.post(
      ApiObject.Product.generateBatchPresignedUrls, 
      payload
    );
    return response.data; // Contains { success: true, products: [{ productId, uploads: [...] }] }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.data) {
      // Prioritize structured backend error keys, fall back cleanly to string messages
      throw error.response.data.error || error.response.data.message || 'Backend validation failed';
    }
    throw 'Network connection failure';
  }
};

export const storeProductMedia = async (payload: {catalogId: string; media: { productId: string; path: string; isCover: boolean }[] }) => {
    try {
        const response = await apiClient.post(
            ApiObject.Product.storeProductMediaData,
            payload
        );
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            // Prioritize structured backend error keys, fall back cleanly to string messages
            throw error.response.data.error || error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

interface ProductBatchPayload{
  productId: string;
  productName: string;
  quantity: number;
  price: number;
}

export const updateProductBatchDetails = async (payload: Array<ProductBatchPayload>) => {
  try {
    const response = await apiClient.post(ApiObject.Product.updateProductBatchDetails, {products: payload});
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.data) {
      // FIX: Check for error.response.data.error to match your backend error payload structure
      throw error.response.data.error || error.response.data.message || 'Backend validation failed';
    }
    throw 'Network connection failure';
  }
}

interface ProductMatrixPayload {
  productId: string;
  productMatrix: {
    product: string;
    material: string;
    colour: string;
    length: string;
    width: string;
    washingInstructionId: number | null;
  }[];
}

export const uploadProductMatrix = async (payload: ProductMatrixPayload) => {
  try {
    const response = await apiClient.post(ApiObject.Product.updateProductMatrix, payload);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.data) {
      // FIX: Check for error.response.data.error to match your backend error payload structure
      throw error.response.data.error || error.response.data.message || 'Backend validation failed';
    }
    throw 'Network connection failure';
  }}

export const updateProductDescriptionsBulk = async (payload: {productId: string; description: string}[]) => {
    try {
        const response = await apiClient.post(ApiObject.Product.updateProductDescriptionsBulk, payload);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            // FIX: Check for error.response.data.error to match your backend error payload structure
            throw error.response.data.error || error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}

interface GetProductListAPIPayload{
  catalogId :String; 
  productId :string;
  productName :string;
  pageNumber :number;
}

export const getProductsAndRefreshMedia = async (payload: GetProductListAPIPayload) => {
    try {
        const response = await apiClient.get(`${ApiObject.Product.getProductList}?catalogId=${payload.catalogId}&productId=${payload.productId}&productName=${payload.productName}&pageNumber=${payload.pageNumber}`);
        return response.data;
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.data) {
            // FIX: Check for error.response.data.error to match your backend error payload structure
            throw error.response.data.error || error.response.data.message || 'Backend validation failed';
        }
        throw 'Network connection failure';
    }
}
    