import { ApiObject } from '../api/endpoints';
import { apiClient } from '../api/client';
import axios from 'axios';

export const loginMobileVerify = async (data: { mobileNo: string }) => {
  try {
    const response = await apiClient.post(ApiObject.Auth.mobileNoValid, data);
    return response.data;
  } catch (error) {
    // Extract the precise error payload sent by your backend API response
    if (axios.isAxiosError(error) && error.response?.data) {
      throw error.response.data.message || 'Backend validation failed';
    }
    throw 'Network connection failure';
  }
};

export const verifyOtp = async (data: { mobileNo: string; otp: string }) => {
  try {
    const response = await apiClient.post(ApiObject.Auth.verifyOtp, data);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.data) {
      throw error.response.data.message || 'Invalid OTP validation data';
    }
    throw 'Network connection failure';
  }
};