import { createRoot } from 'react-dom/client'
import { AuthProvider } from "./context/AuthContext.tsx";
import { ThemeProvider } from "./context/ThemeContext.tsx";
import { LoaderProvider } from "./context/LoaderContext.tsx";
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <AuthProvider>
    <ThemeProvider>
      <LoaderProvider>
        <App />
      </LoaderProvider>
    </ThemeProvider>
  </AuthProvider>
)